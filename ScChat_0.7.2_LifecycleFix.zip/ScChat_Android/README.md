# Sc Chat — Android 0.7.2

<p align="center">
  <img src="app/src/main/assets/logo.png" width="112" alt="Sc Ai Lab atom emblem">
</p>

<p align="center"><strong>Your AI Workspace by Sc Ai Lab</strong></p>
<p align="center">Android · Multi-Provider · Local-First · 0.7.2</p>

---

## Overview

Sc Chat is an Android AI workspace developed by Sc Ai Lab. It brings AI conversations, projects, custom assistants, model connections, and local attachments into one mobile application.

The application supports Pollinations and user-configured OpenAI-compatible chat-completions providers. Its long-term direction is to integrate third-party cloud models, local inference runtimes, and Sc Ai Lab's own HSSM models behind a unified client architecture.

## What's New in 0.7.2

### Account & Profile Input Fix
- Account profile fields no longer activate the main chat composer's keyboard layout.
- Nickname, password, and account-deletion fields have isolated focus ownership.
- Delayed Android IME visibility callbacks are ignored by the chat composer while a modal/editor owns focus.

### Background & Restoration Improvements
- The WebView is paused and resumed through the Android Activity lifecycle.
- The application no longer unconditionally reloads the local page when returning to the foreground.
- WebView navigation state is saved and restored through Activity saved-instance state.
- The selected conversation, workspace page, open project, selected Provider, and active assistant are checkpointed per local account.
- The checkpoint is saved when the app becomes hidden and during Android lifecycle callbacks.
- WebView renderer termination is handled explicitly; the Activity is recreated from the local app entry point and workspace state is restored where possible.
- Initial conversation creation during restoration does not automatically focus the message input or open the keyboard.

**Android lifecycle limitation:** Android may terminate a background process under memory pressure. An app cannot guarantee that its process will remain alive indefinitely. This release focuses on preserving and restoring the user's workspace instead of trying to keep a background process alive with a permanent service.

## Features

### Chat Workspace
- Streaming assistant responses and stop generation.
- Copy, edit, and regenerate messages.
- Markdown, tables, and code blocks.
- Image and document attachments.
- Keyboard-aware mobile composer.

### Projects & Assistants
- Create, edit, and delete projects.
- Organize conversations into projects.
- Create and manage custom AI assistants.
- Configure assistant-specific system instructions.

### Models & Connections
- Pollinations integration.
- Custom OpenAI-compatible HTTPS providers.
- Provider connection tests and model discovery where supported.
- Per-model Vision and Streaming capability configuration.
- Context-window and pricing metadata.
- Local usage estimates and budget reminders.
- Provider credentials protected through the Android Keystore bridge.

### File Library
- Browse attachments from saved conversations.
- Search by filename or conversation title.
- Return to the source conversation.
- Extract text from supported text-based PDFs. Scanned image-only PDFs are not OCR-processed.

### Local Accounts
- Local registration and login.
- Profile image and display-name editing.
- Password changes and local account deletion.
- No cloud account, password recovery, or cross-device synchronization.

### Appearance & Android Integration
- Automatic Android light/dark theme.
- Sc Ai Lab blue accent and atom emblem.
- System-bar inset handling.
- Native IME inset handling and WebView lifecycle integration.

## Requirements

- Android 8.0 (API 26) or later.
- Internet access for remote providers.
- Provider credentials where required.
- An HTTPS endpoint compatible with the implemented OpenAI Chat Completions request format for custom providers.

## Install from GitHub Actions

1. Upload `ScChat_0.7.2_LifecycleFix.zip` to the repository root.
2. Put the workflow YAML at `.github/workflows/build-from-zip.yml`.
3. Run **Build Sc Chat 0.7.2 APK** from GitHub Actions.
4. Download the `ScChat-0.7.2-debug` artifact.
5. Install `app-debug.apk` on the Android device.

The output is a debug/test APK, not a production release.

## Build from Source

Requirements: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, and Gradle 8.9.

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Custom Provider Configuration

Open **Models & Connections** and add an OpenAI-compatible Provider. Configure its display name, HTTPS Base URL, model ID, API key, and supported capabilities.

Example values (illustrative only):

```text
Provider Name: My Provider
Base URL: https://api.example.com/v1
Model ID: example-model
API Key: your-provider-key
```

Provider prices, quotas, availability, and data-handling policies are controlled by the respective provider. Local usage and cost figures are estimates unless reconciled with an official provider billing API.

## Local Data & Privacy

- Accounts, profiles, conversations, projects, assistants, workspace checkpoints, and attachments are stored locally.
- Provider credentials are handled through the Android Keystore bridge.
- Prompts and attachments are transmitted to the selected provider when submitted.
- The app does not currently provide cloud synchronization or encrypted local conversation storage.
- Do not include passwords or sensitive credentials in chats or attachments.

## Compatibility & Upgrade Notes

| Setting | Value |
|---|---|
| Android Application ID | `ai.scailab.chat` |
| Local storage namespace | `scailab.*` |
| Version Code | `11` |
| Version Name | `0.7.2` |
| Minimum Android | API 26 / Android 8.0 |

Keep the same development signing certificate when installing an update over a previous test build. If Android reports a signature conflict, do not uninstall the old app until important local data has been exported or otherwise backed up.

## Roadmap

- [x] Local accounts and profile settings
- [x] Streaming chat and message actions
- [x] Provider management and model capability registry
- [x] Project and custom assistant management
- [x] Local file library
- [x] Android IME and system inset handling
- [x] Workspace checkpoint and Activity restoration
- [ ] Long-term conversation memory
- [ ] Context management
- [ ] Knowledge collections and RAG
- [ ] Voice input and speech output
- [ ] Native HSSM Provider integration
- [ ] Encrypted local conversation database and backups

## About Sc Ai Lab

Sc Chat is part of the Sc Ai Lab ecosystem. The long-term direction is to offer one flexible client for third-party cloud models, local inference engines, and Sc Ai Lab's own HSSM models.

## License

Apache License 2.0. See `LICENSE` for details.

## Disclaimer

Sc Chat 0.7.2 is an experimental development release. Features and provider compatibility may change. Real Android device testing is required for final validation of keyboard handling, lifecycle restoration, and background behavior.
