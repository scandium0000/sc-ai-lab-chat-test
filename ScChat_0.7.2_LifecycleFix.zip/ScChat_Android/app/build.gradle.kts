plugins {
    id("com.android.application")
}

android {
    namespace = "ai.scailab.chat"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.scailab.chat"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "0.7.2"
    }

    signingConfigs {
        create("development") {
            storeFile = file("dev-debug.jks")
            storeType = "PKCS12"
            storePassword = "scai-dev-only"
            keyAlias = "scai-debug"
            keyPassword = "scai-dev-only"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("development")
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
}
