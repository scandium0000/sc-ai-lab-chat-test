package ai.scailab.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

public final class MainActivity extends Activity {
    private static final String KEY_ALIAS = "scailab.chat.provider.keys.v1";
    private static final String SECRET_PREFS = "scailab_secure_provider_secrets";
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final int FILE_CHOOSER_REQUEST_CODE = 4105;
    private static final int SAVE_TEXT_FILE_REQUEST_CODE = 4106;
    private static final int MAX_EXPORT_BYTES = 8 * 1024 * 1024;
    private static final int MAX_PDF_BYTES = 10 * 1024 * 1024;
    private static final int MAX_PDF_TEXT_CHARS = 120000;

    private WebView webView;
    private FrameLayout rootContainer;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileChooserCallback;
    private volatile String pendingSaveContent;
    private volatile String pendingSaveMimeType;
    private volatile String pendingSaveFileName;
    private final ExecutorService networkExecutor = Executors.newCachedThreadPool();
    private final ConcurrentHashMap<String, HttpURLConnection> activeConnections = new ConcurrentHashMap<>();
    private final java.util.Set<String> cancelledRequests = ConcurrentHashMap.newKeySet();
    private volatile boolean activityDestroyed = false;
    private volatile boolean pdfBoxInitialized = false;
    private volatile boolean imeVisible = false;
    private boolean rendererGone = false;
    private boolean rendererRecoveryPending = false;
    private boolean activityResumed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        rootContainer = new FrameLayout(this);
        rootContainer.setBackgroundColor(isDarkMode() ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246));
        webView = new WebView(this);
        webView.setBackgroundColor(isDarkMode() ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246));
        rootContainer.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(rootContainer);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // The app handles system-bar and IME insets explicitly. This avoids relying
            // on OEM-specific adjustResize behavior inside Android WebView.
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
                            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        } else {
            // Legacy Android versions resize the content window when the IME opens.
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        applySystemBars();
        applyWindowInsets();

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Access is still gated by the Android document picker.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new ScAiBridge(), "ScAiBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] requestedTypes = requestedMimeTypes(params);
                intent.setType(requestedTypes.length == 1 ? requestedTypes[0] : "*/*");
                if (requestedTypes.length > 1) intent.putExtra(Intent.EXTRA_MIME_TYPES, requestedTypes);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                    return true;
                } catch (Exception error) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setSingleLine(true);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(message)
                        .setView(input)
                        .setPositiveButton("保存", (dialog, which) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                dispatchNativeImeState();
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        // Keep the current application screen if no browser can handle the link.
                    }
                    return true;
                }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                android.util.Log.e("ScChatLifecycle", "WebView renderer exited. didCrash="
                        + (detail != null && detail.didCrash())
                        + ", priority=" + (detail == null ? "unknown" : detail.rendererPriorityAtExit()));
                if (view == webView) {
                    rendererGone = true;
                    if (rootContainer != null) rootContainer.removeView(view);
                    webView = null;
                    view.destroy();
                    // Recreate only after a renderer failure. The new Activity will
                    // restore the last saved WebView state or reload the local entry
                    // point; the account and workspace checkpoint live in localStorage.
                    runOnUiThread(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        if (activityResumed) recreate();
                        else rendererRecoveryPending = true;
                    });
                } else {
                    view.destroy();
                }
                return true;
            }
        });

        boolean restoredPage = false;
        if (savedInstanceState != null) {
            try {
                android.webkit.WebBackForwardList restored = webView.restoreState(savedInstanceState);
                restoredPage = restored != null && restored.getSize() > 0;
                android.util.Log.i("ScChatLifecycle", "WebView state restored=" + restoredPage);
            } catch (Exception error) {
                android.util.Log.w("ScChatLifecycle", "WebView state restore failed; loading the local app entry point.", error);
            }
        }
        if (!restoredPage) {
            webView.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
        }
    }


    private String[] requestedMimeTypes(WebChromeClient.FileChooserParams params) {
        java.util.LinkedHashSet<String> types = new java.util.LinkedHashSet<>();
        if (params != null && params.getAcceptTypes() != null) {
            for (String raw : params.getAcceptTypes()) {
                if (raw == null) continue;
                for (String token : raw.split(",")) {
                    String value = token.trim().toLowerCase(java.util.Locale.ROOT);
                    if (value.isEmpty()) continue;
                    if (value.contains("/")) {
                        if (!"*/*".equals(value)) types.add(value);
                    } else if (value.startsWith(".")) {
                        switch (value) {
                            case ".pdf": types.add("application/pdf"); break;
                            case ".txt": case ".log": types.add("text/plain"); break;
                            case ".md": case ".markdown": types.add("text/markdown"); break;
                            case ".csv": types.add("text/csv"); break;
                            case ".json": types.add("application/json"); break;
                            case ".js": case ".ts": types.add("application/javascript"); break;
                            case ".py": types.add("text/x-python"); break;
                            case ".java": case ".kt": types.add("text/x-java-source"); break;
                            case ".html": types.add("text/html"); break;
                            case ".css": types.add("text/css"); break;
                            case ".xml": types.add("application/xml"); break;
                            case ".yaml": case ".yml": types.add("text/yaml"); break;
                            default: break;
                        }
                    }
                }
            }
        }
        if (types.isEmpty()) {
            java.util.Collections.addAll(types, "image/*", "application/pdf", "text/plain", "text/markdown",
                    "text/csv", "application/json", "application/javascript", "text/x-python",
                    "text/x-java-source", "text/html", "text/css", "application/xml", "text/yaml");
        }
        return types.toArray(new String[0]);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_TEXT_FILE_REQUEST_CODE) {
            String content = pendingSaveContent;
            pendingSaveContent = null;
            pendingSaveMimeType = null;
            pendingSaveFileName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || content == null) {
                notifyFileSaveResult(false, "已取消保存。");
                return;
            }
            Uri destination = data.getData();
            networkExecutor.execute(() -> {
                try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                    if (output == null) throw new IllegalStateException("无法打开保存位置。");
                    output.write(content.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                    notifyFileSaveResult(true, "文件已保存。");
                } catch (Exception error) {
                    String message = error.getMessage() == null ? "保存文件失败。" : error.getMessage();
                    notifyFileSaveResult(false, message.length() > 180 ? message.substring(0, 180) : message);
                }
            });
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST_CODE) return;
        if (fileChooserCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    private void notifyFileSaveResult(boolean success, String message) {
        WebView target = webView;
        if (target == null || activityDestroyed) return;
        String js = "window.__scaiFileSaveResult&&window.__scaiFileSaveResult(" + success + ","
                + JSONObject.quote(message == null ? "" : message) + ")";
        target.post(() -> target.evaluateJavascript(js, null));
    }

    private String extractPdfText(String encodedPdf) {
        if (encodedPdf == null || encodedPdf.length() > 14 * 1024 * 1024) {
            return "__PDF_ERROR__PDF 文件过大，最大支持 10 MB。";
        }
        try {
            byte[] pdfBytes = Base64.decode(encodedPdf, Base64.DEFAULT);
            if (pdfBytes.length == 0 || pdfBytes.length > MAX_PDF_BYTES) {
                return "__PDF_ERROR__PDF 文件为空或超过 10 MB 限制。";
            }
            if (!pdfBoxInitialized) {
                synchronized (MainActivity.class) {
                    if (!pdfBoxInitialized) {
                        PDFBoxResourceLoader.init(getApplicationContext());
                        pdfBoxInitialized = true;
                    }
                }
            }
            try (PDDocument document = PDDocument.load(new ByteArrayInputStream(pdfBytes))) {
                if (document.isEncrypted()) return "__PDF_ERROR__暂不支持加密或受密码保护的 PDF。";
                int pageCount = document.getNumberOfPages();
                if (pageCount <= 0) return "";
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setStartPage(1);
                stripper.setEndPage(Math.min(pageCount, 40));
                String text = stripper.getText(document);
                if (text == null) return "";
                if (text.length() > MAX_PDF_TEXT_CHARS) {
                    text = text.substring(0, MAX_PDF_TEXT_CHARS) + "\n\n[文档内容已截断：最多提取 120,000 个字符]";
                }
                return text;
            }
        } catch (Exception error) {
            String message = error.getMessage() == null ? "PDF 解析失败。" : error.getMessage();
            if (message.length() > 240) message = message.substring(0, 240);
            return "__PDF_ERROR__" + message;
        }
    }

    private boolean isDarkMode() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applySystemBars() {
        Window window = getWindow();
        boolean dark = isDarkMode();
        int background = dark ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(background);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                int appearance = 0;
                if (!dark) {
                    appearance = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                }
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(appearance, mask);
            }
        } else {
            int flags = 0;
            if (!dark) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        if (rootContainer != null) rootContainer.setBackgroundColor(background);
        if (webView != null) webView.setBackgroundColor(background);
    }

    private void applyWindowInsets() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            rootContainer.setOnApplyWindowInsetsListener((view, insets) -> {
                int insetTypes = WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout();
                android.graphics.Insets bars = insets.getInsets(insetTypes);
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                boolean keyboardVisible = insets.isVisible(WindowInsets.Type.ime());

                // Lay out the WebView inside the visible app area. The top margin
                // protects the toolbar from the status bar; the bottom margin follows
                // the IME when the keyboard opens and returns to the navigation bar
                // inset when it closes.
                int bottomInset = Math.max(bars.bottom, keyboardVisible ? ime.bottom : 0);
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) webView.getLayoutParams();
                if (params.topMargin != bars.top || params.bottomMargin != bottomInset
                        || params.leftMargin != bars.left || params.rightMargin != bars.right) {
                    params.setMargins(bars.left, bars.top, bars.right, bottomInset);
                    webView.setLayoutParams(params);
                }

                imeVisible = keyboardVisible;
                android.util.Log.d("ScChatInsets", "top=" + bars.top
                        + " bottom=" + bars.bottom + " ime=" + ime.bottom
                        + " visible=" + keyboardVisible
                        + " webViewHeight=" + webView.getHeight());
                dispatchNativeImeState();
                return WindowInsets.CONSUMED;
            });
            rootContainer.requestApplyInsets();
        }
        // API 26-29 use the platform's non-edge-to-edge content area and adjustResize.
        // Their WebView viewport is resized by the system when the keyboard is shown.
    }

    private void dispatchNativeImeState() {
        if (webView == null || activityDestroyed) return;
        webView.post(() -> {
            if (webView == null || activityDestroyed) return;
            String script = "if(window.__scaiNativeImeChanged){window.__scaiNativeImeChanged("
                    + imeVisible + ");}";
            webView.evaluateJavascript(script, null);
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && rootContainer != null) rootContainer.requestApplyInsets();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applySystemBars();
        if (rootContainer != null) rootContainer.requestApplyInsets();
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private SharedPreferences secretPrefs() {
        return getSharedPreferences(SECRET_PREFS, Context.MODE_PRIVATE);
    }

    private String readSecret(String key) throws Exception {
        String stored = secretPrefs().getString(key, null);
        if (stored == null) return null;
        String[] parts = stored.split("\\.", 2);
        if (parts.length != 2) return null;
        byte[] iv = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP);
        byte[] encrypted = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private boolean writeSecret(String key, String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String encoded = android.util.Base64.encodeToString(cipher.getIV(), android.util.Base64.NO_WRAP)
                + "." + android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP);
        return secretPrefs().edit().putString(key, encoded).commit();
    }

    private void emitNativeEvent(String id, String type, String payload) {
        if (activityDestroyed || webView == null) return;
        String js = "window.__scaiNativeEvent && window.__scaiNativeEvent(" + JSONObject.quote(id) + ","
                + JSONObject.quote(type) + "," + JSONObject.quote(payload == null ? "" : payload) + ");";
        runOnUiThread(() -> {
            if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private String resolveCredential(String credentialRef) throws Exception {
        if (credentialRef == null) throw new IllegalArgumentException("Missing API credential.");
        if (credentialRef.startsWith("literal:")) return credentialRef.substring("literal:".length());
        if (credentialRef.startsWith("secret:")) {
            String value = readSecret(credentialRef.substring("secret:".length()));
            if (value == null || value.isEmpty()) throw new IllegalStateException("API Key not found in Android Keystore storage.");
            return value;
        }
        throw new IllegalArgumentException("Unsupported credential reference.");
    }

    private void performChatRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
        HttpURLConnection connection = null;
        StringBuilder fullAnswer = new StringBuilder();
        try {
            if (cancelledRequests.remove(requestId)) return;
            Uri parsed = Uri.parse(endpoint);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IllegalArgumentException("Only HTTPS API endpoints are allowed.");
            }
            String credential = resolveCredential(credentialRef);
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("POST");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Bearer " + credential);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "text/event-stream, application/json");
            activeConnections.put(requestId, connection);
            if (cancelledRequests.remove(requestId)) { connection.disconnect(); return; }
            byte[] body = bodyJson.getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) { output.write(body); output.flush(); }

            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (status >= 400) {
                String errorText = readAll(stream);
                String detail = extractApiError(errorText);
                throw new IllegalStateException("API 请求失败（HTTP " + status + "）：" + detail);
            }
            String contentType = connection.getContentType() == null ? "" : connection.getContentType().toLowerCase();
            if (contentType.contains("text/event-stream")) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("data:")) {
                            String data = line.substring(5).trim();
                            if ("[DONE]".equals(data)) break;
                            String piece = parseStreamPiece(data);
                            if (!piece.isEmpty()) {
                                fullAnswer.append(piece);
                                emitNativeEvent(requestId, "chunk", piece);
                            }
                        }
                    }
                }
            } else {
                String jsonText = readAll(stream);
                String content = extractJsonAnswer(jsonText);
                if (!content.isEmpty()) {
                    fullAnswer.append(content);
                    emitNativeEvent(requestId, "chunk", content);
                }
            }
            emitNativeEvent(requestId, "done", fullAnswer.toString());
        } catch (Exception error) {
            emitNativeEvent(requestId, "error", error.getMessage() == null ? "Network request failed." : error.getMessage());
        } finally {
            activeConnections.remove(requestId);
            cancelledRequests.remove(requestId);
            if (connection != null) connection.disconnect();
        }
    }

    private void performProviderTest(String requestId, String endpoint, String credentialRef) {
        HttpURLConnection connection = null;
        int status = 0;
        String body = "";
        try {
            Uri parsed = Uri.parse(endpoint);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IllegalArgumentException("Only HTTPS API endpoints are allowed.");
            }
            String credential = resolveCredential(credentialRef);
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("Authorization", "Bearer " + credential);
            connection.setRequestProperty("Accept", "application/json");
            status = connection.getResponseCode();
            InputStream response = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            body = readLimited(response, 65536);
        } catch (Exception error) {
            body = error.getMessage() == null ? "Provider connection test failed." : error.getMessage();
        } finally {
            if (connection != null) connection.disconnect();
        }
        emitProviderTestResult(requestId, status, body);
    }

    private String readLimited(InputStream stream, int maxChars) throws Exception {
        if (stream == null) return "";
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[2048];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                int remaining = maxChars - text.length();
                if (remaining <= 0) break;
                text.append(buffer, 0, Math.min(read, remaining));
            }
        }
        return text.toString();
    }

    private void emitProviderTestResult(String requestId, int status, String body) {
        if (activityDestroyed || webView == null) return;
        String js = "window.__scaiProviderTestResult&&window.__scaiProviderTestResult("
                + JSONObject.quote(requestId) + "," + status + "," + JSONObject.quote(body == null ? "" : body) + ");";
        runOnUiThread(() -> {
            if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        }
        return text.toString();
    }

    private String parseStreamPiece(String data) throws JSONException {
        JSONObject root = new JSONObject(data);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject delta = choice == null ? null : choice.optJSONObject("delta");
        String value = delta == null ? (choice == null ? "" : choice.optString("text", "")) : delta.optString("content", "");
        return value;
    }

    private String extractJsonAnswer(String jsonText) throws JSONException {
        JSONObject root = new JSONObject(jsonText);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject message = choice == null ? null : choice.optJSONObject("message");
        return message == null ? (choice == null ? "" : choice.optString("text", "")) : message.optString("content", "");
    }

    private String extractApiError(String text) {
        try {
            JSONObject root = new JSONObject(text);
            JSONObject error = root.optJSONObject("error");
            return error == null ? root.optString("message", text) : error.optString("message", error.toString());
        } catch (Exception ignored) {
            return text.length() > 500 ? text.substring(0, 500) : text;
        }
    }

    private final class ScAiBridge {
        @JavascriptInterface
        public boolean saveTextFile(String fileName, String mimeType, String content) {
            if (content == null || activityDestroyed) return false;
            if (content.getBytes(StandardCharsets.UTF_8).length > MAX_EXPORT_BYTES) return false;
            String normalizedName = fileName == null ? "scailab-export.txt" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final String safeName = normalizedName.isEmpty() ? "scailab-export.txt" : normalizedName;
            final String safeMime = ("application/json".equals(mimeType) || "text/markdown".equals(mimeType)
                    || "text/plain".equals(mimeType)) ? mimeType : "text/plain";
            runOnUiThread(() -> {
                pendingSaveFileName = safeName;
                pendingSaveMimeType = safeMime;
                pendingSaveContent = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(safeMime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(intent, SAVE_TEXT_FILE_REQUEST_CODE);
                } catch (Exception error) {
                    pendingSaveContent = null;
                    pendingSaveMimeType = null;
                    pendingSaveFileName = null;
                    notifyFileSaveResult(false, "无法打开系统文件保存窗口。");
                }
            });
            return true;
        }

        @JavascriptInterface
        public boolean setSecret(String key, String value) {
            if (!isAllowedSecretKey(key) || value == null) return false;
            try { return writeSecret(key, value); } catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public boolean hasSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            try { String value = readSecret(key); return value != null && !value.isEmpty(); }
            catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public boolean removeSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            return secretPrefs().edit().remove(key).commit();
        }

        @JavascriptInterface
        public void startRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
            if (requestId == null || requestId.length() > 120 || endpoint == null || bodyJson == null) {
                emitNativeEvent(requestId == null ? "" : requestId, "error", "Invalid API request.");
                return;
            }
            networkExecutor.execute(() -> performChatRequest(requestId, endpoint, credentialRef, bodyJson));
        }

        @JavascriptInterface
        public void cancelRequest(String requestId) {
            cancelledRequests.add(requestId);
            HttpURLConnection connection = activeConnections.remove(requestId);
            if (connection != null) connection.disconnect();
        }

        @JavascriptInterface
        public void testProvider(String requestId, String endpoint, String credentialRef) {
            if (requestId == null || requestId.length() > 120 || endpoint == null || credentialRef == null) {
                emitProviderTestResult(requestId == null ? "" : requestId, 0, "Invalid provider test request.");
                return;
            }
            networkExecutor.execute(() -> performProviderTest(requestId, endpoint, credentialRef));
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Sc Chat", text == null ? "" : text));
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Sc Chat" : title);
                intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(intent, "分享或保存聊天记录"));
            });
        }

        @JavascriptInterface
        public void extractPdfTextAsync(String requestId, String base64Pdf) {
            if (requestId == null || requestId.length() > 120 || base64Pdf == null) return;
            networkExecutor.execute(() -> {
                String result = MainActivity.this.extractPdfText(base64Pdf);
                if (activityDestroyed || webView == null) return;
                String js = "window.__scaiPdfResult&&window.__scaiPdfResult(" + JSONObject.quote(requestId)
                        + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> {
                    if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
                });
            });
        }

        private boolean isAllowedSecretKey(String key) {
            return key != null && key.startsWith("scailab.provider.key.") && key.length() <= 180;
        }
    }

    @Override
    protected void onPause() {
        activityResumed = false;
        if (webView != null && !rendererGone) {
            // Persist the last workspace selection before Android potentially
            // reclaims this background process. localStorage writes are synchronous.
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            webView.onPause();
        }
        // The keyboard is not considered owned by the composer while the Activity
        // is backgrounded. Insets will be queried again on resume.
        imeVisible = false;
        super.onPause();
        android.util.Log.d("ScChatLifecycle", "Activity paused");
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityResumed = true;
        if (rendererRecoveryPending && !isFinishing()) {
            rendererRecoveryPending = false;
            recreate();
            return;
        }
        if (webView != null && !rendererGone) {
            webView.onResume();
            if (rootContainer != null) rootContainer.requestApplyInsets();
            dispatchNativeImeState();
        }
        android.util.Log.d("ScChatLifecycle", "Activity resumed without reloading the WebView");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null && !rendererGone) {
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            webView.saveState(outState);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN && webView != null && !rendererGone) {
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            android.util.Log.i("ScChatLifecycle", "Saved workspace checkpoint while app is hidden; trim level=" + level);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        pendingSaveContent = null;
        pendingSaveMimeType = null;
        pendingSaveFileName = null;
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        for (HttpURLConnection connection : activeConnections.values()) connection.disconnect();
        activeConnections.clear();
        cancelledRequests.clear();
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("ScAiBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
