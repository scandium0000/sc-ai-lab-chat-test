# Build Sc Chat 0.7.1 from an Android phone

1. Upload `ScChat_0.7.1_UXFix.zip` to the root of your private GitHub repository.
2. Replace `.github/workflows/build-from-zip.yml` with `build-from-zip-0.7.1.yml`.
3. Open **Actions** and select **Build Sc Chat 0.7.1 APK**.
4. Run the workflow and wait for validation, build, and APK signature verification.
5. Download the `ScChat-0.7.1-debug` artifact.

The build checks JavaScript syntax, Provider logic, UI regression behavior, asset references, and Android XML before compiling the APK.
