# Sc Ai Lab Chat — Android prototype 0.4.0

An Android WebView AI chat client with system light/dark appearance, the text-free Sc Ai Lab atom mark, local account registration/login, streaming chat, Markdown/code rendering, message actions, searchable conversation management, Pollinations BYOP, and multiple OpenAI-compatible providers.

## What changed in 0.4.0

- Redesigned the login, welcome, conversation, composer, and settings screens with a cleaner, Claude-inspired visual direction. This is an original Sc Ai Lab interface, not a copy of another product.
- Replaced in-app logo artwork with the text-free atom emblem.
- Kept existing account and chat-storage keys so the UI redesign does not intentionally reset local data.
- Changed the interface accent color to blue to match the Sc Ai Lab atom emblem.
- Added automatic light/dark appearance based on the Android system theme.
- Applied Android system-bar insets so the top toolbar no longer overlaps the phone status bar.
- Updated app version to 0.4.0 (versionCode 4).
- Added a ZIP-based GitHub Actions workflow template matching `ScAiLabChat_0.4.0.zip`.

## Features added in 0.4.0

- Streaming chat responses and a stop-generation control.
- Message actions: copy, edit a user prompt, and regenerate an assistant response.
- Escaped Markdown rendering for headings, lists, links, tables, blockquotes, inline code, fenced code, and lightweight syntax coloring.
- Pollinations plus custom OpenAI-compatible Chat Completions providers.
- Custom API keys encrypted at rest using Android Keystore AES-GCM; keys are not placed in localStorage or included in exports.
- Search, rename, pin, delete, and Markdown export for conversations; JSON backup sharing for all chat history.
- Android-native network requests for provider calls to avoid WebView CORS restrictions. Custom endpoints must use HTTPS and standard Bearer authentication.

## Current build status

This delivery is an **Android project source ZIP**, not a compiled APK. Build the APK with the included GitHub Actions workflow. This source package has passed static checks but has not yet been compiled or device-tested in this environment.

### Build an APK with GitHub Actions (no local Android SDK required)

A source-build workflow is included at `.github/workflows/build-debug-apk.yml`. For the phone-only workflow where the ZIP itself is uploaded to the repository root, use the separately supplied `build-from-zip-0.4.0.yml` template and save it at `.github/workflows/build-from-zip.yml`. It watches the exact archive name `ScAiLabChat_0.4.0.zip`.

1. Create a GitHub repository and upload the contents of this project ZIP.
2. Push the files to the repository's `main` or `master` branch. The workflow starts automatically; it can also be started from **Actions → Build Sc Ai Lab Debug APK → Run workflow**.
3. Open the completed workflow run and download the `ScAiLabChat-0.4.0-debug` artifact. The workflow uploads the single APK file directly rather than wrapping it in another ZIP.
4. Open the downloaded APK on your Android device and install it. Android may ask you to allow installation from the browser or file manager used to open it.

### Build locally with Android Studio

1. Open this folder in a recent Android Studio version with Android SDK 35 installed.
2. Allow Gradle sync and install any prompted SDK components.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The project uses Gradle 8.9; the included CI workflow installs it directly, so a Gradle wrapper JAR is not required for that route.
4. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Java + Android WebView, AndroidX WebKit, minSdk 26 (Android 8.0), and targetSdk 35. The debug APK is for testing and is not a Play Store release build.

## Pollinations setup

Pollinations authentication, model availability, and pricing are managed by Pollinations and may change. Confirm the current terms and model prices on its official site before authorizing generation requests. A model marked zero-price in a directory does not automatically mean every related service or account operation is free.

This prototype uses Pollinations' documented device authorization flow (BYOP):

1. A Sc Ai Lab publisher/developer must create a public App Key (`pk_...`) at `https://enter.pollinations.ai/keys` and configure it for the app.
2. In the app, open Settings and enter that public App Key.
3. Select **Connect Pollinations**. If the current Pollinations device authorization flow is available for your App Key, the app asks for a device code; open the authorization page and approve access.
4. The resulting short-lived user-authorized bearer key is held in app memory only. It is not written to localStorage. Disconnecting or exiting the app clears it.
5. The app queries `https://gen.pollinations.ai/text/models` and shows only models for which the returned pricing metadata is explicitly all-zero. If the pricing schema is unfamiliar or the directory is unavailable, it fails closed rather than silently selecting a potentially paid model.

The app does not contain a developer secret. The public `pk_...` App Key is configuration, not a substitute for user authorization. Users must review account limits and revoke access through the service provider when needed.

References:
- API docs: https://gen.pollinations.ai/
- BYOP device authorization: https://github.com/pollinations/pollinations/blob/main/BRING_YOUR_OWN_POLLEN.md
- Authentication: https://github.com/pollinations/pollinations/blob/main/gen.pollinations.ai/src/docs/authentication.md

## Local account system and limitations

- Register/login is local to this device. Usernames and PBKDF2-SHA256 password verifiers (210,000 iterations with per-user random salts) are stored in browser local storage.
- This is **not** a cloud account system: no server, email verification, password recovery, or multi-device sync exists in this prototype.
- Conversation text is stored locally in browser storage and is not encrypted at rest. Do not use real passwords or enter sensitive/personal information into this prototype.
- Pollinations access tokens are memory-only and are cleared on app process exit or disconnect.
- The app keeps a bounded recent context window (last 30 messages) when sending a request.
- The free-model filter uses live catalog pricing data and deliberately avoids selecting a model if zero pricing cannot be verified. Model pricing and availability can change.
- This is a prototype. Before public release, replace local accounts with a properly secured backend or a mature identity provider; assess data protection, abuse controls, logging, rate limits, and Android security requirements.

## Project structure

```text
app/
  src/main/
    AndroidManifest.xml
    java/ai/scailab/chat/MainActivity.java
    assets/
      index.html
      styles.css
      app.js
      logo.png
    res/...
```

The UI can also be previewed by opening `app/src/main/assets/index.html` in a browser. Pollinations requests require network connectivity and a correctly configured App Key plus user authorization.


## Version 0.4.0 notes

- Android app version: `0.4.0` (`versionCode 4`). The application ID remains `ai.scailab.chat` and existing local account/chat storage keys are preserved.
- Pollinations remains an optional provider. Model availability, pricing, and account authorization are controlled by Pollinations and can change. The app does not promise that Pollinations usage is free.
- Custom providers must expose an OpenAI-compatible `/chat/completions` endpoint over HTTPS and accept Bearer API-key authentication. Some providers require different request formats or headers and are not compatible.
- Custom provider API keys are stored in Android Keystore-backed AES-GCM encrypted preferences. In a plain browser preview, secrets are kept in memory only and are lost when the preview is reloaded.
- Chat histories remain local to the device. Export uses the Android share sheet and only includes the selected conversation or chat backup chosen by the user.
- Markdown rendering escapes raw HTML; links are limited to HTTP/HTTPS. Code highlighting is lightweight and does not replace a full compiler or formatter.
- This source package has passed static JavaScript/HTML/YAML/ZIP checks. Build the APK with the included GitHub Actions workflow; on-device runtime behavior still needs verification.

### Debug signing and upgrades

A dedicated **development-only** debug keystore is included so later 0.4.x builds from this project can share one signing identity. Keep this GitHub repository private. The keystore password in the Gradle file is intentionally a test-build credential, not a production secret; never reuse this keystore for a Play Store or public release. The first 0.4.0 build uses a different signing identity from earlier CI-generated 0.2/0.3 APKs, so Android may require uninstalling the older app before installing 0.4.0. Uninstalling removes local app data. Export/retain any data you need before uninstalling; once 0.4.0 is installed, subsequent builds using the included development keystore should update in place.
