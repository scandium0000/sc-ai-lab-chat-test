'use strict';

const $ = (id) => document.getElementById(id);
const STORE_USERS = 'scailab.users.v1';
const STORE_SESSION = 'scailab.session.v1';
const STORE_CHATS = 'scailab.chats.v1';
const STORE_APPKEY = 'scailab.pollinations.appkey.v1';
const STORE_PROVIDERS = 'scailab.providers.v1';
const STORE_ACTIVE_PROVIDER = 'scailab.activeProvider.v1';
const POLLINATIONS = 'https://gen.pollinations.ai';
const ENTER = 'https://enter.pollinations.ai';
const ITERATIONS = 210000;

let authMode = 'login';
let currentUser = null;
let currentChatId = null;
let chats = [];
let freeModels = [];
let providers = [];
let selectedProviderId = 'pollinations';
let accessToken = null; // OAuth access token remains memory-only.
let devicePollTimer = null;
let deviceCancelled = false;
let busy = false;
let activeController = null;
let toastTimer = null;
let runtimeSecrets = Object.create(null); // Preview fallback only; never persisted.
let pendingNative = new Map();

function safeJsonParse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } }
function getUsers() { return safeJsonParse(localStorage.getItem(STORE_USERS), {}); }
function setUsers(users) { localStorage.setItem(STORE_USERS, JSON.stringify(users)); }
function normaliseUsername(value) { return value.trim().toLowerCase(); }
function validUsername(value) { return /^[a-zA-Z0-9_-]{3,24}$/.test(value); }
function base64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))); }
function fromBase64(value) { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }
function randomBytes(length) { const out = new Uint8Array(length); crypto.getRandomValues(out); return out; }
async function derivePassword(password, salt) {
  if (!crypto.subtle) throw new Error('当前运行环境不支持安全密码摘要，请在 Android 应用或 HTTPS 环境中使用。');
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:ITERATIONS, hash:'SHA-256'}, material, 256);
  return base64(bits);
}

function showToast(message) {
  const toast = $('toast'); toast.textContent = message; toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}
function setAuthMode(mode) {
  authMode = mode;
  $('authTitle').textContent = mode === 'login' ? 'Welcome back.' : 'Create your space.';
  $('authSubtitle').textContent = mode === 'login' ? '进入 Sc Ai Lab Chat，开始你的 AI 对话。' : '创建一个保存在本机的 Sc Ai Lab 账户。';
  $('authSubmit').innerHTML = mode === 'login' ? '登录 <span>↗</span>' : '创建账户 <span>↗</span>';
  $('switchPrompt').textContent = mode === 'login' ? '还没有本地账户？' : '已经有账户了？';
  $('switchAuth').textContent = mode === 'login' ? '创建账户' : '返回登录';
  $('confirmWrap').classList.toggle('hidden', mode === 'login');
  $('authPassword').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('authError').textContent = '';
}

$('switchAuth').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'register' : 'login'));
$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const usernameRaw = $('authUsername').value.trim();
  const username = normaliseUsername(usernameRaw);
  const password = $('authPassword').value;
  $('authError').textContent = '';
  if (!validUsername(usernameRaw)) { $('authError').textContent = '用户名需为 3–24 位字母、数字、下划线或连字符。'; return; }
  if (password.length < 10) { $('authError').textContent = '密码至少需要 10 位。请勿重复使用其他网站的密码。'; return; }
  const users = getUsers();
  const submit = $('authSubmit'); submit.disabled = true;
  try {
    if (authMode === 'register') {
      if (users[username]) { $('authError').textContent = '这个用户名已经存在。'; return; }
      if (password !== $('authConfirm').value) { $('authError').textContent = '两次输入的密码不一致。'; return; }
      const salt = randomBytes(16);
      const hash = await derivePassword(password, salt);
      users[username] = {username: usernameRaw, salt: base64(salt), hash, createdAt: Date.now()};
      setUsers(users);
      localStorage.setItem(STORE_SESSION, username);
      enterApp(usernameRaw);
      showToast('本地账户创建成功');
    } else {
      const record = users[username];
      if (!record) { $('authError').textContent = '没有找到这个本地账户。请先注册。'; return; }
      const hash = await derivePassword(password, fromBase64(record.salt));
      if (hash !== record.hash) { $('authError').textContent = '用户名或密码不正确。'; return; }
      localStorage.setItem(STORE_SESSION, username);
      enterApp(record.username);
    }
  } catch (error) {
    $('authError').textContent = error?.message || '账户操作失败。';
  } finally { submit.disabled = false; }
});

function enterApp(username) {
  currentUser = username;
  $('authView').classList.add('hidden'); $('chatView').classList.remove('hidden');
  $('sidebarUsername').textContent = username; $('userAvatar').textContent = username.slice(0,1).toUpperCase();
  loadChats(); loadProviders(); renderConversationList();
  $('appKeyInput').value = localStorage.getItem(STORE_APPKEY) || '';
  selectedProviderId = localStorage.getItem(STORE_ACTIVE_PROVIDER) || 'pollinations';
  renderProviderControls();
  loadModels(); updateConnectionState();
  if (chats.length) selectChat(sortedChats()[0].id); else createChat();
}
function logOut() {
  if (activeController) activeController.abort();
  currentUser = null; accessToken = null; runtimeSecrets = Object.create(null); localStorage.removeItem(STORE_SESSION);
  if (devicePollTimer) clearTimeout(devicePollTimer);
  $('chatView').classList.add('hidden'); $('authView').classList.remove('hidden');
  $('authForm').reset(); setAuthMode('login');
}
$('logoutButton').addEventListener('click', logOut);

function chatStorageKey() { return `${STORE_CHATS}.${normaliseUsername(currentUser || '')}`; }
function loadChats() {
  chats = safeJsonParse(localStorage.getItem(chatStorageKey()), []);
  if (!Array.isArray(chats)) chats = [];
  chats.forEach(chat => { if (!Array.isArray(chat.messages)) chat.messages = []; if (typeof chat.pinned !== 'boolean') chat.pinned = false; });
}
function saveChats() { localStorage.setItem(chatStorageKey(), JSON.stringify(chats)); renderConversationList(); }
function sortedChats() { return [...chats].sort((a,b) => Number(!!b.pinned)-Number(!!a.pinned) || (b.updatedAt||0)-(a.updatedAt||0)); }
function createChat() {
  const chat = {id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), title:'新对话', messages:[], updatedAt:Date.now(), pinned:false};
  chats.unshift(chat); currentChatId = chat.id; saveChats(); renderMessages();
  $('welcomePanel').classList.remove('hidden'); $('messages').classList.add('hidden'); $('messageInput').focus(); closeSidebar();
}
function selectChat(id) {
  if (busy && activeGenerationChatId === currentChatId) stopGeneration();
  currentChatId = id; const chat = chats.find(item => item.id === id); if (!chat) return;
  renderConversationList(); renderMessages(); closeSidebar();
}
function activeChat() { return chats.find(item => item.id === currentChatId); }
function renderConversationList() {
  const list = $('conversationList'); if (!list) return;
  const query = ($('chatSearch')?.value || '').trim().toLowerCase();
  list.innerHTML = '';
  const visible = sortedChats().filter(chat => !query || (chat.title || '').toLowerCase().includes(query) || chat.messages.some(m => String(m.content||'').toLowerCase().includes(query)));
  if (!visible.length) {
    const empty = document.createElement('div'); empty.className = 'conversation-empty'; empty.textContent = query ? '没有匹配的对话' : '还没有对话'; list.appendChild(empty); return;
  }
  for (const chat of visible) {
    const row = document.createElement('div'); row.className = `conversation-row${chat.id === currentChatId ? ' active' : ''}`;
    const button = document.createElement('button'); button.className = 'conversation-item';
    button.textContent = `${chat.pinned ? '📌 ' : ''}${chat.title || '新对话'}`; button.title = chat.title || '新对话';
    button.addEventListener('click', () => selectChat(chat.id));
    const more = document.createElement('button'); more.className = 'conversation-more'; more.type = 'button'; more.textContent = '⋯'; more.setAttribute('aria-label','对话操作');
    const menu = document.createElement('div'); menu.className = 'conversation-menu hidden';
    const actions = [
      ['重命名', () => renameChat(chat)],
      [chat.pinned ? '取消置顶' : '置顶对话', () => { chat.pinned = !chat.pinned; chat.updatedAt = Date.now(); saveChats(); }],
      ['导出 Markdown', () => exportChat(chat)],
      ['删除对话', () => deleteChat(chat)]
    ];
    actions.forEach(([label, action]) => { const item = document.createElement('button'); item.type='button'; item.textContent=label; item.addEventListener('click', event => { event.stopPropagation(); menu.classList.add('hidden'); action(); }); menu.appendChild(item); });
    more.addEventListener('click', event => { event.stopPropagation(); document.querySelectorAll('.conversation-menu').forEach(other => { if (other !== menu) other.classList.add('hidden'); }); menu.classList.toggle('hidden'); });
    row.append(button, more, menu); list.appendChild(row);
  }
}
document.addEventListener('click', event => { if (!event.target.closest('.conversation-row')) document.querySelectorAll('.conversation-menu').forEach(menu => menu.classList.add('hidden')); });
$('chatSearch').addEventListener('input', renderConversationList);
function renameChat(chat) {
  const name = prompt('为这段对话设置一个名称：', chat.title || '新对话');
  if (name === null) return;
  const clean = name.trim().slice(0,80);
  if (!clean) { showToast('对话名称不能为空。'); return; }
  chat.title = clean; chat.updatedAt = Date.now(); saveChats(); showToast('对话已重命名。');
}
function deleteChat(chat) {
  if (!confirm(`确定删除“${chat.title || '新对话'}”吗？此操作无法撤销。`)) return;
  if (activeGenerationChatId===chat.id) stopGeneration();
  chats = chats.filter(item => item.id !== chat.id);
  if (currentChatId === chat.id) {
    currentChatId = null;
    if (chats.length) selectChat(sortedChats()[0].id); else createChat();
  } else saveChats();
  showToast('对话已删除。');
}
function markdownForChat(chat) {
  const lines = [`# ${chat.title || '新对话'}`, '', `导出时间：${new Date().toLocaleString()}`, ''];
  for (const message of chat.messages) lines.push(`## ${message.role === 'user' ? '用户' : 'Sc Ai Lab'}`, '', String(message.content || ''), '');
  return lines.join('\n');
}
function nativeShare(title, text) {
  if (window.ScAiBridge && typeof window.ScAiBridge.shareText === 'function') { window.ScAiBridge.shareText(title, text); return true; }
  copyText(text); showToast('当前预览环境不支持文件分享，内容已复制。'); return false;
}
function exportChat(chat) { nativeShare(`导出对话：${chat.title || '新对话'}`, markdownForChat(chat)); }
$('exportAllChats').addEventListener('click', () => {
  const backup = {format:'scailab-chat-backup-v1', exportedAt:new Date().toISOString(), username:currentUser, chats};
  nativeShare('Sc Ai Lab 聊天记录备份', JSON.stringify(backup, null, 2));
});
function renderMessages() {
  const chat = activeChat(); const messages = $('messages');
  if (!chat || chat.messages.length === 0) { $('welcomePanel').classList.remove('hidden'); messages.classList.add('hidden'); messages.innerHTML = ''; return; }
  $('welcomePanel').classList.add('hidden'); messages.classList.remove('hidden'); messages.innerHTML = '';
  chat.messages.forEach((item,index) => appendMessage(item.role, item.content, {index}));
  messages.scrollTop = messages.scrollHeight;
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function renderInlineMarkdown(text) {
  let html = escapeHtml(text);
  html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  return html;
}
function highlightCode(source, language) {
  const escaped = String(source);
  if (!/^(js|javascript|ts|typescript|py|python|json|bash|sh|yaml|yml|java|kotlin|css|html|xml)$/i.test(language || '')) return escapeHtml(escaped);
  const tokenPattern = /(\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(\b(?:const|let|var|function|return|if|else|for|while|class|new|async|await|import|from|export|default|try|catch|throw|public|private|static|final|void|int|boolean|extends|implements|package|interface|def|lambda|pass|True|False|None|null|undefined|true|false)\b)|(\b\d+(?:\.\d+)?\b)/g;
  let output=''; let last=0; let match;
  while((match=tokenPattern.exec(escaped))!==null) {
    output+=escapeHtml(escaped.slice(last,match.index));
    const token=match[0];
    const cls=match[1]?'code-comment':match[2]?'code-string':match[3]?'code-keyword':'code-number';
    output+=`<span class="${cls}">${escapeHtml(token)}</span>`; last=match.index+token.length;
  }
  return output+escapeHtml(escaped.slice(last));
}
function renderMarkdown(source) {
  const lines = String(source || '').replace(/\r\n?/g,'\n').split('\n');
  const output = []; let paragraph = []; let index = 0;
  const flushParagraph = () => { if (paragraph.length) { output.push(`<p>${paragraph.map(renderInlineMarkdown).join('<br>')}</p>`); paragraph=[]; } };
  while (index < lines.length) {
    const line = lines[index];
    const fence = line.match(/^\s*```([\w+-]*)\s*$/);
    if (fence) {
      flushParagraph(); const language = fence[1] || 'text'; index++; const code=[];
      while (index < lines.length && !/^\s*```\s*$/.test(lines[index])) code.push(lines[index++]);
      if (index < lines.length) index++;
      const raw = code.join('\n');
      output.push(`<div class="code-block"><div class="code-header"><span>${escapeHtml(language)}</span><button type="button" class="code-copy">复制代码</button></div><pre><code>${highlightCode(raw,language)}</code></pre></div>`);
      continue;
    }
    if (!line.trim()) { flushParagraph(); index++; continue; }
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) { flushParagraph(); const level=heading[1].length; output.push(`<h${level}>${renderInlineMarkdown(heading[2])}</h${level}>`); index++; continue; }
    if (/^\s*(---+|\*\*\*+)\s*$/.test(line)) { flushParagraph(); output.push('<hr>'); index++; continue; }
    if (line.startsWith('>')) { flushParagraph(); const quote=[]; while(index<lines.length && lines[index].startsWith('>')) quote.push(lines[index++].replace(/^>\s?/,'')); output.push(`<blockquote>${quote.map(renderInlineMarkdown).join('<br>')}</blockquote>`); continue; }
    if (/^\s*\|/.test(line) && index+1<lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[index+1])) {
      flushParagraph(); const parseCells = value => value.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(cell=>cell.trim());
      const headers=parseCells(line); index+=2; const rows=[];
      while(index<lines.length && /^\s*\|/.test(lines[index])) rows.push(parseCells(lines[index++]));
      output.push(`<div class="table-wrap"><table><thead><tr>${headers.map(cell=>`<th>${renderInlineMarkdown(cell)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${headers.map((_,i)=>`<td>${renderInlineMarkdown(row[i]||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
      continue;
    }
    if (/^\s*[-*+]\s+/.test(line)) {
      flushParagraph(); const items=[]; while(index<lines.length && /^\s*[-*+]\s+/.test(lines[index])) items.push(`<li>${renderInlineMarkdown(lines[index++].replace(/^\s*[-*+]\s+/,''))}</li>`); output.push(`<ul>${items.join('')}</ul>`); continue;
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      flushParagraph(); const items=[]; while(index<lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) items.push(`<li>${renderInlineMarkdown(lines[index++].replace(/^\s*\d+[.)]\s+/,''))}</li>`); output.push(`<ol>${items.join('')}</ol>`); continue;
    }
    paragraph.push(line); index++;
  }
  flushParagraph();
  return output.join('');
}
function appendMessage(role, content, opts = {}) {
  const messages = $('messages');
  const row = document.createElement('article'); row.className = `message ${role}`;
  const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = role === 'assistant' ? 'SC' : (currentUser || 'U').slice(0,1).toUpperCase();
  const bodyWrap = document.createElement('div'); bodyWrap.className = 'message-content';
  const label = document.createElement('div'); label.className = 'message-role'; label.textContent = role === 'assistant' ? 'SC AI LAB' : 'YOU';
  const body = document.createElement('div'); body.className = `message-body${opts.error ? ' error' : ''}`;
  if (opts.typing) body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  else body.innerHTML = renderMarkdown(content);
  bodyWrap.append(label, body);
  if (!opts.typing && Number.isInteger(opts.index)) {
    const actions = document.createElement('div'); actions.className = 'message-actions';
    const addAction = (labelText, actionName, callback) => { const button=document.createElement('button'); button.type='button'; button.textContent=labelText; button.dataset.action=actionName; button.addEventListener('click',callback); actions.appendChild(button); };
    addAction('复制', 'copy', () => copyText(String(content || '')));
    if (role === 'assistant') addAction('重新生成', 'regenerate', () => regenerateMessage(opts.index));
    if (role === 'user') addAction('编辑', 'edit', () => editMessage(opts.index));
    bodyWrap.append(actions);
  }
  row.append(avatar, bodyWrap); messages.appendChild(row); messages.scrollTop = messages.scrollHeight;
  row.querySelectorAll('.code-copy').forEach(button => button.addEventListener('click', () => copyText(button.closest('.code-block')?.querySelector('code')?.textContent || '')));
  return {row, body};
}
async function copyText(text) {
  try {
    if (window.ScAiBridge && typeof window.ScAiBridge.copyText === 'function') window.ScAiBridge.copyText(String(text));
    else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(String(text));
    else { const temp=document.createElement('textarea'); temp.value=String(text); document.body.appendChild(temp); temp.select(); document.execCommand('copy'); temp.remove(); }
    showToast('已复制到剪贴板。');
  } catch { showToast('复制失败，请长按文字选择复制。'); }
}
function editMessage(index) {
  const chat=activeChat(); if (!chat || !chat.messages[index] || chat.messages[index].role!=='user') return;
  const content=chat.messages[index].content;
  chat.messages=chat.messages.slice(0,index); chat.updatedAt=Date.now(); saveChats(); renderMessages();
  $('messageInput').value=content; autoResize(); $('messageInput').focus(); showToast('已载入提问。修改后发送即可。');
}
async function regenerateMessage(index) {
  const chat=activeChat(); if (!chat || busy || !chat.messages[index] || chat.messages[index].role!=='assistant') return;
  let userIndex=index-1; while(userIndex>=0 && chat.messages[userIndex].role!=='user') userIndex--;
  if (userIndex<0) { showToast('找不到对应的用户提问。'); return; }
  const promptText=chat.messages[userIndex].content;
  chat.messages=chat.messages.slice(0,index); chat.updatedAt=Date.now(); saveChats(); renderMessages();
  await requestAssistant(chat,promptText);
}
$('newChat').addEventListener('click', createChat);
document.querySelectorAll('.suggestion-card').forEach(button => button.addEventListener('click', () => { $('messageInput').value = button.dataset.prompt || ''; $('messageInput').focus(); autoResize(); }));

function setBusy(value) {
  busy = value; $('messageInput').disabled = value;
  $('sendButton').textContent = value ? '■' : '↑';
  $('sendButton').setAttribute('aria-label', value ? '停止生成' : '发送消息');
  $('sendButton').classList.toggle('stop-mode', value);
}
$('sendButton').addEventListener('click', event => { if (busy) { event.preventDefault(); stopGeneration(); } });
function stopGeneration() { if (activeController) activeController.abort(); }
$('composer').addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = $('messageInput').value.trim();
  if (!text || busy) return;
  if (selectedProviderId === 'pollinations') {
    if (!accessToken) { showToast('请先连接 Pollinations，或在设置中添加其他服务商。'); openSettings(); return; }
    if (!$('modelSelect').value || !freeModels.some(item => item.id === $('modelSelect').value)) { showToast('请先选择一个已确认零价格的 Pollinations 模型。'); openSettings(); return; }
  } else {
    const selected = providers.find(item => item.id === selectedProviderId);
    const ready = selected && (runtimeSecrets[selected.keyId] || (window.ScAiBridge && window.ScAiBridge.hasSecret && window.ScAiBridge.hasSecret(selected.keyId)));
    if (!ready) { showToast('请先在设置中添加并选择一个有效的服务商。'); openSettings(); return; }
  }
  $('messageInput').value = ''; autoResize();
  let chat=activeChat(); if (!chat) { createChat(); chat=activeChat(); }
  chat.messages.push({role:'user',content:text});
  if (chat.messages.length===1) chat.title=text.slice(0,36)||'新对话';
  chat.updatedAt=Date.now(); saveChats(); renderMessages();
  await requestAssistant(chat,text);
});
async function requestAssistant(chat, promptText) {
  const providerId=selectedProviderId;
  const provider=providers.find(item=>item.id===providerId);
  if (providerId==='pollinations') {
    if (!accessToken) { showToast('请先在设置中连接 Pollinations，或添加其他兼容服务。'); openSettings(); return; }
    const modelId=$('modelSelect').value;
    if (!modelId || !freeModels.some(item=>item.id===modelId)) { showToast('当前没有已确认零价格的 Pollinations 文本模型。'); openSettings(); return; }
  } else if (!provider) { showToast('请先添加并选择一个模型服务商。'); openSettings(); return; }
  const requestId=`req_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const controller=new AbortController(); activeController=controller; activeGenerationChatId=chat.id;
  const pending=chat.id===currentChatId ? appendMessage('assistant','',{typing:true}) : null;
  let answer=''; setBusy(true);
  try {
    const messages=chat.messages.slice(-30).map(message=>({role:message.role,content:message.content}));
    if (providerId==='pollinations') {
      const modelId=$('modelSelect').value;
      const body={model:modelId,messages,stream:true};
      const endpoint=`${POLLINATIONS}/v1/chat/completions`;
      const onChunk=chunk=>{answer+=chunk;updateStreamDisplay(pending,answer);};
      if(window.ScAiBridge&&typeof window.ScAiBridge.startRequest==='function') answer=await streamNative(requestId,endpoint,`literal:${accessToken}`,body,controller.signal,onChunk);
      else answer=await streamFetch(endpoint,accessToken,body,controller.signal,onChunk);
    } else {
      const endpoint=normaliseEndpoint(provider.baseUrl);
      const body={model:provider.model,messages,stream:true};
      const onChunk=chunk=>{answer+=chunk;updateStreamDisplay(pending,answer);};
      if (window.ScAiBridge && typeof window.ScAiBridge.startRequest==='function') {
        answer=await streamNative(requestId,endpoint,`secret:${provider.keyId}`,body,controller.signal,onChunk);
      } else {
        const key=runtimeSecrets[provider.keyId];
        if (!key) throw new Error('当前预览环境未保存 API Key。请在此会话重新输入密钥；正式 Android 应用会使用系统 Keystore 加密保存。');
        answer=await streamFetch(endpoint,key,body,controller.signal,onChunk);
      }
    }
    if (controller.signal.aborted && !answer.trim()) throw new DOMException('Generation stopped','AbortError');
    if (!answer.trim()) throw new Error('模型没有返回可显示的文本。');
    chat.messages.push({role:'assistant',content:answer.trim()}); chat.updatedAt=Date.now(); saveChats();
    if (pending) { pending.row.remove(); renderMessages(); }
  } catch (error) {
    if (error?.name==='AbortError') {
      if (answer.trim()) { chat.messages.push({role:'assistant',content:answer.trim()+'\n\n_（已停止生成）_'}); chat.updatedAt=Date.now(); saveChats(); }
      if (pending) {
        pending.row.remove();
        if (chat.id === currentChatId) { if (answer.trim()) renderMessages(); else appendMessage('assistant','已停止生成。',{error:true}); }
      }
      showToast('已停止生成。');
    } else {
      if (pending) pending.row.remove();
      const message=`${error?.message || '请求失败。'}\n\n请检查网络、服务商地址、API Key、模型名称和账户额度。`;
      if (pending) appendMessage('assistant',message,{error:true}); else showToast(message);
    }
  } finally {
    if (activeController===controller) activeController=null;
    activeGenerationChatId=null; setBusy(false); $('messageInput').focus();
  }
}
function updateStreamDisplay(pending, text) {
  if (!pending?.body) return;
  pending.body.innerHTML=renderMarkdown(text || '');
  pending.row.querySelectorAll('.code-copy').forEach(button => button.addEventListener('click', () => copyText(button.closest('.code-block')?.querySelector('code')?.textContent || '')));
  $('messages').scrollTop=$('messages').scrollHeight;
}
function normaliseEndpoint(baseUrl) {
  let url; try { url=new URL(baseUrl.trim()); } catch { throw new Error('服务商 Base URL 不是有效网址。'); }
  if (url.protocol!=='https:') throw new Error('为了保护 API Key，服务商地址必须使用 HTTPS。');
  let endpoint=url.toString().replace(/\/+$/,'');
  if (!/\/chat\/completions$/i.test(endpoint)) endpoint+='/chat/completions';
  return endpoint;
}
async function streamFetch(url, credential, body, signal, onChunk) {
  const response=await fetch(url,{method:'POST',signal,headers:{'Authorization':`Bearer ${credential}`,'Content-Type':'application/json','Accept':'text/event-stream, application/json'},body:JSON.stringify(body)});
  if (!response.ok) { const text=await response.text(); let detail=text; try { const parsed=JSON.parse(text); detail=parsed?.error?.message||parsed?.message||text; } catch {} throw new Error(`API 请求失败（HTTP ${response.status}）：${detail.slice(0,500)}`); }
  const type=response.headers.get('content-type')||'';
  if (type.includes('text/event-stream')) return readSse(response,onChunk);
  const payload=await response.json();
  const content=payload?.choices?.[0]?.message?.content??payload?.choices?.[0]?.text??'';
  const value=typeof content==='string'?content:Array.isArray(content)?content.map(part=>part.text||'').join(''):'';
  if (value) onChunk(value);
  return value;
}
async function readSse(response,onChunk) {
  if (!response.body?.getReader) throw new Error('当前设备不支持流式响应读取。');
  const reader=response.body.getReader(); const decoder=new TextDecoder(); let buffer=''; let all='';
  const consume=block=>{
    const data=block.split(/\r?\n/).filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trim()).join('\n');
    if (!data || data==='[DONE]') return;
    let payload; try { payload=JSON.parse(data); } catch { return; }
    const piece=payload?.choices?.[0]?.delta?.content??payload?.choices?.[0]?.text??'';
    const value=typeof piece==='string'?piece:Array.isArray(piece)?piece.map(part=>part.text||'').join(''):'';
    if (value) { all+=value; onChunk(value); }
    const error=payload?.error?.message; if (error) throw new Error(error);
  };
  while(true) {
    const {done,value}=await reader.read();
    buffer+=decoder.decode(value||new Uint8Array(),{stream:!done});
    let boundary;
    while((boundary=buffer.indexOf('\n\n'))>=0) { const block=buffer.slice(0,boundary); buffer=buffer.slice(boundary+2); consume(block); }
    if(done) break;
  }
  if(buffer.trim()) consume(buffer);
  return all;
}
function streamNative(requestId, endpoint, credentialRef, body, signal, onChunk) {
  return new Promise((resolve,reject)=>{
    const entry={resolve,reject,onChunk}; pendingNative.set(requestId,entry);
    const abort=()=>{ pendingNative.delete(requestId); try { window.ScAiBridge.cancelRequest(requestId); } catch {} reject(new DOMException('Generation stopped','AbortError')); };
    signal.addEventListener('abort',abort,{once:true}); entry.cleanup=()=>signal.removeEventListener('abort',abort);
    try { window.ScAiBridge.startRequest(requestId,endpoint,credentialRef,JSON.stringify(body)); }
    catch(error) { pendingNative.delete(requestId); entry.cleanup(); reject(error); }
  });
}
window.__scaiNativeEvent=(id,type,payload)=>{
  const entry=pendingNative.get(id); if(!entry) return;
  if(type==='chunk') entry.onChunk(payload);
  else if(type==='done') { pendingNative.delete(id); entry.cleanup?.(); entry.resolve(payload||''); }
  else if(type==='error') { pendingNative.delete(id); entry.cleanup?.(); entry.reject(new Error(payload||'Native network request failed.')); }
};
function autoResize() { const input=$('messageInput'); input.style.height='auto'; input.style.height=`${Math.min(input.scrollHeight,170)}px`; }
$('messageInput').addEventListener('input',autoResize);
$('messageInput').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();$('composer').requestSubmit();}});

function openSettings() { $('settingsModal').classList.remove('hidden'); renderProviderControls(); }
function closeSettings() { $('settingsModal').classList.add('hidden'); }
$('settingsButton').addEventListener('click',openSettings); $('topSettings').addEventListener('click',openSettings);
$('closeSettings').addEventListener('click',closeSettings); $('doneSettings').addEventListener('click',closeSettings);
$('settingsModal').addEventListener('click',event=>{if(event.target===$('settingsModal'))closeSettings();});
$('appKeyInput').addEventListener('change',()=>localStorage.setItem(STORE_APPKEY,$('appKeyInput').value.trim()));
$('disconnectButton').addEventListener('click',()=>{accessToken=null;deviceCancelled=true;updateConnectionState();showToast('已断开 Pollinations 连接。');});

function loadProviders() {
  providers=safeJsonParse(localStorage.getItem(STORE_PROVIDERS),[]);
  if(!Array.isArray(providers)) providers=[];
  providers=providers.filter(item=>item&&item.id&&item.name&&item.baseUrl&&item.model&&item.keyId);
}
function saveProviders() { localStorage.setItem(STORE_PROVIDERS,JSON.stringify(providers)); }
function renderProviderControls() {
  const select=$('providerSelect'); if(!select) return;
  select.innerHTML='';
  const poll=document.createElement('option'); poll.value='pollinations'; poll.textContent='Pollinations'; select.appendChild(poll);
  providers.forEach(provider=>{const option=document.createElement('option');option.value=provider.id;option.textContent=provider.name;select.appendChild(option);});
  if(selectedProviderId!=='pollinations'&&!providers.some(item=>item.id===selectedProviderId))selectedProviderId='pollinations';
  select.value=selectedProviderId;
  $('pollinationsSettings').classList.toggle('hidden',selectedProviderId!=='pollinations');
  $('customProviderList').innerHTML='';
  providers.forEach(provider=>{
    const row=document.createElement('div');row.className='provider-saved-row';
    const info=document.createElement('div');info.className='provider-saved-info';
    const title=document.createElement('strong');title.textContent=provider.name;
    const detail=document.createElement('small');detail.textContent=`${provider.model} · ${new URL(provider.baseUrl).host}`;
    info.append(title,detail);
    const remove=document.createElement('button');remove.type='button';remove.className='provider-remove';remove.textContent='移除';
    remove.addEventListener('click',async()=>{
      if(!confirm(`确定移除服务商“${provider.name}”吗？`))return;
      providers=providers.filter(item=>item.id!==provider.id);await removeSecret(provider.keyId);
      if(selectedProviderId===provider.id)selectedProviderId='pollinations';
      localStorage.setItem(STORE_ACTIVE_PROVIDER,selectedProviderId);saveProviders();renderProviderControls();updateConnectionState();showToast('服务商已移除。');
    });
    row.append(info,remove);$('customProviderList').appendChild(row);
  });
  updateSelectedModelLabel(); updateConnectionState();
}
$('providerSelect').addEventListener('change',()=>{
  selectedProviderId=$('providerSelect').value;localStorage.setItem(STORE_ACTIVE_PROVIDER,selectedProviderId);
  renderProviderControls();
  if(selectedProviderId==='pollinations')loadModels();
});
async function saveSecret(key,value) {
  if(window.ScAiBridge&&typeof window.ScAiBridge.setSecret==='function') {
    if(!window.ScAiBridge.setSecret(key,value)) throw new Error('Android Keystore 保存失败，请重试。');
  } else runtimeSecrets[key]=value;
}
async function removeSecret(key) {
  if(window.ScAiBridge&&typeof window.ScAiBridge.removeSecret==='function')window.ScAiBridge.removeSecret(key);
  delete runtimeSecrets[key];
}
$('saveProviderButton').addEventListener('click',async()=>{
  const name=$('providerNameInput').value.trim().slice(0,40);
  const baseUrl=$('providerBaseUrlInput').value.trim();
  const model=$('providerModelInput').value.trim().slice(0,120);
  const apiKey=$('providerApiKeyInput').value.trim();
  if(!name||!baseUrl||!model||!apiKey){showToast('请完整填写名称、Base URL、模型 ID 和 API Key。');return;}
  try {
    const endpoint=normaliseEndpoint(baseUrl); const parsed=new URL(endpoint);
    if(!/^https:$/.test(parsed.protocol)){showToast('服务商必须使用 HTTPS。');return;}
    const id=crypto.randomUUID?crypto.randomUUID():`provider_${Date.now()}`;
    const keyId=`scailab.provider.key.${id}`;
    await saveSecret(keyId,apiKey);
    providers.push({id,name,baseUrl:baseUrl.replace(/\/+$/,''),model,keyId,createdAt:Date.now()});
    saveProviders();selectedProviderId=id;localStorage.setItem(STORE_ACTIVE_PROVIDER,id);
    $('providerNameInput').value='';$('providerBaseUrlInput').value='';$('providerModelInput').value='';$('providerApiKeyInput').value='';
    renderProviderControls();showToast('兼容服务商已添加，密钥已安全保存。');
  } catch(error){showToast(error.message||'保存服务商失败。');}
});
async function loadModels() {
  if(selectedProviderId!=='pollinations') { updateSelectedModelLabel(); return; }
  $('modelStatus').textContent='正在获取 Pollinations 实时文本模型目录…';$('modelSelect').innerHTML='<option>正在加载…</option>';
  try {
    const response=await fetch(`${POLLINATIONS}/text/models`,{headers:{'Accept':'application/json'}});
    if(!response.ok)throw new Error(`目录请求失败（HTTP ${response.status}）`);
    const raw=await response.json();const entries=Array.isArray(raw)?raw:(raw.data||raw.models||raw.results||[]);
    freeModels=entries.map(entry=>({id:entry.id||entry.name||entry.model||entry.slug,label:entry.name||entry.title||entry.id||entry.model,raw:entry})).filter(item=>item.id&&isExplicitlyFree(item.raw));
    const select=$('modelSelect');select.innerHTML='';
    if(!freeModels.length){select.innerHTML='<option value="">当前没有检测到零价格文本模型</option>';$('modelStatus').textContent='目录中没有返回明确标记为零价格的文本模型。你可以添加其他兼容服务商。';$('selectedModelLabel').textContent='未找到免费模型';return;}
    freeModels.sort((a,b)=>String(a.label).localeCompare(String(b.label)));
    for(const item of freeModels){const option=document.createElement('option');option.value=item.id;option.textContent=`${item.label} · FREE`;select.appendChild(option);}
    $('modelStatus').textContent=`已找到 ${freeModels.length} 个明确零价格的文本模型。列表以实时目录为准。`;
    updateSelectedModelLabel();
  }catch(error){freeModels=[];$('modelSelect').innerHTML='<option value="">无法加载模型目录</option>';$('modelStatus').textContent=`${error.message}。请检查网络，或配置其他服务商。`;$('selectedModelLabel').textContent='目录不可用';}
}
function isExplicitlyFree(model) {
  const candidates=[];
  const addNumericLeaves=value=>{
    if(typeof value==='number'&&Number.isFinite(value))candidates.push(value);
    else if(Array.isArray(value))value.forEach(addNumericLeaves);
    else if(value&&typeof value==='object')Object.entries(value).forEach(([key,val])=>{if(/price|pricing|cost|pollen|token|input|output|prompt|completion/i.test(key))addNumericLeaves(val);else if(val&&typeof val==='object')addNumericLeaves(val);});
  };
  for(const key of ['pricing','price','input_price','output_price','cost','pollen'])if(key in model)addNumericLeaves(model[key]);
  return candidates.length>0&&candidates.every(value=>value===0);
}
$('refreshModels').addEventListener('click',loadModels);
$('modelSelect').addEventListener('change',updateSelectedModelLabel);
function updateSelectedModelLabel() {
  const selected=providers.find(item=>item.id===selectedProviderId);
  if(selected){$('selectedModelLabel').textContent=`${selected.name} · ${selected.model}`;return;}
  const option=$('modelSelect').selectedOptions[0];$('selectedModelLabel').textContent=option?.value?option.textContent:'未选择模型';
}

async function connectPollinations() {
  const appKey=$('appKeyInput').value.trim();
  if(!appKey.startsWith('pk_')){showToast('请先填入 Pollinations App Key（pk_…）。');return;}
  localStorage.setItem(STORE_APPKEY,appKey);
  if(devicePollTimer)clearTimeout(devicePollTimer);
  deviceCancelled=false;$('connectButton').disabled=true;$('connectButton').textContent='正在启动授权…';
  $('devicePanel').classList.remove('hidden');$('deviceStatus').textContent='正在向 Pollinations 请求设备授权码…';
  try {
    const response=await fetch(`${ENTER}/api/device/code`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:appKey})});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(payload.error_description||payload.error||`HTTP ${response.status}`);
    if(!payload.device_code||!payload.user_code)throw new Error('授权服务未返回完整设备代码。');
    $('deviceCode').textContent=payload.user_code;
    $('deviceLink').href=payload.verification_uri?new URL(payload.verification_uri,ENTER).href:`${ENTER}/device`;
    $('deviceStatus').textContent='请打开授权页面并输入上方代码。授权完成后，本应用会自动连接。';
    pollDeviceToken(payload.device_code,Date.now()+12*60*1000);
  }catch(error){$('deviceStatus').textContent=`启动失败：${error.message}`;showToast('无法启动 Pollinations 授权。');}
  finally{$('connectButton').disabled=false;$('connectButton').textContent='重新连接 ↗';}
}
function pollDeviceToken(deviceCode,deadline) {
  const poll=async()=>{
    if(deviceCancelled||Date.now()>deadline){$('deviceStatus').textContent=deviceCancelled?'授权已取消。':'授权等待超时，请重新开始。';return;}
    try {
      const response=await fetch(`${ENTER}/api/device/token`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device_code:deviceCode})});
      const payload=await response.json().catch(()=>({}));
      if(response.ok&&payload.access_token){accessToken=payload.access_token;$('deviceStatus').textContent='授权成功。你可以关闭此窗口并开始对话。';updateConnectionState();showToast('Pollinations 已连接。');return;}
      const error=payload.error||'';
      if(error==='authorization_pending'||response.status===400||response.status===428){$('deviceStatus').textContent='等待你在浏览器中确认授权…';}
      else if(error==='slow_down'){$('deviceStatus').textContent='授权服务要求降低轮询频率，正在稍后重试…';devicePollTimer=setTimeout(poll,8000);return;}
      else if(error)throw new Error(payload.error_description||error);
      else if(!response.ok)throw new Error(payload.error_description||`HTTP ${response.status}`);
    }catch(error){$('deviceStatus').textContent=`授权检查失败：${error.message}`;return;}
    devicePollTimer=setTimeout(poll,5000);
  };
  devicePollTimer=setTimeout(poll,5000);
}
$('connectButton').addEventListener('click',connectPollinations);
$('cancelDevice').addEventListener('click',()=>{deviceCancelled=true;if(devicePollTimer)clearTimeout(devicePollTimer);$('deviceStatus').textContent='已取消。';});
function updateConnectionState() {
  const usingPollinations=selectedProviderId==='pollinations';
  const selectedCustom=providers.find(item=>item.id===selectedProviderId);
  let customKeyExists=!!(selectedCustom&&runtimeSecrets[selectedCustom.keyId]);
  if(selectedCustom&&window.ScAiBridge&&typeof window.ScAiBridge.hasSecret==='function') customKeyExists=window.ScAiBridge.hasSecret(selectedCustom.keyId);
  const connected=usingPollinations?!!accessToken:!!(selectedCustom&&customKeyExists);
  const pill=$('connectionLabel');pill.classList.toggle('connected',connected);
  pill.innerHTML=connected?'<i></i> Connected':'<i></i> Not connected';
  $('apiStatus').textContent=accessToken?'已授权':'未授权';
  $('disconnectButton').classList.toggle('hidden',!accessToken);
  $('apiHint').textContent=usingPollinations
    ?(accessToken?'Pollinations 已连接。发送前请确认所选模型的实时价格与账户额度。':'可连接 Pollinations，或在设置中添加其他兼容服务商。Pollinations 调用可能产生费用。')
    :`当前使用 ${providers.find(item=>item.id===selectedProviderId)?.name||'自定义服务商'}。费用与免费额度由对应服务商决定。`;
}

$('clearLocalData').addEventListener('click',()=>{
  if(!confirm('确定清除这台设备上的所有 Sc Ai Lab 本地账户和聊天记录吗？此操作无法撤销。'))return;
  providers.forEach(provider=>removeSecret(provider.keyId));
  localStorage.removeItem(STORE_USERS);localStorage.removeItem(STORE_SESSION);
  localStorage.removeItem(STORE_PROVIDERS);localStorage.removeItem(STORE_ACTIVE_PROVIDER);
  localStorage.removeItem(STORE_APPKEY);
  for(const key of Object.keys(localStorage))if(key.startsWith(STORE_CHATS+'.'))localStorage.removeItem(key);
  accessToken=null;closeSettings();logOut();showToast('本地账户、服务商配置与聊天记录已清除。');
});
function openSidebar(){$('sidebar').classList.add('open');}
function closeSidebar(){$('sidebar').classList.remove('open');}
$('openSidebar').addEventListener('click',openSidebar);$('closeSidebar').addEventListener('click',closeSidebar);

(function boot(){
  setAuthMode('login');
  const saved=localStorage.getItem(STORE_SESSION);
  if(saved){const account=getUsers()[saved];if(account)enterApp(account.username);else localStorage.removeItem(STORE_SESSION);}
})();
