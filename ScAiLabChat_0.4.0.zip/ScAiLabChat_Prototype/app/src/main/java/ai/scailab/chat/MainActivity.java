package ai.scailab.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class MainActivity extends Activity {
    private static final String KEY_ALIAS = "scailab.chat.provider.keys.v1";
    private static final String SECRET_PREFS = "scailab_secure_provider_secrets";
    private static final String ASSET_HOST = "appassets.androidplatform.net";

    private WebView webView;
    private WebViewAssetLoader assetLoader;
    private final ExecutorService networkExecutor = Executors.newCachedThreadPool();
    private final ConcurrentHashMap<String, HttpURLConnection> activeConnections = new ConcurrentHashMap<>();
    private final java.util.Set<String> cancelledRequests = ConcurrentHashMap.newKeySet();
    private volatile boolean activityDestroyed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(isDarkMode() ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246));
        setContentView(webView);
        applySystemBars();
        applyWindowInsets();

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new ScAiBridge(), "ScAiBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setSingleLine(true);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(message)
                        .setView(input)
                        .setPositiveButton("保存", (dialog, which) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        // Keep the current application screen if no browser can handle the link.
                    }
                    return true;
                }
                return true;
            }
        });

        webView.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
    }

    private boolean isDarkMode() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applySystemBars() {
        Window window = getWindow();
        boolean dark = isDarkMode();
        int background = dark ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(background);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        int flags = 0;
        if (!dark) {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        window.getDecorView().setSystemUiVisibility(flags);
        if (webView != null) webView.setBackgroundColor(background);
    }

    private void applyWindowInsets() {
        webView.setOnApplyWindowInsetsListener((view, insets) -> {
            int top;
            int bottom;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                top = bars.top;
                bottom = bars.bottom;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            view.setPadding(0, top, 0, bottom);
            return insets;
        });
        webView.requestApplyInsets();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applySystemBars();
        if (webView != null) webView.requestApplyInsets();
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private SharedPreferences secretPrefs() {
        return getSharedPreferences(SECRET_PREFS, Context.MODE_PRIVATE);
    }

    private String readSecret(String key) throws Exception {
        String stored = secretPrefs().getString(key, null);
        if (stored == null) return null;
        String[] parts = stored.split("\\.", 2);
        if (parts.length != 2) return null;
        byte[] iv = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP);
        byte[] encrypted = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private boolean writeSecret(String key, String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String encoded = android.util.Base64.encodeToString(cipher.getIV(), android.util.Base64.NO_WRAP)
                + "." + android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP);
        return secretPrefs().edit().putString(key, encoded).commit();
    }

    private void emitNativeEvent(String id, String type, String payload) {
        if (activityDestroyed || webView == null) return;
        String js = "window.__scaiNativeEvent && window.__scaiNativeEvent(" + JSONObject.quote(id) + ","
                + JSONObject.quote(type) + "," + JSONObject.quote(payload == null ? "" : payload) + ");";
        runOnUiThread(() -> {
            if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private String resolveCredential(String credentialRef) throws Exception {
        if (credentialRef == null) throw new IllegalArgumentException("Missing API credential.");
        if (credentialRef.startsWith("literal:")) return credentialRef.substring("literal:".length());
        if (credentialRef.startsWith("secret:")) {
            String value = readSecret(credentialRef.substring("secret:".length()));
            if (value == null || value.isEmpty()) throw new IllegalStateException("API Key not found in Android Keystore storage.");
            return value;
        }
        throw new IllegalArgumentException("Unsupported credential reference.");
    }

    private void performChatRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
        HttpURLConnection connection = null;
        StringBuilder fullAnswer = new StringBuilder();
        try {
            if (cancelledRequests.remove(requestId)) return;
            Uri parsed = Uri.parse(endpoint);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IllegalArgumentException("Only HTTPS API endpoints are allowed.");
            }
            String credential = resolveCredential(credentialRef);
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("POST");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Bearer " + credential);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "text/event-stream, application/json");
            activeConnections.put(requestId, connection);
            if (cancelledRequests.remove(requestId)) { connection.disconnect(); return; }
            byte[] body = bodyJson.getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) { output.write(body); output.flush(); }

            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (status >= 400) {
                String errorText = readAll(stream);
                String detail = extractApiError(errorText);
                throw new IllegalStateException("API 请求失败（HTTP " + status + "）：" + detail);
            }
            String contentType = connection.getContentType() == null ? "" : connection.getContentType().toLowerCase();
            if (contentType.contains("text/event-stream")) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("data:")) {
                            String data = line.substring(5).trim();
                            if ("[DONE]".equals(data)) break;
                            String piece = parseStreamPiece(data);
                            if (!piece.isEmpty()) {
                                fullAnswer.append(piece);
                                emitNativeEvent(requestId, "chunk", piece);
                            }
                        }
                    }
                }
            } else {
                String jsonText = readAll(stream);
                String content = extractJsonAnswer(jsonText);
                if (!content.isEmpty()) {
                    fullAnswer.append(content);
                    emitNativeEvent(requestId, "chunk", content);
                }
            }
            emitNativeEvent(requestId, "done", fullAnswer.toString());
        } catch (Exception error) {
            emitNativeEvent(requestId, "error", error.getMessage() == null ? "Network request failed." : error.getMessage());
        } finally {
            activeConnections.remove(requestId);
            cancelledRequests.remove(requestId);
            if (connection != null) connection.disconnect();
        }
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        }
        return text.toString();
    }

    private String parseStreamPiece(String data) throws JSONException {
        JSONObject root = new JSONObject(data);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject delta = choice == null ? null : choice.optJSONObject("delta");
        String value = delta == null ? (choice == null ? "" : choice.optString("text", "")) : delta.optString("content", "");
        return value;
    }

    private String extractJsonAnswer(String jsonText) throws JSONException {
        JSONObject root = new JSONObject(jsonText);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject message = choice == null ? null : choice.optJSONObject("message");
        return message == null ? (choice == null ? "" : choice.optString("text", "")) : message.optString("content", "");
    }

    private String extractApiError(String text) {
        try {
            JSONObject root = new JSONObject(text);
            JSONObject error = root.optJSONObject("error");
            return error == null ? root.optString("message", text) : error.optString("message", error.toString());
        } catch (Exception ignored) {
            return text.length() > 500 ? text.substring(0, 500) : text;
        }
    }

    private final class ScAiBridge {
        @JavascriptInterface
        public boolean setSecret(String key, String value) {
            if (!isAllowedSecretKey(key) || value == null) return false;
            try { return writeSecret(key, value); } catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public boolean hasSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            try { String value = readSecret(key); return value != null && !value.isEmpty(); }
            catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public boolean removeSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            return secretPrefs().edit().remove(key).commit();
        }

        @JavascriptInterface
        public void startRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
            if (requestId == null || requestId.length() > 120 || endpoint == null || bodyJson == null) {
                emitNativeEvent(requestId == null ? "" : requestId, "error", "Invalid API request.");
                return;
            }
            networkExecutor.execute(() -> performChatRequest(requestId, endpoint, credentialRef, bodyJson));
        }

        @JavascriptInterface
        public void cancelRequest(String requestId) {
            cancelledRequests.add(requestId);
            HttpURLConnection connection = activeConnections.remove(requestId);
            if (connection != null) connection.disconnect();
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Sc Ai Lab Chat", text == null ? "" : text));
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Sc Ai Lab Chat" : title);
                intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(intent, "分享或保存聊天记录"));
            });
        }

        private boolean isAllowedSecretKey(String key) {
            return key != null && key.startsWith("scailab.provider.key.") && key.length() <= 180;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        for (HttpURLConnection connection : activeConnections.values()) connection.disconnect();
        activeConnections.clear();
        cancelledRequests.clear();
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("ScAiBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
