# Build Sc Ai Lab Chat 0.4.0 from an Android phone

The source archive is named `ScAiLabChat_0.4.0.zip`. Upload this ZIP file to the root of your GitHub repository. Then create or replace `.github/workflows/build-from-zip.yml` with the companion file `BUILD_FROM_ZIP_WORKFLOW_0.4.0.yml` (the same workflow is also supplied separately as `build-from-zip-0.4.0.yml`).

The workflow extracts `ScAiLabChat_Prototype/`, installs Android SDK 35 components, builds `:app:assembleDebug`, verifies the APK signature and package metadata, and uploads the artifact `ScAiLabChat-0.4.0-debug`.

The app version is 0.4.0 / versionCode 4. Its application ID remains `ai.scailab.chat` and local account/chat storage keys are preserved. A development-only signing keystore is included so future builds from this project use a stable signing identity. Keep your GitHub repository private; this development key must never be used for a public or Play Store release.

The first 0.4.0 APK may not update an older 0.2/0.3 APK because those earlier CI builds may have different debug signing certificates. If Android reports a signature conflict, uninstalling the older app may be required, which deletes its local data. The older prototype did not include the new export function, so preserve anything important before uninstalling; after 0.4.0 is installed, later builds using this same project signing key should update in place.
