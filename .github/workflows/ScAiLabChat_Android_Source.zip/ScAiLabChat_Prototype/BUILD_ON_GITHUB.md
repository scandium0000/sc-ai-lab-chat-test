# Build the Android APK without a local Android SDK

The included GitHub Actions workflow builds `app-debug.apk` on a GitHub-hosted Linux runner and uploads the APK as a single file artifact.

1. Create a repository on GitHub.
2. Upload and commit every file from this project ZIP, including the hidden `.github` folder.
3. Push to `main` or `master`, or open the repository's **Actions** tab and manually run **Build Sc Ai Lab Debug APK**.
4. When the workflow finishes successfully, open that run and download the artifact named `app-debug.apk`.
5. Open the downloaded APK on the Android device and install it.

The result is a debug/test build signed by the Android Gradle Plugin's debug signing configuration. It is not a production release APK. The workflow uses GitHub's official hosted-runner Actions and installs Android SDK 35 and Gradle 8.9 during the run.
