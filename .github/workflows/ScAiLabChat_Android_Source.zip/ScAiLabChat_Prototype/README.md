# Sc Ai Lab Chat — Android prototype 0.1.0

A small Android WebView client branded with the revised Sc Ai Lab atom logo. The UI includes local account registration/login, a conversation list, chat history, model selection, Pollinations BYOP device authorization, and text chat through Pollinations' OpenAI-compatible endpoint.

## Current build status

This delivery is an **Android project source ZIP**, not a compiled APK. The preparation container has no Android SDK or Gradle installation, and outbound DNS resolution for the official Gradle / Google Android download hosts is unavailable. Therefore no APK has been compiled or device-tested in this environment.

### Build an APK with GitHub Actions (no local Android SDK required)

A workflow is included at `.github/workflows/build-debug-apk.yml`.

1. Create a GitHub repository and upload the contents of this project ZIP.
2. Push the files to the repository's `main` or `master` branch. The workflow starts automatically; it can also be started from **Actions → Build Sc Ai Lab Debug APK → Run workflow**.
3. Open the completed workflow run and download the `app-debug.apk` artifact. The workflow uploads the single APK file directly rather than wrapping it in another ZIP.
4. Open the downloaded APK on your Android device and install it. Android may ask you to allow installation from the browser or file manager used to open it.

### Build locally with Android Studio

1. Open this folder in a recent Android Studio version with Android SDK 35 installed.
2. Allow Gradle sync and install any prompted SDK components.
3. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The project uses Gradle 8.9; the included CI workflow installs it directly, so a Gradle wrapper JAR is not required for that route.
4. The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Java + Android WebView, AndroidX WebKit, minSdk 26 (Android 8.0), and targetSdk 35. The debug APK is for testing and is not a Play Store release build.

## Pollinations setup

The current Pollinations API requires a user-authorized API key for generation requests. The model directory endpoints are public, but inference requests require authorization. A zero price means a public model is free at the Pollinations layer; it does not mean the generation endpoint can be called without a key.

This prototype uses Pollinations' documented device authorization flow (BYOP):

1. A Sc Ai Lab publisher/developer must create a public App Key (`pk_...`) at `https://enter.pollinations.ai/keys` and configure it for the app.
2. In the app, open Settings and enter that public App Key.
3. Select **Connect Pollinations**. The app asks Pollinations for a device code; open the authorization page and approve access.
4. The resulting short-lived user-authorized bearer key is held in app memory only. It is not written to localStorage. Disconnecting or exiting the app clears it.
5. The app queries `https://gen.pollinations.ai/text/models` and shows only models for which the returned pricing metadata is explicitly all-zero. If the pricing schema is unfamiliar or the directory is unavailable, it fails closed rather than silently selecting a potentially paid model.

The app does not contain a developer `sk_...` secret. The public `pk_...` App Key is configuration, not an inference credential. Users authorize their own Pollinations account and control the associated balance/budget and revocation in Pollinations.

References:
- API docs: https://gen.pollinations.ai/
- BYOP device authorization: https://github.com/pollinations/pollinations/blob/main/BRING_YOUR_OWN_POLLEN.md
- Authentication: https://github.com/pollinations/pollinations/blob/main/gen.pollinations.ai/src/docs/authentication.md

## Local account system and limitations

- Register/login is local to this device. Usernames and PBKDF2-SHA256 password verifiers (210,000 iterations with per-user random salts) are stored in browser local storage.
- This is **not** a cloud account system: no server, email verification, password recovery, or multi-device sync exists in this prototype.
- Conversation text is also stored locally in browser storage and is not encrypted at rest. Do not use real passwords or enter sensitive/personal information into this prototype.
- Pollinations access tokens are memory-only and are cleared on app process exit or disconnect.
- Chat responses are currently non-streaming. The app keeps a bounded recent context window (last 24 messages) when sending a request.
- The free-model filter uses live catalog pricing data and deliberately avoids selecting a model if zero pricing cannot be verified. Model pricing and availability can change.
- This is a prototype. Before public release, replace local accounts with a properly secured backend or a mature identity provider; assess data protection, abuse controls, logging, rate limits, and Android security requirements.

## Project structure

```text
app/
  src/main/
    AndroidManifest.xml
    java/ai/scailab/chat/MainActivity.java
    assets/
      index.html
      styles.css
      app.js
      logo.png
    res/...
```

The UI can also be previewed by opening `app/src/main/assets/index.html` in a browser. Pollinations requests require network connectivity and a correctly configured App Key plus user authorization.
