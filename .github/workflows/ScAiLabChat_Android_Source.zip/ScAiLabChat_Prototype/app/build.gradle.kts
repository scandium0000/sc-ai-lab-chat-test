plugins {
    id("com.android.application")
}

android {
    namespace = "ai.scailab.chat"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.scailab.chat"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
