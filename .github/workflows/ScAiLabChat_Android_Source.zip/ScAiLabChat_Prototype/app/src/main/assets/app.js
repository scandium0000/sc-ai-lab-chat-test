'use strict';

const $ = (id) => document.getElementById(id);
const STORE_USERS = 'scailab.users.v1';
const STORE_SESSION = 'scailab.session.v1';
const STORE_CHATS = 'scailab.chats.v1';
const STORE_APPKEY = 'scailab.pollinations.appkey.v1';
const POLLINATIONS = 'https://gen.pollinations.ai';
const ENTER = 'https://enter.pollinations.ai';
const ITERATIONS = 210000;

let authMode = 'login';
let currentUser = null;
let currentChatId = null;
let chats = [];
let freeModels = [];
let accessToken = null; // Never persisted to localStorage.
let devicePollTimer = null;
let deviceCancelled = false;
let busy = false;
let toastTimer = null;

function safeJsonParse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } }
function getUsers() { return safeJsonParse(localStorage.getItem(STORE_USERS), {}); }
function setUsers(users) { localStorage.setItem(STORE_USERS, JSON.stringify(users)); }
function normaliseUsername(value) { return value.trim().toLowerCase(); }
function validUsername(value) { return /^[a-zA-Z0-9_-]{3,24}$/.test(value); }
function base64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))); }
function fromBase64(value) { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }
function randomBytes(length) { const out = new Uint8Array(length); crypto.getRandomValues(out); return out; }
async function derivePassword(password, salt) {
  if (!crypto.subtle) throw new Error('当前运行环境不支持安全密码摘要，请在 Android 应用或 HTTPS 环境中使用。');
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:ITERATIONS, hash:'SHA-256'}, material, 256);
  return base64(bits);
}

function showToast(message) {
  const toast = $('toast'); toast.textContent = message; toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 3000);
}
function setAuthMode(mode) {
  authMode = mode;
  $('authTitle').textContent = mode === 'login' ? 'Welcome back.' : 'Create your space.';
  $('authSubtitle').textContent = mode === 'login' ? '进入 Sc Ai Lab Chat，开始你的 AI 对话。' : '创建一个保存在本机的 Sc Ai Lab 账户。';
  $('authSubmit').innerHTML = mode === 'login' ? '登录 <span>↗</span>' : '创建账户 <span>↗</span>';
  $('switchPrompt').textContent = mode === 'login' ? '还没有本地账户？' : '已经有账户了？';
  $('switchAuth').textContent = mode === 'login' ? '创建账户' : '返回登录';
  $('confirmWrap').classList.toggle('hidden', mode === 'login');
  $('authPassword').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('authError').textContent = '';
}

$('switchAuth').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'register' : 'login'));
$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const usernameRaw = $('authUsername').value.trim();
  const username = normaliseUsername(usernameRaw);
  const password = $('authPassword').value;
  $('authError').textContent = '';
  if (!validUsername(usernameRaw)) { $('authError').textContent = '用户名需为 3–24 位字母、数字、下划线或连字符。'; return; }
  if (password.length < 10) { $('authError').textContent = '密码至少需要 10 位。请勿重复使用其他网站的密码。'; return; }
  const users = getUsers();
  const key = username;
  const submit = $('authSubmit'); submit.disabled = true;
  try {
    if (authMode === 'register') {
      if (users[key]) { $('authError').textContent = '这个用户名已经存在。'; return; }
      if (password !== $('authConfirm').value) { $('authError').textContent = '两次输入的密码不一致。'; return; }
      const salt = randomBytes(16);
      const hash = await derivePassword(password, salt);
      users[key] = {username: usernameRaw, salt: base64(salt), hash, createdAt: Date.now()};
      setUsers(users);
      localStorage.setItem(STORE_SESSION, key);
      enterApp(usernameRaw);
      showToast('本地账户创建成功');
    } else {
      const record = users[key];
      if (!record) { $('authError').textContent = '没有找到这个本地账户。请先注册。'; return; }
      const hash = await derivePassword(password, fromBase64(record.salt));
      if (hash !== record.hash) { $('authError').textContent = '用户名或密码不正确。'; return; }
      localStorage.setItem(STORE_SESSION, key);
      enterApp(record.username);
    }
  } catch (error) {
    $('authError').textContent = error?.message || '账户操作失败。';
  } finally { submit.disabled = false; }
});

function enterApp(username) {
  currentUser = username;
  $('authView').classList.add('hidden'); $('chatView').classList.remove('hidden');
  $('sidebarUsername').textContent = username; $('userAvatar').textContent = username.slice(0,1).toUpperCase();
  loadChats(); renderConversationList();
  $('appKeyInput').value = localStorage.getItem(STORE_APPKEY) || '';
  loadModels(); updateConnectionState();
  if (chats.length) selectChat(chats[0].id); else createChat();
}
function logOut() {
  currentUser = null; accessToken = null; localStorage.removeItem(STORE_SESSION);
  if (devicePollTimer) clearTimeout(devicePollTimer);
  $('chatView').classList.add('hidden'); $('authView').classList.remove('hidden');
  $('authForm').reset(); setAuthMode('login');
}
$('logoutButton').addEventListener('click', logOut);

function chatStorageKey() { return `${STORE_CHATS}.${normaliseUsername(currentUser || '')}`; }
function loadChats() { chats = safeJsonParse(localStorage.getItem(chatStorageKey()), []); if (!Array.isArray(chats)) chats = []; }
function saveChats() { localStorage.setItem(chatStorageKey(), JSON.stringify(chats)); renderConversationList(); }
function createChat() {
  const chat = {id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), title:'新对话', messages:[], updatedAt:Date.now()};
  chats.unshift(chat); currentChatId = chat.id; saveChats(); renderMessages(); $('welcomePanel').classList.remove('hidden'); $('messages').classList.add('hidden'); $('messageInput').focus(); closeSidebar();
}
function selectChat(id) {
  currentChatId = id; const chat = chats.find(item => item.id === id); if (!chat) return;
  renderConversationList(); renderMessages(); closeSidebar();
}
function activeChat() { return chats.find(item => item.id === currentChatId); }
function renderConversationList() {
  const list = $('conversationList'); list.innerHTML = '';
  for (const chat of chats) {
    const button = document.createElement('button'); button.className = `conversation-item${chat.id === currentChatId ? ' active' : ''}`;
    button.textContent = chat.title || '新对话'; button.title = button.textContent;
    button.addEventListener('click', () => selectChat(chat.id)); list.appendChild(button);
  }
}
function renderMessages() {
  const chat = activeChat(); const messages = $('messages');
  if (!chat || chat.messages.length === 0) { $('welcomePanel').classList.remove('hidden'); messages.classList.add('hidden'); messages.innerHTML = ''; return; }
  $('welcomePanel').classList.add('hidden'); messages.classList.remove('hidden'); messages.innerHTML = '';
  for (const item of chat.messages) appendMessage(item.role, item.content);
  messages.scrollTop = messages.scrollHeight;
}
function appendMessage(role, content, opts = {}) {
  const messages = $('messages');
  const row = document.createElement('article'); row.className = `message ${role}`;
  const avatar = document.createElement('div'); avatar.className = 'message-avatar'; avatar.textContent = role === 'assistant' ? 'SC' : (currentUser || 'U').slice(0,1).toUpperCase();
  const bodyWrap = document.createElement('div'); bodyWrap.className = 'message-content';
  const label = document.createElement('div'); label.className = 'message-role'; label.textContent = role === 'assistant' ? 'SC AI LAB' : 'YOU';
  const body = document.createElement('div'); body.className = `message-body${opts.error ? ' error' : ''}`;
  if (opts.typing) { body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>'; }
  else body.textContent = content;
  bodyWrap.append(label, body); row.append(avatar, bodyWrap); messages.appendChild(row); messages.scrollTop = messages.scrollHeight;
  return {row, body};
}
$('newChat').addEventListener('click', createChat);
$('suggestionGrid');
document.querySelectorAll('.suggestion-card').forEach(button => button.addEventListener('click', () => { $('messageInput').value = button.dataset.prompt || ''; $('messageInput').focus(); autoResize(); }));

function setBusy(value) { busy = value; $('sendButton').disabled = value; $('messageInput').disabled = value; }
$('composer').addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = $('messageInput').value.trim();
  if (!text || busy) return;
  if (!accessToken) { showToast('请先在设置中连接 Pollinations。'); openSettings(); return; }
  const modelId = $('modelSelect').value;
  if (!modelId || !freeModels.some(item => item.id === modelId)) { showToast('当前没有已确认零价格的文本模型。'); openSettings(); return; }
  let chat = activeChat(); if (!chat) { createChat(); chat = activeChat(); }
  chat.messages.push({role:'user', content:text});
  if (chat.messages.length === 1) chat.title = text.slice(0,32) || '新对话';
  $('messageInput').value = ''; autoResize(); saveChats();
  renderMessages(); const pending = appendMessage('assistant', '', {typing:true}); setBusy(true);
  try {
    const response = await fetch(`${POLLINATIONS}/v1/chat/completions`, {
      method:'POST',
      headers:{'Authorization':`Bearer ${accessToken}`, 'Content-Type':'application/json'},
      body:JSON.stringify({model:modelId, messages:chat.messages.slice(-24).map(m => ({role:m.role, content:m.content})), stream:false})
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload?.error?.message || payload?.message || `Pollinations 请求失败（HTTP ${response.status}）。`);
    const answer = payload?.choices?.[0]?.message?.content ?? payload?.choices?.[0]?.text ?? '';
    if (typeof answer !== 'string' || !answer.trim()) throw new Error('模型没有返回可显示的文本。');
    pending.row.remove(); chat.messages.push({role:'assistant', content:answer.trim()}); saveChats(); appendMessage('assistant', answer.trim());
  } catch (error) {
    pending.row.remove();
    const message = `${error?.message || '请求失败。'}\n\n请检查授权是否仍有效、账户额度以及所选模型状态。`;
    chat.messages.push({role:'assistant', content:message}); saveChats(); appendMessage('assistant', message, {error:true});
  } finally { setBusy(false); $('messageInput').focus(); }
});
function autoResize() { const input = $('messageInput'); input.style.height = 'auto'; input.style.height = `${Math.min(input.scrollHeight,150)}px`; }
$('messageInput').addEventListener('input', autoResize);
$('messageInput').addEventListener('keydown', event => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); $('composer').requestSubmit(); } });

function openSettings() { $('settingsModal').classList.remove('hidden'); }
function closeSettings() { $('settingsModal').classList.add('hidden'); }
$('settingsButton').addEventListener('click', openSettings); $('topSettings').addEventListener('click', openSettings);
$('closeSettings').addEventListener('click', closeSettings); $('doneSettings').addEventListener('click', closeSettings);
$('settingsModal').addEventListener('click', event => { if (event.target === $('settingsModal')) closeSettings(); });
$('appKeyInput').addEventListener('change', () => localStorage.setItem(STORE_APPKEY, $('appKeyInput').value.trim()));
$('disconnectButton').addEventListener('click', () => { accessToken = null; deviceCancelled = true; updateConnectionState(); showToast('已断开 Pollinations 连接。'); });

async function loadModels() {
  $('modelStatus').textContent = '正在获取 Pollinations 实时文本模型目录…';
  $('modelSelect').innerHTML = '<option>正在加载…</option>';
  try {
    const response = await fetch(`${POLLINATIONS}/text/models`, {headers:{'Accept':'application/json'}});
    if (!response.ok) throw new Error(`目录请求失败（HTTP ${response.status}）`);
    const raw = await response.json();
    const entries = Array.isArray(raw) ? raw : (raw.data || raw.models || raw.results || []);
    freeModels = entries.map(entry => ({id:entry.id || entry.name || entry.model || entry.slug, label:entry.name || entry.title || entry.id || entry.model, raw:entry}))
      .filter(item => item.id && isExplicitlyFree(item.raw));
    const select = $('modelSelect'); select.innerHTML = '';
    if (!freeModels.length) {
      select.innerHTML = '<option value="">当前没有检测到零价格文本模型</option>';
      $('modelStatus').textContent = '目录中没有返回明确标记为零价格的文本模型。为避免误选付费模型，暂不自动选择。';
      $('selectedModelLabel').textContent = '未找到免费模型'; return;
    }
    freeModels.sort((a,b) => String(a.label).localeCompare(String(b.label)));
    for (const item of freeModels) { const option = document.createElement('option'); option.value = item.id; option.textContent = `${item.label} · FREE`; select.appendChild(option); }
    $('modelStatus').textContent = `已找到 ${freeModels.length} 个明确零价格的文本模型。列表以实时目录为准。`;
    updateSelectedModelLabel();
  } catch (error) {
    freeModels = []; $('modelSelect').innerHTML = '<option value="">无法加载模型目录</option>';
    $('modelStatus').textContent = `${error.message}。请检查网络后刷新。`;
    $('selectedModelLabel').textContent = '目录不可用';
  }
}
function isExplicitlyFree(model) {
  const candidates = [];
  const addNumericLeaves = (value) => {
    if (typeof value === 'number' && Number.isFinite(value)) candidates.push(value);
    else if (Array.isArray(value)) value.forEach(addNumericLeaves);
    else if (value && typeof value === 'object') Object.entries(value).forEach(([key,val]) => {
      if (/price|pricing|cost|pollen|token|input|output|prompt|completion/i.test(key)) addNumericLeaves(val);
      else if (val && typeof val === 'object') addNumericLeaves(val);
    });
  };
  if ('pricing' in model) addNumericLeaves(model.pricing);
  if ('price' in model) addNumericLeaves(model.price);
  if ('input_price' in model) addNumericLeaves(model.input_price);
  if ('output_price' in model) addNumericLeaves(model.output_price);
  if ('cost' in model) addNumericLeaves(model.cost);
  if ('pollen' in model) addNumericLeaves(model.pollen);
  return candidates.length > 0 && candidates.every(value => value === 0);
}
$('refreshModels').addEventListener('click', loadModels);
$('modelSelect').addEventListener('change', updateSelectedModelLabel);
function updateSelectedModelLabel() { const option = $('modelSelect').selectedOptions[0]; $('selectedModelLabel').textContent = option?.value ? option.textContent : '未选择免费模型'; }

async function connectPollinations() {
  const appKey = $('appKeyInput').value.trim();
  if (!appKey.startsWith('pk_')) { showToast('请先填入 Pollinations App Key（pk_…）。'); return; }
  localStorage.setItem(STORE_APPKEY, appKey);
  if (devicePollTimer) clearTimeout(devicePollTimer);
  deviceCancelled = false; $('connectButton').disabled = true; $('connectButton').textContent = '正在启动授权…';
  $('devicePanel').classList.remove('hidden'); $('deviceStatus').textContent = '正在向 Pollinations 请求设备授权码…';
  try {
    const response = await fetch(`${ENTER}/api/device/code`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({client_id:appKey})});
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error_description || payload.error || `HTTP ${response.status}`);
    if (!payload.device_code || !payload.user_code) throw new Error('授权服务未返回完整设备代码。');
    $('deviceCode').textContent = payload.user_code;
    const verification = payload.verification_uri ? new URL(payload.verification_uri, ENTER).href : `${ENTER}/device`;
    $('deviceLink').href = verification;
    $('deviceStatus').textContent = '请打开授权页面并输入上方代码。授权完成后，本应用会自动连接。';
    pollDeviceToken(payload.device_code, appKey, Date.now() + 12*60*1000);
  } catch (error) {
    $('deviceStatus').textContent = `启动失败：${error.message}`;
    showToast('无法启动 Pollinations 授权。');
  } finally {
    $('connectButton').disabled = false; $('connectButton').textContent = '重新连接 ↗';
  }
}
function pollDeviceToken(deviceCode, appKey, deadline) {
  const poll = async () => {
    if (deviceCancelled || Date.now() > deadline) { $('deviceStatus').textContent = deviceCancelled ? '授权已取消。' : '授权等待超时，请重新开始。'; return; }
    try {
      const response = await fetch(`${ENTER}/api/device/token`, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({device_code:deviceCode})});
      const payload = await response.json().catch(() => ({}));
      if (response.ok && payload.access_token) {
        accessToken = payload.access_token; // Memory only; never persist the bearer token.
        $('deviceStatus').textContent = '授权成功。你可以关闭此窗口并开始对话。';
        updateConnectionState(); showToast('Pollinations 已连接。'); return;
      }
      const error = payload.error || '';
      if (error === 'authorization_pending' || response.status === 400 || response.status === 428) {
        $('deviceStatus').textContent = '等待你在浏览器中确认授权…';
      } else if (error === 'slow_down') {
        $('deviceStatus').textContent = '授权服务要求降低轮询频率，正在稍后重试…';
        devicePollTimer = setTimeout(poll, 8000); return;
      } else if (error) throw new Error(payload.error_description || error);
      else if (!response.ok) throw new Error(payload.error_description || `HTTP ${response.status}`);
    } catch (error) {
      $('deviceStatus').textContent = `授权检查失败：${error.message}`; return;
    }
    devicePollTimer = setTimeout(poll, 5000);
  };
  devicePollTimer = setTimeout(poll, 5000);
}
$('connectButton').addEventListener('click', connectPollinations);
$('cancelDevice').addEventListener('click', () => { deviceCancelled = true; if (devicePollTimer) clearTimeout(devicePollTimer); $('deviceStatus').textContent = '已取消。'; });
function updateConnectionState() {
  const pill = $('connectionLabel'); pill.classList.toggle('connected', !!accessToken);
  pill.innerHTML = accessToken ? '<i></i> Connected' : '<i></i> Not connected';
  $('apiStatus').textContent = accessToken ? '已授权' : '未授权';
  $('disconnectButton').classList.toggle('hidden', !accessToken);
  $('apiHint').textContent = accessToken ? '连接已建立。选择一个零价格文本模型即可开始对话。' : '需要先在「设置」中配置 Pollinations App Key 并完成授权。';
}

$('clearLocalData').addEventListener('click', () => {
  const ok = confirm('确定清除这台设备上的所有 Sc Ai Lab 本地账户和聊天记录吗？此操作无法撤销。');
  if (!ok) return;
  localStorage.removeItem(STORE_USERS); localStorage.removeItem(STORE_SESSION);
  for (const key of Object.keys(localStorage)) if (key.startsWith(STORE_CHATS + '.')) localStorage.removeItem(key);
  accessToken = null; closeSettings(); logOut(); showToast('本地账户与聊天记录已清除。');
});

function openSidebar() { $('sidebar').classList.add('open'); }
function closeSidebar() { $('sidebar').classList.remove('open'); }
$('openSidebar').addEventListener('click', openSidebar); $('closeSidebar').addEventListener('click', closeSidebar);

(function boot() {
  setAuthMode('login');
  const saved = localStorage.getItem(STORE_SESSION);
  if (saved) {
    const account = getUsers()[saved];
    if (account) enterApp(account.username); else localStorage.removeItem(STORE_SESSION);
  }
})();
