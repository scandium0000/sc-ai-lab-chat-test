# Sc Chat 0.9.0 — Sc Reasoning Engine

## Added
- Composer selector for Off, Native Reasoning, and Sc Reasoning Engine.
- Per-account reasoning amount: Light, Standard, and Deep.
- Native `reasoning_effort` mapping: low / medium / high, gated by declared model capability.
- Automatic fallback to Sc Reasoning Engine when a provider rejects the native reasoning parameter.
- Multi-stage API orchestration with two, three, or four passes depending on the selected amount.
- Local aggregate token estimates and API-call counting for each multi-stage turn.
- Approximate token-use multiplier display and explanations of estimate limitations.
- Regression tests for the stage pipeline and mode/level wiring.

## Technical boundaries
- Sc Reasoning Engine uses structured multi-stage requests. It does not control a remote model's live token decoder or suppress EOS / reasoning-end tokens.
- Token-use multipliers are rough estimates; provider usage data remains authoritative.
- Image-token usage and hidden native reasoning tokens may not be visible to local estimation.

## Compatibility
- Application ID remains `ai.scailab.chat`.
- Version code: 14.
- Version name: 0.9.0.
- Minimum Android API: 26.
