# Sc Chat 0.7.1 — UI Interaction Hotfix

## Fixed
- IME layout is now scoped to the main chat composer only. Keyboard activity in assistant, account, settings, or project dialogs no longer applies the chat-composer layout.
- Opening an account, assistant, or settings overlay dismisses stale focus from the chat composer and closes the mobile navigation drawer.
- Modal backdrops render above the mobile navigation drawer, preventing profile and settings dialogs from being hidden behind it.
- Assistant management now explicitly releases the chat composer focus before showing the assistant editor.

## Preserved
- Provider management center, per-model capability settings, model catalog tests, usage estimates, and budget reminders.
- Local accounts, conversations, projects, personal assistants, file library, Pollinations integration, and custom providers.
- Application ID `ai.scailab.chat`, local storage namespace `scailab.*`, and development signing key.

## Validation
- JavaScript syntax check.
- Provider logic regression tests.
- UI regression tests for IME isolation, modal focus isolation, drawer navigation, and overlay stacking.
- HTML ID/reference validation.
- Android XML parsing.
- ZIP integrity validation.

APK compilation and physical-device behavior still require GitHub Actions and Android device testing.

## Version
- `versionCode`: 10
- `versionName`: 0.7.1
