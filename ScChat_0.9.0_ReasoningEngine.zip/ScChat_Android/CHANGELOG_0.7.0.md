# Sc Chat 0.7.0 — Provider Management Center

## Added
- Provider management dashboard with add, edit, remove, and default-provider actions.
- Authenticated HTTPS `GET /models` connection test through the native Android bridge.
- Model catalog discovery with manual model-ID fallback.
- Per-model Vision and Streaming flags.
- Per-model context-window metadata.
- Per-model input/output prices (USD per one million tokens).
- Local monthly usage ledger that stores metadata only.
- Approximate text-token usage and estimated cost display.
- Configurable monthly budget warning threshold.
- Node-based unit tests for endpoint validation, model parsing, model capabilities, cost calculations, budget thresholds, and text-only token estimates.
- HTML-to-JavaScript DOM reference validation.

## Changed
- Non-streaming OpenAI-compatible providers can send `stream: false`.
- Default provider preference is applied when the app session starts.
- Custom provider top-bar state distinguishes API reachability from merely having a saved key.
- Usage estimates are recorded against the local account active when a request starts.

## Preserved
- Application ID: `ai.scailab.chat`.
- Local storage namespace: `scailab.*`.
- Development signing keystore from 0.6.1.
- Local account, chats, projects, assistants, file library, Pollinations flow, blue theme, and Android keyboard/system-inset handling.

## Limitations
- Token and cost figures are heuristics, not provider billing data.
- Image/vision token usage is excluded from local text-token estimates.
- Budget warnings do not block requests or enforce provider spending limits.
- Some providers do not expose `/models`; manual model IDs remain available.
- Android APK compilation and physical-device validation must be completed by GitHub Actions and device testing.

## Version
- `versionCode`: 9
- `versionName`: 0.7.0
