# Build Sc Chat 0.9.0 from an Android phone

1. Upload `ScChat_0.9.0_ReasoningEngine.zip` to the root of your private GitHub repository.
2. Copy `build-from-zip-0.9.0.yml` to `.github/workflows/build-from-zip.yml`.
3. Open **Actions** and run **Build Sc Chat 0.9.0 APK**.
4. Open the completed workflow run and download `ScChat-0.9.0-debug`.

Keep the repository private because the project contains a development-only signing key. Never use the development key for a public release.
