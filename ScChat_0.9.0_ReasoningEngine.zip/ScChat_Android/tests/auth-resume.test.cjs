const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/ai/scailab/chat/MainActivity.java'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');

assert.match(java, /public boolean setSecret\(String key, String value\)/, 'Android must save encrypted credentials.');
assert.match(java, /public boolean hasSecret\(String key\)/, 'The UI must be able to test whether a token exists without reading it.');
assert.match(java, /public String getSecret\(String key\)[\s\S]*?if \(!"scailab\.oauth\.pollinations\.pending_device"\.equals\(key\)\) return "";/,
  'JavaScript may only read the pending device-flow checkpoint, never the Pollinations access token.');
assert.match(java, /"scailab\.oauth\.pollinations\.access_token"\.equals\(key\)/, 'The Pollinations access token must be an allowed encrypted secret.');
assert.match(java, /"scailab\.oauth\.pollinations\.pending_device"\.equals\(key\)/, 'The pending device flow must be an allowed encrypted secret.');
assert.match(java, /boolean allowedPollinationsToken = "scailab\.oauth\.pollinations\.access_token"\.equals\(key\)/, 'The native credential resolver must only read the Pollinations token from the expected key.');
assert.match(java, /if \(!allowedProviderKey && !allowedPollinationsToken\)/, 'Unrecognized encrypted preference names must not be usable as request credentials.');
assert.match(java, /protected void onResume\(\)[\s\S]*?__scaiNativeResume/, 'Android foregrounding must notify JavaScript to resume authorization polling.');
assert.match(java, /public void onPageFinished\(WebView view, String url\)[\s\S]*?__scaiNativeResume/, 'A newly restored WebView runtime must resume pending authorization.');

assert.match(app, /function persistPendingDeviceAuthorization\(pending\)/, 'Pending authorization state must be persisted.');
assert.match(app, /POLLINATIONS_PENDING_SECRET, serialized/, 'The device code and expiry must be stored in Android Keystore.');
assert.match(app, /function restorePollinationsAuthorization\(\)/, 'App startup must restore the pending authorization.');
assert.match(app, /function resumePendingDeviceAuthorization\(\)/, 'Foreground return must resume the pending device flow.');
assert.match(app, /function hasPollinationsAuthorization\(\)/, 'The UI must determine connection state without exposing the token.');
assert.match(app, /secret:\$\{POLLINATIONS_TOKEN_SECRET\}/, 'Native generation requests must resolve the token inside Java.');
assert.doesNotMatch(app, /literal:\$\{accessToken\}/, 'The access token must not be copied into JavaScript-to-native request arguments.');
assert.match(app, /setPollinationsSecret\(POLLINATIONS_TOKEN_SECRET,payload\.access_token\)/, 'The granted user token must be persisted in Android Keystore.');
assert.match(app, /removePollinationsSecret\(POLLINATIONS_TOKEN_SECRET\)/, 'Disconnect and clear-data flows must remove the encrypted token.');

console.log('Authorization recovery tests passed: pending device flow survives process recreation and access tokens stay in Android Keystore.');
