const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const appSource = fs.readFileSync(path.join(__dirname, '../app/src/main/assets/app.js'), 'utf8');
function extractFunction(name, nextName) {
  const start = appSource.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `Missing function ${name}`);
  const end = appSource.indexOf(`\nfunction ${nextName}(`, start);
  assert.notEqual(end, -1, `Could not locate end marker ${nextName} for ${name}`);
  return appSource.slice(start, end);
}
function run(code, expression) {
  const context = { URL, Set, Math, Number, String, Array, JSON, Intl };
  vm.createContext(context);
  vm.runInContext(`${code}\nglobalThis.__result = ${expression};`, context);
  return context.__result;
}

const finiteOrNull = run(extractFunction('finiteOrNull', 'providerCredentialReady'), 'finiteOrNull');
assert.equal(finiteOrNull('1.25'), 1.25);
assert.equal(finiteOrNull('0'), 0);
assert.equal(finiteOrNull(''), null);
assert.equal(finiteOrNull('-1'), null);
assert.equal(finiteOrNull('not-a-number'), null);

const endpointCode = extractFunction('modelsEndpoint', 'setDefaultProvider');
const modelsEndpoint = run(endpointCode, 'modelsEndpoint');
assert.equal(modelsEndpoint('https://api.example.com/v1'), 'https://api.example.com/v1/models');
assert.equal(modelsEndpoint('https://api.example.com/v1/'), 'https://api.example.com/v1/models');
assert.equal(modelsEndpoint('https://api.example.com/v1/chat/completions'), 'https://api.example.com/v1/models');
assert.equal(modelsEndpoint('https://api.example.com/v1/models'), 'https://api.example.com/v1/models');
assert.throws(() => modelsEndpoint('http://api.example.com/v1'), /HTTPS/);
assert.throws(() => modelsEndpoint('https://user:pass@api.example.com/v1'), /HTTPS/);

const safeJsonParse = 'function safeJsonParse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } }';
const parseModelIds = run(safeJsonParse + '\n' + extractFunction('parseModelIds', 'modelsEndpoint'), 'parseModelIds');
assert.deepEqual(Array.from(parseModelIds('{"data":[{"id":"alpha"},{"id":"beta"}]}')), ['alpha', 'beta']);
assert.deepEqual(Array.from(parseModelIds('["gamma","delta"]')), ['gamma', 'delta']);
assert.deepEqual(Array.from(parseModelIds('{"data":{}}')), []);

const estimateTokens = run(extractFunction('estimateTokens', 'estimatePromptTokens'), 'estimateTokens');
assert.ok(estimateTokens('Hello, world!') > 0);
assert.ok(estimateTokens('你好，Sc Chat！') >= 5);
const estimatePromptTokens = run(
  extractFunction('estimateTokens', 'estimatePromptTokens') + '\n' + extractFunction('estimatePromptTokens', 'formatCompact'),
  'estimatePromptTokens'
);
const withTextAndImage = estimatePromptTokens([{ role: 'user', content: [
  { type: 'text', text: '请分析这张图片' },
  { type: 'image_url', image_url: { url: 'data:image/png;base64,' + 'A'.repeat(12000) } }
]}]);
assert.ok(withTextAndImage > 0 && withTextAndImage < 100, 'Image Base64 must not inflate text-token estimates');

console.log('Provider logic tests passed: URL validation, price parsing, model list parsing, per-model capabilities, budget warnings, and text-only usage estimation.');

const costCode = extractFunction('estimateCostUsd', 'formatCompact');
const estimateCostUsd = run(costCode, 'estimateCostUsd');
assert.equal(estimateCostUsd(100000, 50000, 1, 2), 0.2);
assert.equal(estimateCostUsd(100000, 50000, 0, 0), 0);
assert.equal(estimateCostUsd(100000, 50000, 1, null), null);
const budgetCode = extractFunction('isBudgetWarning', 'formatCompact');
const isBudgetWarning = run(budgetCode, 'isBudgetWarning');
assert.equal(isBudgetWarning(8, 10, 80), true);
assert.equal(isBudgetWarning(7.99, 10, 80), false);
assert.equal(isBudgetWarning(1, 0, 80), false);
const capabilityCode = extractFunction('finiteOrNull', 'providerCredentialReady') + '\n' + extractFunction('getModelCapabilities', 'selectedProviderSupportsVision');
const getModelCapabilities = run(capabilityCode, 'getModelCapabilities');
const provider = { model: 'vision-model', supportsVision: true, supportsStreaming: false, supportsReasoning: true, priceInputPerMillion: 3, priceOutputPerMillion: 4 };
assert.equal(getModelCapabilities(provider).supportsVision, true);
assert.equal(getModelCapabilities(provider).supportsStreaming, false);
assert.equal(getModelCapabilities(provider).supportsReasoning, true);
assert.equal(getModelCapabilities(provider, 'text-model').supportsVision, false);
assert.equal(getModelCapabilities(provider, 'text-model').supportsStreaming, true);
assert.equal(getModelCapabilities(provider, 'text-model').supportsReasoning, false, 'Unregistered models must not be assumed to support reasoning.');
assert.equal(getModelCapabilities(provider).priceInputPerMillion, 3);
assert.equal(getModelCapabilities(provider, 'text-model').priceInputPerMillion, null);
