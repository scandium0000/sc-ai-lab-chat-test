const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/ai/scailab/chat/MainActivity.java'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');

assert.match(java, /protected void onPause\(\)[\s\S]*?webView\.onPause\(\)/, 'Activity must pause WebView when backgrounded.');
assert.match(java, /protected void onResume\(\)[\s\S]*?webView\.onResume\(\)/, 'Activity must resume the existing WebView without recreating it.');
assert.match(java, /protected void onSaveInstanceState\(Bundle outState\)[\s\S]*?webView\.saveState\(outState\)/, 'WebView navigation state must be saved.');
assert.match(java, /webView\.restoreState\(savedInstanceState\)/, 'Saved WebView state must be restored before the initial load.');
assert.match(java, /onRenderProcessGone\(WebView view, RenderProcessGoneDetail detail\)/, 'Renderer termination must be handled explicitly.');
assert.match(java, /if \(activityResumed\) recreate\(\);\s*else rendererRecoveryPending = true;/, 'Renderer failure must be deferred while the Activity is in the background.');
assert.match(java, /if \(rendererRecoveryPending && !isFinishing\(\)\)[\s\S]*?recreate\(\)/, 'A pending renderer recovery should run when the Activity returns to the foreground.');
const onResumeBody = java.match(/protected void onResume\(\)\s*\{([\s\S]*?)\n    \}/)?.[1] || '';
assert.doesNotMatch(onResumeBody, /loadUrl\(/, 'Returning from background must not unconditionally reload the app.');

assert.match(app, /const STORE_UI_STATE = 'scailab\.uiState\.v1'/, 'A per-account UI checkpoint key must exist.');
assert.match(app, /function persistAppUiState\(\)/, 'Workspace state must be persisted.');
assert.match(app, /document\.addEventListener\('visibilitychange'/, 'Workspace state must be checkpointed when the app becomes hidden.');
assert.match(app, /window\.addEventListener\('pagehide'/, 'Workspace state must be checkpointed on page hide.');
assert.match(app, /currentChatId,\s*page: activeWorkspacePage,\s*openProjectId,\s*selectedProviderId,\s*activeAssistantId/, 'Checkpoint must include the active conversation and workspace.');
assert.match(app, /const savedUi = readAppUiState\(\)/, 'Startup must read the saved workspace checkpoint.');
assert.match(app, /const savedChat = chats\.find\(item => item\.id === savedUi\?\.currentChatId\)/, 'Startup must restore the previous conversation when it still exists.');
assert.match(app, /createChat\(null, \{focus:false\}\)/, 'Cold restore must not unexpectedly open the keyboard.');

console.log('Lifecycle regression tests passed: WebView pause/resume, state restore, renderer recovery, and workspace checkpointing.');
