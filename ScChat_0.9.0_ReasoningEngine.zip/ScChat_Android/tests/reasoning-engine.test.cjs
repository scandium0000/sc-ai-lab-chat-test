const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const app = fs.readFileSync(path.join(__dirname, '..', 'app/src/main/assets/app.js'), 'utf8');
const start = app.indexOf('function withReasoningSystemInstruction(');
const end = app.indexOf('\nasync function dispatchModelRequest(', start);
assert.ok(start >= 0 && end > start, 'Reasoning Engine helpers must exist.');

const context = {
  estimatePromptTokens: messages => JSON.stringify(messages).length,
  estimateTokens: value => String(value).length
};
vm.createContext(context);
vm.runInContext(`${app.slice(start, end)}\nthis.runReasoningEngine = runReasoningEngine;`, context);

(async () => {
  for (const [level, expectedCalls] of [['light', 2], ['standard', 3], ['deep', 4]]) {
    let calls = 0;
    const stages = [];
    let finalStream = '';
    const result = await context.runReasoningEngine(
      [{role:'user', content:'Solve a representative algebra problem.'}],
      level,
      async messages => {
        calls += 1;
        assert.ok(messages.length >= 2, 'Each stage must contain the original task and its instructions.');
        return `stage-${calls} result`;
      },
      chunk => { finalStream += chunk; },
      stage => stages.push(stage)
    );
    assert.equal(calls, expectedCalls, `${level} must use ${expectedCalls} stages.`);
    assert.equal(result.usage.apiCalls, expectedCalls);
    assert.equal(result.answer, `stage-${expectedCalls} result`);
    assert.equal(stages.length, expectedCalls);
    assert.ok(result.usage.inputTokens > 0 && result.usage.outputTokens > 0);
  }
  console.log('Sc Reasoning Engine tests passed: light/standard/deep stage counts, usage accounting, and final-answer routing.');
})().catch(error => { console.error(error); process.exitCode = 1; });
