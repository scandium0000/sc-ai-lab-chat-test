const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'app/src/main/assets/styles.css'), 'utf8');

function extract(name, nextName) {
  const start = app.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `Missing ${name}`);
  const end = app.indexOf(`\nfunction ${nextName}(`, start);
  assert.notEqual(end, -1, `Missing boundary ${nextName}`);
  return app.slice(start, end);
}

// Execute the actual modal/IME decision functions with a tiny DOM substitute.
const ids = ['messageInput', 'accountModal', 'assistantModal', 'settingsModal', 'projectModal'];
const elements = Object.fromEntries(ids.map(id => [id, {
  id,
  classList: { contains: cls => elements[id].visible && cls === 'hidden' ? false : cls === 'hidden' },
  blur() {}
}]));
let imeClass = false;
const document = {
  activeElement: elements.messageInput,
  addEventListener() {},
  body: { classList: {
    toggle(name, value) { if (name === 'ime-visible') imeClass = !!value; },
    remove(name) { if (name === 'ime-visible') imeClass = false; }
  } }
};
const code = [
  extract('hasBlockingModalOpen', 'shouldApplyComposerIme'),
  extract('shouldApplyComposerIme', 'dismissComposerFocus'),
  extract('updateComposerImeOwnership', 'handleGlobalFocusIn'),
  extract('handleGlobalFocusIn', 'setImeVisible'),
  extract('setImeVisible', 'autoResize')
].join('\n');
const testCode = `let nativeImeVisible = false;\n${code}`;
const context = {
  document,
  window: {},
  $: id => elements[id],
  blockingModalIds: ['accountModal', 'assistantModal', 'settingsModal', 'projectModal'],
  requestAnimationFrame: callback => callback(),
  syncAppViewport() {},
  keepComposerVisible() {}
};
vm.createContext(context);
vm.runInContext(`${testCode}\nsetImeVisible(true);`, context);
assert.equal(imeClass, true, 'Chat input should own IME when it is focused and no modal is open.');

elements.assistantModal.visible = true;
vm.runInContext(`setImeVisible(true);`, context);
assert.equal(imeClass, false, 'Assistant modal must not activate the chat composer IME layout.');

elements.assistantModal.visible = false;
document.activeElement = { id: 'assistantNameInput' };
vm.runInContext(`setImeVisible(true);`, context);
assert.equal(imeClass, false, 'Assistant editor fields must not move the chat composer.');

document.activeElement = elements.messageInput;
elements.settingsModal.visible = true;
vm.runInContext(`setImeVisible(true);`, context);
assert.equal(imeClass, false, 'Settings modal must not activate the chat composer IME layout.');


elements.settingsModal.visible = false;
elements.accountModal.visible = true;
document.activeElement = { id: 'nicknameInput' };
vm.runInContext(`handleGlobalFocusIn({target: document.activeElement}); setImeVisible(true);`, context);
assert.equal(imeClass, false, 'Profile and account form fields must never move the main chat composer.');

elements.accountModal.visible = false;
document.activeElement = elements.messageInput;
vm.runInContext(`setImeVisible(true);`, context);
assert.equal(imeClass, true, 'Chat composer should regain IME layout after account modal closes and it owns focus.');

// Opening overlays from the mobile drawer must close the drawer before presenting them.
for (const fn of ['openAccount', 'openAssistants', 'openSettings']) {
  const match = app.match(new RegExp(`function ${fn}\\([\\s\\S]*?\\n\\}`));
  assert.ok(match, `Missing ${fn}`);
  assert.match(match[0], /closeSidebar\(\)/, `${fn} must close the navigation drawer.`);
  assert.match(match[0], /dismissComposerFocus\(\)/, `${fn} must dismiss stale chat-input focus.`);
}

const modalRule = css.match(/\.modal-backdrop\s*\{[^}]*z-index\s*:\s*(\d+)/);
const sidebarRule = css.match(/@media\s*\(max-width:\s*620px\)[\s\S]*?\.sidebar\s*\{[^}]*z-index\s*:\s*(\d+)/);
assert.ok(modalRule && sidebarRule, 'Could not find modal/sidebar stacking rules.');
assert.ok(Number(modalRule[1]) > Number(sidebarRule[1]), 'Dialogs must render above the mobile navigation drawer.');

console.log('UI regression tests passed: composer IME isolation, modal focus isolation, drawer navigation, and overlay stacking.');
