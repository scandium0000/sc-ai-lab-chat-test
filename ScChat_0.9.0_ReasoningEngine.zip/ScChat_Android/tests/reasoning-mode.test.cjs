const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const root = path.join(__dirname, '..');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'app/src/main/assets/index.html'), 'utf8');
const css = fs.readFileSync(path.join(root, 'app/src/main/assets/styles.css'), 'utf8');

function sliceBetween(startMarker, endMarker) {
  const start = app.indexOf(startMarker);
  assert.notEqual(start, -1, `Missing ${startMarker}`);
  const end = app.indexOf(endMarker, start);
  assert.notEqual(end, -1, `Missing ${endMarker}`);
  return app.slice(start, end);
}

const capabilityCode = sliceBetween('function inferReasoningCapability(', '\nfunction selectedProviderSupportsReasoning(');
const requestCode = sliceBetween('function reasoningEffortValue(', '\nfunction updateReasoningControl(');
const context = {};
vm.createContext(context);
vm.runInContext(`${capabilityCode}\n${requestCode}\nthis.inferReasoningCapability = inferReasoningCapability; this.buildReasoningRequestBody = buildReasoningRequestBody; this.reasoningEstimate = reasoningEstimate; this.isNativeReasoningParameterError = isNativeReasoningParameterError;`, context);

assert.equal(context.inferReasoningCapability({supported_parameters:['temperature','reasoning_effort']}), true);
assert.equal(context.inferReasoningCapability({supported_parameters:['temperature']}), false);
assert.equal(context.inferReasoningCapability({supports_reasoning:true}), true);
assert.equal(context.inferReasoningCapability({}), false, 'Unknown model capability must default to unsupported.');

assert.equal(context.buildReasoningRequestBody({model:'sample'}, 'off', true).reasoning_effort, undefined);
assert.equal(context.buildReasoningRequestBody({model:'sample'}, 'native', true, 'light').reasoning_effort, 'low');
assert.equal(context.buildReasoningRequestBody({model:'sample'}, 'native', true, 'standard').reasoning_effort, 'medium');
assert.equal(context.buildReasoningRequestBody({model:'sample'}, 'native', true, 'deep').reasoning_effort, 'high');
assert.equal(context.buildReasoningRequestBody({model:'sample'}, 'native', false, 'deep').reasoning_effort, undefined, 'Unsupported models must not receive native reasoning parameters.');
assert.equal(context.isNativeReasoningParameterError(new Error('Unknown parameter reasoning_effort')), true);
assert.equal(context.isNativeReasoningParameterError(new Error('Network timeout')), false);
assert.equal(context.reasoningEstimate('off', 'standard'), '约 1.0×');
assert.equal(context.reasoningEstimate('engine', 'deep'), '约 4–6×');

assert.match(html, /id="reasoningToggle"/, 'Composer must expose the reasoning selector.');
assert.match(html, /id="reasoningModeSelect"/, 'Composer must expose reasoning modes.');
assert.match(html, /id="reasoningLevelSelect"/, 'Composer must expose reasoning intensity.');
assert.match(html, /id="reasoningEstimate"/, 'Composer must expose estimated token multiplier.');
assert.match(html, /Sc Reasoning Engine/);
assert.match(css, /\.reasoning-panel/);
assert.match(app, /reasoningModeStorageKey\(\)/);
assert.match(app, /STORE_REASONING_MODE_LEGACY/);
assert.match(app, /apiCalls:Math\.max/);

console.log('Reasoning mode tests passed: capability gating, native effort mapping, mode/level estimates, composer UI, preference migration, and multi-call metering.');
