from html.parser import HTMLParser
from pathlib import Path
import re
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
js = (ROOT / 'app/src/main/assets/app.js').read_text(encoding='utf-8')

class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])

parser = IdParser()
parser.feed(html)
counts = Counter(parser.ids)
duplicates = sorted(key for key, count in counts.items() if count > 1)
if duplicates:
    raise SystemExit(f'Duplicate HTML IDs: {duplicates}')

ids = set(parser.ids)
refs = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", js))
missing = sorted(refs - ids)
if missing:
    raise SystemExit(f'JavaScript references missing HTML IDs: {missing}')

required = {
    'usageRequestCount', 'usageTokenCount', 'usageCostTotal',
    'usageEstimateNote', 'resetUsageButton', 'makePollinationsDefault',
    'providerModelsInput', 'providerContextWindow', 'providerInputPrice',
    'providerOutputPrice', 'providerMonthlyBudget', 'providerBudgetThreshold',
    'providerStreamingInput', 'cancelProviderEdit'
}
if not required.issubset(ids):
    raise SystemExit(f'Missing Provider UI controls: {sorted(required - ids)}')

native = (ROOT / 'app/src/main/java/ai/scailab/chat/MainActivity.java').read_text(encoding='utf-8')
if 'public void testProvider(' not in native or 'performProviderTest(' not in native:
    raise SystemExit('Native Provider connection-test bridge is missing.')

print(f'Asset validation passed: {len(ids)} unique HTML IDs, {len(refs)} JS DOM references, Provider native bridge present.')
