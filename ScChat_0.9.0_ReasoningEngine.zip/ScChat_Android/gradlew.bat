@echo off
setlocal
set GRADLE_VERSION=8.9
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set DIST_DIR=%GRADLE_USER_HOME%\scailab-distributions\gradle-%GRADLE_VERSION%
set ARCHIVE=%GRADLE_USER_HOME%\scailab-distributions\gradle-%GRADLE_VERSION%-bin.zip
if not exist "%DIST_DIR%\bin\gradle.bat" (
  if not exist "%GRADLE_USER_HOME%\scailab-distributions" mkdir "%GRADLE_USER_HOME%\scailab-distributions"
  if not exist "%ARCHIVE%" powershell -NoProfile -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ARCHIVE%'"
  powershell -NoProfile -Command "Expand-Archive -Force '%ARCHIVE%' '%GRADLE_USER_HOME%\scailab-distributions'"
)
call "%DIST_DIR%\bin\gradle.bat" -p "%~dp0" %*
endlocal
