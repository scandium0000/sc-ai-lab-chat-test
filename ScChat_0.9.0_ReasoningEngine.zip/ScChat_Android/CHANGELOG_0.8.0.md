# Sc Chat 0.8.0 — Minimal UX + Native Reasoning Mode

## Interface
- Refined the light theme into a cleaner cool-neutral palette while preserving the signature blue accent.
- Improved sidebar, navigation, welcome cards, message spacing, composer shape, and modal surfaces.
- Kept the existing chat-first layout and avoided additional dashboard clutter.
- Preserved dark-mode variables and added matching styling for the new control.

## Deep Thinking
- Added an optional composer toggle for model-native reasoning effort.
- Pollinations availability is inferred only from explicit `supported_parameters` metadata (or an explicit reasoning capability declaration).
- Custom providers require manual per-model confirmation that `reasoning_effort` is supported.
- Sends `reasoning_effort: "high"` only when enabled and supported. Unsupported models receive no parameter.
- Preference is stored per local account.
- Clarified that this is remote model-native reasoning, not on-device HSSM inference.

## Compatibility
- Application ID remains `ai.scailab.chat`.
- Version code 13; version name 0.8.0.
- Existing local data namespaces and development signing configuration are retained.
