# Sc Chat 0.6.1 — Keyboard & System Insets Hotfix

## Fixed
- The Android status bar no longer overlaps the Sc Chat top toolbar: the WebView is placed below the status-bar and display-cutout insets.
- The message composer now follows the Android software keyboard instead of remaining behind it.
- Android 11+ uses explicit native `WindowInsets.Type.ime()` handling and `SOFT_INPUT_ADJUST_NOTHING` to avoid OEM-dependent WebView resize behavior.
- Android 8–10 continue using `SOFT_INPUT_ADJUST_RESIZE`.
- The UI receives native keyboard visibility updates and collapses home shortcuts while typing.
- Removed the previous page-level `scrollIntoView()` fallback that could scroll the wrong container.
- System-bar icon appearance now uses `WindowInsetsController` on Android 11+, avoiding accidental reset of edge-to-edge layout flags.

## Compatibility
- `applicationId`: `ai.scailab.chat` (unchanged)
- `versionCode`: `8`
- `versionName`: `0.6.1`
- Previous 0.6.0 development signing key retained for in-place debug upgrades.
- Local storage namespaces remain unchanged.

## Validation
- JavaScript syntax check passed.
- HTML duplicate-ID and JS-to-DOM reference checks passed.
- CSS parser check passed.
- Android Manifest and theme XML checks passed.
- YAML parse and embedded shell syntax checks passed.
- Browser smoke test passed at reduced viewports of 520, 460, 420, and 380 CSS px; composer remained visible and within the viewport.
- Physical Android `WindowInsets` behavior and APK build still require GitHub Actions + device verification.
