# Sc Chat 0.7.2 — Account IME & Lifecycle Hotfix

## Fixed

- Prevent account/profile form fields (nickname, password, account deletion confirmation) from activating the main chat composer IME layout.
- Track native IME visibility separately from focus ownership; stale keyboard callbacks can no longer move the chat composer while an account/settings/editor modal owns focus.
- Explicitly clear the chat-composer IME state when opening account, assistant, or settings dialogs.
- Persist per-account workspace state: active conversation, workspace page, open project, selected Provider, and active assistant.
- Restore the previous workspace after Activity recreation or process restoration when the referenced data still exists.
- Avoid focusing the chat composer when creating the initial conversation during cold restore, preventing the keyboard from opening unexpectedly.
- Add WebView pause/resume lifecycle handling rather than reloading the page on every foreground transition.
- Save and restore WebView navigation state through Android Activity saved-instance state.
- Handle WebView renderer termination explicitly and recreate the Activity from the local app entry point when necessary.
- Save the workspace checkpoint on `visibilitychange`, `pagehide`, Activity pause, Activity save-state, and Android UI-hidden memory callbacks.
- Remove the per-account workspace checkpoint when deleting that local account; clear all checkpoints when clearing local data.

## Preserved

- Application ID: `ai.scailab.chat`
- Local storage namespaces: `scailab.*`
- Existing account, chats, assistants, projects, Providers, and usage records.
- Development signing configuration for compatible test upgrades.

## Validation

- JavaScript syntax check.
- Provider logic tests.
- UI regression tests, including profile/account IME isolation.
- Lifecycle regression tests for WebView pause/resume, saved-state restore, renderer recovery, and workspace checkpointing.
- Asset validation: HTML IDs and JavaScript DOM references.
- Android XML and workflow validation.
- ZIP integrity check.

A full Android SDK build and real-device lifecycle test are still required before treating this hotfix as device-verified. Android may still reclaim a background process under memory pressure; this release improves restoration and reduces avoidable reloads, but cannot override OS process-management policy.
