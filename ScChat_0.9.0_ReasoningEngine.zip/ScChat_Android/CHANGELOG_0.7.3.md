# Sc Chat 0.7.3 — Authorization Recovery Hotfix

## Fixed

- Pending Pollinations device authorization is encrypted and persisted before leaving for the browser.
- Activity resume and WebView page restoration restart the pending device-flow poller.
- Device authorization uses the provider-returned expiry, polling interval, and complete verification URI where available.
- Pollinations' granted user token is stored in Android Keystore-backed encrypted preferences.
- Native generation requests resolve the Pollinations token in Java. JavaScript can test token presence but cannot read the token value.
- Disconnect and clear-local-data actions remove the encrypted Pollinations token and pending authorization.

## Preserved

- Application ID: `ai.scailab.chat`.
- Development signing keystore and alias.
- Local account, chat, project, assistant, and provider storage namespaces.
- Existing WebView lifecycle recovery and IME focus isolation.

## Validation

- Node.js syntax check.
- Provider logic regression tests.
- UI regression tests.
- Lifecycle regression tests.
- Authorization recovery regression tests.
- Python asset validation and Android XML parsing.
- Android APK compilation requires the configured GitHub Actions build environment; this container does not have Gradle installed.

## Device testing still required

- Start a Pollinations device authorization, open the external browser, approve access, then return to Sc Chat.
- Repeat while Android is configured to aggressively reclaim background apps.
- Confirm that a previously granted token survives a normal app process restart and is removed after disconnect.
