# Sc Chat — Android 0.9.5

A minimal Android AI chat client by Sc Ai Lab. The app uses a native Java Android shell and a local HTML/CSS/JavaScript interface inside Android WebView.

## What's new in 0.9.5 and 0.9.4

### Sc Document Engine
- PDF: local PDFBox text extraction with page labels, up to 40 pages and 120,000 characters.
- Scanned/image-only PDF: on-device OCR using bundled ML Kit Chinese and Latin models. Searchable pages use native text extraction; pages without embedded text use OCR. OCR is capped at 20 scanned pages per PDF.
- DOCX: local ZIP/XML parsing with headings, paragraphs, lists, and basic tables retained.
- XLSX: local workbook and worksheet parsing, shared strings, cell values, basic row/column structure, booleans, and formula expressions.
- PPTX: local slide-order and text extraction with slide labels.
- ZIP: safe in-memory archive inspection; supported text, PDF, DOCX, XLSX, and PPTX entries are locally processed. Unsupported binaries are listed, never executed.
- Existing TXT, MD, CSV, JSON, common source-code, and markup text handling remains available.

### Server-generated file downloads
- Assistant Markdown links that point to recognizable generated files receive a **Download file** action.
- Bare HTTPS links to recognizable file extensions are also detected.
- Android opens the system Save As picker and downloads the file directly. Provider API credentials are never forwarded to the download host.
- Downloads require HTTPS and are limited to 50 MB. The Provider must return a real HTTPS URL. Provider-specific file IDs that require a custom authenticated download API are not yet supported.

### Camera Stability Update (0.9.5)
- Native camera photos are served to the local WebView through a short-lived, app-local resource URL instead of embedding the full Base64 image in a JavaScript call.
- Camera decoding is bounded to a 1280-pixel longest edge and the temporary preview is compressed to at most 450 KB.
- Temporary camera output files survive Activity configuration recreation; preview files are removed after the editor loads them.
- Camera intent URI permissions are explicitly granted to resolved camera handlers, and diagnostic logs are written under the `ScChatCamera` tag.
- Existing local pen, mosaic, crop, rotation, and undo editing remains available.

## Parsing limits

- PDF: 10 MB; native extraction up to 40 pages; OCR up to 20 scanned pages.
- DOCX: 10 MB, with bounded internal XML extraction.
- XLSX/PPTX: 15 MB; XLSX up to 20 worksheets, 600 rows per sheet, 80 cells per row; PPTX up to 80 slides.
- ZIP: 15 MB upload, 200 entries, 12 MB per expanded entry, 40 MB total expanded data. Nested ZIP files are listed, not recursively unpacked.
- All extracted content is capped at 120,000 characters per document. Important tables, formulas, charts, images, handwriting, or visual layout may require manual verification.

## Privacy and safety

- Document extraction and OCR run locally on the device. Only prepared text or images are sent to the selected Provider when the user sends the message.
- ZIP content is never extracted to disk or executed. Archive paths and expansion sizes are validated.
- OCR results can contain mistakes; verify important figures and formulas.
- Document text is treated as untrusted reference data, not as instructions that can override system or safety rules.
- Generated file downloads require an explicit user action and Android Save As confirmation. Only HTTPS is accepted, and no Provider API key is sent to the file host.

## Build from an Android phone with GitHub Actions

1. Upload `ScChat_0.9.5_CameraStability.zip` to the root of your private GitHub repository.
2. Copy `build-from-zip-0.9.5.yml` to `.github/workflows/build-from-zip.yml`.
3. Open **Actions** and run **Build Sc Chat 0.9.5 APK**.
4. Download the `ScChat-0.9.5-debug` artifact when the workflow succeeds.

The workflow discovers the Android SDK Manager already provisioned on the GitHub-hosted runner, installs Android API 35 and Build Tools 35.0.0, runs JavaScript regression tests and Java parser tests, validates Android XML, builds with Gradle 8.9, and verifies the APK package, version, and signature.

Keep the repository private because the debug build retains the existing project signing key to preserve upgrade compatibility. Never publish the keystore or its credentials.

## Compatibility

- Application ID: `ai.scailab.chat`
- Namespace: `ai.scailab.chat`
- Minimum Android SDK: 26
- Compile / target SDK: 35
- Java: 17
- Gradle: 8.9
- Version code: 19
- Version name: `0.9.5`

## Build verification status

Source-level JavaScript, camera regression, and parser tests are run in this development environment. This environment does not have the Android SDK or Gradle, so the APK has not been compiled or tested on a physical device here. Native ML Kit OCR, Save As downloads, and the camera stability update still need GitHub Actions build validation and physical-device testing.
