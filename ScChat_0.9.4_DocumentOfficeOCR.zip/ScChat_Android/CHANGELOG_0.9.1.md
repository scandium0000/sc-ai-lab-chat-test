# Sc Chat 0.9.1 — Reliability Update

## Added
- Per-chat local text draft saving and restoration.
- Persistent request lifecycle states for active, interrupted, failed, and stopped generations.
- Manual retry/recovery for the latest unanswered user message.
- Disabled retry controls while a request is active.
- Reliability tests covering drafts, retry eligibility, and interrupted request recovery.

## Improved
- Request state is saved before dispatch so a process restart can identify an interrupted request.
- A stopped or failed request no longer leaves its last user prompt without a recovery path.
- Existing Application ID, local storage namespace, and debug signing identity are preserved.

## Notes
- Pending attachment selections are not part of composer draft persistence.
- Interrupted requests are never automatically replayed; users must explicitly choose recovery to avoid unintended duplicate provider charges.
- Android APK compilation and physical-device testing must still be completed through GitHub Actions and a real device.
