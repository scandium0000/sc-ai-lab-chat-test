const assert = require('node:assert/strict');
const engine = require('../app/src/main/assets/document-engine.js');

const cases = [
  ['report.xlsx', 'https://cdn.example.test/report.xlsx?token=abc', 'report.xlsx'],
  ['Download presentation', 'https://cdn.example.test/file?id=8', 'file'],
  ['下载文件', 'https://cdn.example.test/export.pdf', 'export.pdf'],
];
for (const [label, url, expectedName] of cases) {
  const result = engine.getDownloadDescriptor(label, url);
  assert.ok(result, `expected download descriptor for ${label}`);
  assert.equal(result.name, expectedName);
}
assert.equal(engine.getDownloadDescriptor('normal link', 'https://example.test/about'), null);
assert.equal(engine.getDownloadDescriptor('user profile', 'https://example.test/profile'), null);
assert.equal(engine.getDownloadDescriptor('download', 'javascript:alert(1)'), null);
assert.equal(engine.getDownloadDescriptor('download', 'https://user:secret@example.test/file'), null);
console.log('Generated-file link tests passed: HTTPS validation, file detection, and safe filenames.');
