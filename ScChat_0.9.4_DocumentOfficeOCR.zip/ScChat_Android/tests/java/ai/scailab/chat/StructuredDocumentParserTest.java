package ai.scailab.chat;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class StructuredDocumentParserTest {
    private static byte[] zip(String[][] entries) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(bytes)) {
            for (String[] entry : entries) {
                zip.putNextEntry(new ZipEntry(entry[0]));
                zip.write(entry[1].getBytes(StandardCharsets.UTF_8));
                zip.closeEntry();
            }
        }
        return bytes.toByteArray();
    }

    private static void contains(String value, String needle, String label) {
        if (value == null || !value.contains(needle)) throw new AssertionError(label + " missing: " + needle + " in " + value);
    }

    public static void main(String[] args) throws Exception {
        byte[] xlsx = zip(new String[][]{
                {"xl/workbook.xml", "<workbook xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships'><sheets><sheet name='Summary' sheetId='1' r:id='rId1'/></sheets></workbook>"},
                {"xl/_rels/workbook.xml.rels", "<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'><Relationship Id='rId1' Target='worksheets/sheet1.xml' Type='worksheet'/></Relationships>"},
                {"xl/sharedStrings.xml", "<sst xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'><si><t>Revenue</t></si><si><t>100</t></si></sst>"},
                {"xl/worksheets/sheet1.xml", "<worksheet xmlns='http://schemas.openxmlformats.org/spreadsheetml/2006/main'><sheetData><row r='1'><c r='A1' t='s'><v>0</v></c><c r='B1'><v>2026</v></c></row><row r='2'><c r='A2' t='s'><v>1</v></c><c r='B2'><f>50*2</f><v>100</v></c></row></sheetData></worksheet>"}
        });
        String sheet = StructuredDocumentParser.extractXlsxText(xlsx);
        contains(sheet, "Worksheet: Summary", "XLSX worksheet name");
        contains(sheet, "Revenue", "XLSX shared string");
        contains(sheet, "formula: =50*2", "XLSX formula metadata");

        byte[] pptx = zip(new String[][]{
                {"ppt/presentation.xml", "<p:presentation xmlns:p='http://schemas.openxmlformats.org/presentationml/2006/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships'><p:sldIdLst><p:sldId id='256' r:id='rId1'/></p:sldIdLst></p:presentation>"},
                {"ppt/_rels/presentation.xml.rels", "<Relationships xmlns='http://schemas.openxmlformats.org/package/2006/relationships'><Relationship Id='rId1' Target='slides/slide1.xml' Type='slide'/></Relationships>"},
                {"ppt/slides/slide1.xml", "<p:sld xmlns:p='http://schemas.openxmlformats.org/presentationml/2006/main' xmlns:a='http://schemas.openxmlformats.org/drawingml/2006/main'><p:cSld><p:spTree><p:sp><p:txBody><a:p><a:r><a:t>Sc Chat roadmap</a:t></a:r></a:p><a:p><a:r><a:t>Document Engine</a:t></a:r></a:p></p:txBody></p:sp></p:spTree></p:cSld></p:sld>"}
        });
        String slides = StructuredDocumentParser.extractPptxText(pptx);
        contains(slides, "Slide 1", "PPTX slide label");
        contains(slides, "Sc Chat roadmap", "PPTX text extraction");

        ByteArrayOutputStream archiveBytes = new ByteArrayOutputStream();
        try (ZipOutputStream archiveZip = new ZipOutputStream(archiveBytes)) {
            archiveZip.putNextEntry(new ZipEntry("docs/notes.txt")); archiveZip.write("Local ZIP extraction works.".getBytes(StandardCharsets.UTF_8)); archiveZip.closeEntry();
            archiveZip.putNextEntry(new ZipEntry("README.md")); archiveZip.write("Project archive".getBytes(StandardCharsets.UTF_8)); archiveZip.closeEntry();
            archiveZip.putNextEntry(new ZipEntry("report.xlsx")); archiveZip.write(xlsx); archiveZip.closeEntry();
        }
        byte[] archive = archiveBytes.toByteArray();
        String extracted = ArchiveDocumentParser.extractText(archive, (name, data) -> {
            if (name.toLowerCase(java.util.Locale.ROOT).endsWith(".xlsx")) return StructuredDocumentParser.extractXlsxText(data);
            return new String(data, StandardCharsets.UTF_8);
        });
        contains(extracted, "Entries: 3", "ZIP entry count");
        contains(extracted, "Local ZIP extraction works.", "ZIP nested text extraction");
        contains(extracted, "Worksheet: Summary", "ZIP nested XLSX extraction");

        byte[] traversal = zip(new String[][]{{"../outside.txt", "should not extract"}});
        boolean rejected = false;
        try { ArchiveDocumentParser.extractText(traversal, (name, data) -> new String(data, StandardCharsets.UTF_8)); }
        catch (IllegalArgumentException expected) { rejected = true; }
        if (!rejected) throw new AssertionError("ZIP path traversal entry was not rejected");

        System.out.println("Structured document tests passed: XLSX, PPTX, ZIP extraction, and ZIP path traversal protection.");
    }
}
