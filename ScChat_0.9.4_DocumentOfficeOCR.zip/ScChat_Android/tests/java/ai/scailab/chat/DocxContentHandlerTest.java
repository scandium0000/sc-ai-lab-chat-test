package ai.scailab.chat;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class DocxContentHandlerTest {
    public static void main(String[] args) throws Exception {
        String xml = """
            <?xml version="1.0" encoding="UTF-8"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p><w:pPr><w:pStyle w:val="Heading1"/></w:pPr><w:r><w:t>Project Overview</w:t></w:r></w:p>
                <w:p><w:r><w:t>First paragraph.</w:t></w:r><w:r><w:tab/><w:t>Tabbed text.</w:t></w:r></w:p>
                <w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="1"/></w:numPr></w:pPr><w:r><w:t>List item</w:t></w:r></w:p>
                <w:tbl>
                  <w:tr><w:tc><w:p><w:r><w:t>Name</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Value</w:t></w:r></w:p></w:tc></w:tr>
                  <w:tr><w:tc><w:p><w:r><w:t>Context</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>128K</w:t></w:r></w:p></w:tc></w:tr>
                </w:tbl>
              </w:body>
            </w:document>
            """;
        ByteArrayOutputStream archive = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(archive)) {
            zip.putNextEntry(new ZipEntry("[Content_Types].xml"));
            zip.write("<Types/>".getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.putNextEntry(new ZipEntry("word/document.xml"));
            zip.write(xml.getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }

        String result = DocxDocumentParser.extractText(archive.toByteArray());
        require(result.contains("# Project Overview"), "Heading style was not preserved");
        require(result.contains("First paragraph."), "Paragraph text was not extracted");
        require(result.contains("Tabbed text."), "Run text was not extracted");
        require(result.contains("- List item"), "List marker was not preserved");
        require(result.contains("[Table 1]"), "Table marker was not emitted");
        require(result.contains("| Name | Value |"), "Table header cells were not extracted");
        require(result.contains("| Context | 128K |"), "Table body cells were not extracted");

        boolean rejectedEmpty = false;
        try { DocxDocumentParser.extractText(new byte[0]); }
        catch (IllegalArgumentException expected) { rejectedEmpty = true; }
        require(rejectedEmpty, "Empty DOCX input must be rejected.");

        String unsafeXml = "<!DOCTYPE document [<!ENTITY x SYSTEM \"file:///etc/passwd\">]><document>&x;</document>";
        ByteArrayOutputStream unsafeArchive = new ByteArrayOutputStream();
        try (ZipOutputStream zip = new ZipOutputStream(unsafeArchive)) {
            zip.putNextEntry(new ZipEntry("word/document.xml"));
            zip.write(unsafeXml.getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        boolean rejectedDtd = false;
        try { DocxDocumentParser.extractText(unsafeArchive.toByteArray()); }
        catch (IllegalArgumentException expected) { rejectedDtd = true; }
        require(rejectedDtd, "DOCX XML entity declarations must be rejected before parsing.");

        System.out.println("DOCX parser JVM test passed: ZIP extraction, headings, paragraphs, tabs, lists, tables, empty-file rejection, and DTD rejection.");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
