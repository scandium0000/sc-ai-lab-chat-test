const assert = require('node:assert/strict');
const engine = require('../app/src/main/assets/document-engine.js');

assert.equal(engine.inferFormat('report.docx'), 'docx');
assert.equal(engine.inferFormat('report.bin', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'), 'docx');
assert.equal(engine.inferFormat('report.pdf'), 'pdf');
assert.equal(engine.inferFormat('workbook.xlsx'), 'xlsx');
assert.equal(engine.inferFormat('slides.pptx'), 'pptx');
assert.equal(engine.inferFormat('bundle.zip', 'application/zip'), 'zip');
assert.equal(engine.inferFormat('data.csv'), 'csv');
assert.equal(engine.inferFormat('payload.json'), 'json');

const generatedFile = engine.getDownloadDescriptor('Download workbook.xlsx', 'https://files.example.test/download?id=123');
assert.equal(generatedFile.name, 'Download workbook.xlsx');
assert.equal(generatedFile.url, 'https://files.example.test/download?id=123');
assert.equal(engine.getDownloadDescriptor('Read documentation', 'https://example.test/docs'), null);
assert.equal(engine.getDownloadDescriptor('Download result', 'http://example.test/result.xlsx'), null);
assert.equal(engine.getDownloadDescriptor('file', 'https://user:pass@example.test/file.xlsx'), null);

assert.equal(engine.normalizeText('\uFEFFalpha\r\nbeta\u0000'), 'alpha\nbeta');

const csv = 'Name,Notes,Score\r\n"A, B","line one\nline two",10\r\n"She said ""yes""",plain,20';
const parsedCsv = engine.csvToMarkdown(csv);
assert.equal(parsedCsv.rows, 3);
assert.equal(parsedCsv.columns, 3);
assert.match(parsedCsv.text, /\| Name \| Notes \| Score \|/);
assert.match(parsedCsv.text, /A, B/);
assert.match(parsedCsv.text, /line one<br>line two/);
assert.match(parsedCsv.text, /She said "yes"/);
assert.match(parsedCsv.text, /\| --- \| --- \| --- \|/);
const rowLimited = engine.parseCsvRows(Array.from({length: 1002}, (_, index) => `row${index},value`).join('\n'));
assert.equal(rowLimited.rows.length, 1000);
assert.equal(rowLimited.truncated, true);

const goodJson = engine.prepareText('json', '{"name":"Sc Chat","version":0.92}');
assert.equal(goodJson.valid, true);
assert.match(goodJson.text, /\n  "name": "Sc Chat"/);
const badJson = engine.prepareText('json', '{not-json');
assert.equal(badJson.valid, false);
assert.equal(badJson.text, '{not-json');

const clipped = engine.clipText('x'.repeat(engine.MAX_CHARS + 50));
assert.equal(clipped.truncated, true);
assert.ok(clipped.text.length <= engine.MAX_CHARS + 2);
assert.match(clipped.text, /Document content truncated/);

console.log('Sc Document Engine tests passed: format detection, text normalization, CSV quoting/tables, JSON validation, and size limits.');
