const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

const app = fs.readFileSync(path.join(__dirname, '..', 'app/src/main/assets/app.js'), 'utf8');

function makeStorage() {
  const values = new Map();
  return {
    getItem(key) { return values.has(key) ? values.get(key) : null; },
    setItem(key, value) { values.set(key, String(value)); },
    removeItem(key) { values.delete(key); },
    key(index) { return [...values.keys()][index] ?? null; },
    get length() { return values.size; },
    values
  };
}

const storage = makeStorage();
const input = {value: ''};
const context = {
  currentUser: 'Alice',
  currentChatId: 'chat-1',
  STORE_DRAFTS: 'scailab.drafts.v1',
  normaliseUsername(value) { return String(value).trim().toLowerCase(); },
  draftSaveTimer: null,
  localStorage: storage,
  Date,
  console,
  setTimeout,
  clearTimeout,
  $: id => id === 'messageInput' ? input : null,
  safeJsonParse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } },
  autoResize() {}
};
vm.createContext(context);
const draftStart = app.indexOf('function draftStorageKey(');
const draftEnd = app.indexOf('\nfunction retryableUserMessage(', draftStart);
assert.ok(draftStart >= 0 && draftEnd > draftStart, 'Draft persistence helpers must exist.');
vm.runInContext(`${app.slice(draftStart, draftEnd)}\nthis.testDraftKey = draftStorageKey; this.testSaveDraft = persistComposerDraft; this.testRestoreDraft = restoreComposerDraft;`, context);

input.value = 'Unsent text that must survive navigation.';
context.testSaveDraft(true);
const key = context.testDraftKey('chat-1');
assert.ok(storage.getItem(key), 'A non-empty draft must be persisted.');

context.currentChatId = 'chat-2';
input.value = '';
context.testRestoreDraft('chat-2');
assert.equal(input.value, '', 'Drafts must be isolated by conversation.');

context.currentChatId = 'chat-1';
context.testRestoreDraft('chat-1');
assert.equal(input.value, 'Unsent text that must survive navigation.', 'The matching conversation draft must be restored.');

input.value = '';
context.testSaveDraft(true);
assert.equal(storage.getItem(key), null, 'An empty composer must clear its saved draft.');

const retryStart = app.indexOf('function retryableUserMessage(');
const retryEnd = app.indexOf('\nasync function retryLastUserMessage(', retryStart);
assert.ok(retryStart >= 0 && retryEnd > retryStart, 'Retry eligibility helper must exist.');
vm.runInContext(`${app.slice(retryStart, retryEnd)}\nthis.testRetryableUserMessage = retryableUserMessage;`, context);
const pendingChat = {messages:[{role:'user', content:'Try this request again.'}]};
assert.equal(context.testRetryableUserMessage(pendingChat).message.content, 'Try this request again.');
assert.equal(context.testRetryableUserMessage({messages:[{role:'user',content:'Done'},{role:'assistant',content:'Complete'}]}), null,
  'Completed conversations must not expose an unanswered-message retry.');
assert.equal(context.testRetryableUserMessage({messages:[]}), null);

const loadStart = app.indexOf('function loadChats()');
const loadEnd = app.indexOf('\nfunction saveChats(', loadStart);
assert.ok(loadStart >= 0 && loadEnd > loadStart, 'Chat recovery loader must exist.');
context.chats = [];
context.chatStorageKey = () => 'scailab.chats.alice';
storage.setItem('scailab.chats.alice', JSON.stringify([
  {id:'interrupted', messages:[{role:'user',content:'Persisted before request'}], requestState:{status:'in_progress'}},
  {id:'completed', messages:[{role:'assistant',content:'Done'}], requestState:null}
]));
vm.runInContext(`${app.slice(loadStart, loadEnd)}\nthis.testLoadChats = loadChats;`, context);
context.testLoadChats();
assert.equal(context.chats[0].requestState.status, 'interrupted', 'An in-progress request must be marked interrupted after app restart.');
assert.equal(context.chats[1].requestState, null, 'Completed conversation state must remain unchanged.');
assert.equal(JSON.parse(storage.getItem('scailab.chats.alice'))[0].requestState.status, 'interrupted', 'Recovery status must be persisted.');

console.log('Sc Chat reliability tests passed: per-chat draft persistence, draft clearing, retry eligibility, and interrupted-request recovery.');
