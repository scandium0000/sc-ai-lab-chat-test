const assert = require('node:assert/strict');
const studio = require('../app/src/main/assets/camera-studio.js');

assert.deepEqual(studio.fitDimensions(4000, 2000, 1600), { width: 1600, height: 800, scale: 0.4 });
assert.deepEqual(studio.fitDimensions(800, 600, 1600), { width: 800, height: 600, scale: 1 });
assert.deepEqual(studio.clampCropRect({ x1: 20, y1: 30, x2: 180, y2: 130 }, 200, 150), { x: 20, y: 30, width: 160, height: 100 });
assert.deepEqual(studio.clampCropRect({ x1: -20, y1: 10, x2: 250, y2: 80 }, 200, 100), { x: 0, y: 10, width: 200, height: 70 });
assert.equal(studio.clampCropRect({ x1: 5, y1: 5, x2: 10, y2: 10 }, 100, 100), null);
assert.equal(studio.estimateDataUrlBytes('data:image/jpeg;base64,AAAA'), 3);

// Verify mosaic edits only the requested region while preserving canvas dimensions.
const width = 16, height = 16;
const pixels = new Uint8ClampedArray(width * height * 4);
for (let y = 0; y < height; y += 1) {
  for (let x = 0; x < width; x += 1) {
    const i = (y * width + x) * 4;
    pixels[i] = x * 10; pixels[i + 1] = y * 10; pixels[i + 2] = 100; pixels[i + 3] = 255;
  }
}
let written = null;
const context = {
  getImageData(x, y, w, h) {
    const data = new Uint8ClampedArray(w * h * 4);
    for (let row = 0; row < h; row += 1) for (let col = 0; col < w; col += 1) {
      const from = ((y + row) * width + (x + col)) * 4;
      const to = (row * w + col) * 4;
      data.set(pixels.slice(from, from + 4), to);
    }
    return { data, width: w, height: h };
  },
  putImageData(image, x, y) { written = { image, x, y }; }
};
studio.applyMosaicDab(context, { width, height }, 8, 8, 8, 4);
assert.ok(written, 'Mosaic should write edited pixels back to the canvas.');
assert.equal(written.x, 0);
assert.equal(written.y, 0);
assert.equal(written.image.width, width);
assert.equal(written.image.height, height);

console.log('Camera Studio tests passed: image sizing, crop bounds, data URL sizing, and local mosaic processing.');
