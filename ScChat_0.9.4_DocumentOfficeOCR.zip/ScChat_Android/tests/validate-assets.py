from html.parser import HTMLParser
from pathlib import Path
import re
from collections import Counter

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'app/src/main/assets/index.html').read_text(encoding='utf-8')
js = (ROOT / 'app/src/main/assets/app.js').read_text(encoding='utf-8')
document_engine = (ROOT / 'app/src/main/assets/document-engine.js').read_text(encoding='utf-8')
camera_studio = (ROOT / 'app/src/main/assets/camera-studio.js').read_text(encoding='utf-8')
main_java = (ROOT / 'app/src/main/java/ai/scailab/chat/MainActivity.java').read_text(encoding='utf-8')

class IdParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.ids = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])

parser = IdParser()
parser.feed(html)
counts = Counter(parser.ids)
duplicates = sorted(key for key, count in counts.items() if count > 1)
if duplicates:
    raise SystemExit(f'Duplicate HTML IDs: {duplicates}')

ids = set(parser.ids)
refs = set(re.findall(r"\$\(['\"]([^'\"]+)['\"]\)", js))
missing = sorted(refs - ids)
if missing:
    raise SystemExit(f'JavaScript references missing HTML IDs: {missing}')

required = {
    'usageRequestCount', 'usageTokenCount', 'usageCostTotal',
    'usageEstimateNote', 'resetUsageButton', 'makePollinationsDefault',
    'providerModelsInput', 'providerContextWindow', 'providerInputPrice',
    'providerOutputPrice', 'providerMonthlyBudget', 'providerBudgetThreshold',
    'providerStreamingInput', 'cancelProviderEdit'
}
if not required.issubset(ids):
    raise SystemExit(f'Missing Provider UI controls: {sorted(required - ids)}')

native = main_java
if 'public void testProvider(' not in native or 'performProviderTest(' not in native:
    raise SystemExit('Native Provider connection-test bridge is missing.')

if '<script src="document-engine.js"></script>' not in html or 'extractDocxTextAsync' not in native or 'extractDocxTextAsync' not in js:
    raise SystemExit('Sc Document Engine or native DOCX bridge is missing.')
if '<script src="camera-studio.js"></script>' not in html or 'capturePhoto()' not in native or 'FileProvider' not in native:
    raise SystemExit('Camera Studio native capture integration is missing.')
if 'MediaStore.ACTION_IMAGE_CAPTURE' not in native or 'ExifInterface' not in native or 'android.permission.CAMERA' in (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8'):
    raise SystemExit('Camera capture intent, orientation handling, or permission boundary is incorrect.')
if not {'cameraButton', 'cameraEditorModal', 'cameraEditorCanvas', 'cameraApplyCrop', 'cameraSaveEdit'}.issubset(ids):
    raise SystemExit('Camera Studio UI controls are incomplete.')
if not (ROOT / 'app/src/main/res/xml/file_paths.xml').exists():
    raise SystemExit('Camera FileProvider paths configuration is missing.')
if not (ROOT / 'app/src/main/assets/document-engine.js').exists():
    raise SystemExit('document-engine.js is missing.')
if 'extractStructuredFileAsync' not in native or 'ArchiveDocumentParser.extractText' not in native:
    raise SystemExit('ZIP/XLSX/PPTX native parser bridge is missing.')
if 'performPdfOcr' not in native or 'com.google.mlkit:text-recognition-chinese:16.0.1' not in (ROOT / 'app/build.gradle.kts').read_text(encoding='utf-8'):
    raise SystemExit('On-device PDF OCR dependencies or native implementation are missing.')
if 'saveRemoteGeneratedFile' not in native or 'generated-file-download' not in js or 'ACTION_CREATE_DOCUMENT' not in native:
    raise SystemExit('Server-generated file download flow is missing.')
if not (ROOT / 'app/src/main/java/ai/scailab/chat/StructuredDocumentParser.java').exists() or not (ROOT / 'app/src/main/java/ai/scailab/chat/ArchiveDocumentParser.java').exists():
    raise SystemExit('Office/archive document parsers are missing.')
print(f'Asset validation passed: {len(ids)} unique HTML IDs, {len(refs)} JS DOM references, Provider, document and camera bridges present.')
