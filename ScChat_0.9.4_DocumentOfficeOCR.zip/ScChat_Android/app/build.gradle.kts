plugins {
    id("com.android.application")
}

android {
    namespace = "ai.scailab.chat"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.scailab.chat"
        minSdk = 26
        targetSdk = 35
        versionCode = 18
        versionName = "0.9.4"
    }

    signingConfigs {
        create("development") {
            storeFile = file("dev-debug.jks")
            storeType = "PKCS12"
            storePassword = "scai-dev-only"
            keyAlias = "scai-debug"
            keyPassword = "scai-dev-only"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("development")
        }
        release {
            isMinifyEnabled = false
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("androidx.core:core:1.15.0")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("com.tom-roush:pdfbox-android:2.0.27.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
}
