(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ScDocumentEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const MAX_CHARS = 120000;

  function normalizeText(value) {
    return String(value == null ? '' : value)
      .replace(/^\uFEFF/, '')
      .replace(/\u0000/g, '')
      .replace(/\r\n?/g, '\n');
  }

  function clipText(value, maxChars = MAX_CHARS) {
    const text = normalizeText(value);
    if (text.length <= maxChars) return { text, truncated: false };
    const marker = '\n\n[Document content truncated by Sc Chat: character limit reached.]';
    return { text: text.slice(0, Math.max(0, maxChars - marker.length)) + marker, truncated: true };
  }

  function parseCsvRows(source, maxRows = 1000) {
    const input = normalizeText(source);
    const rows = [];
    let row = [], cell = '', quoted = false, rowLimitReached = false;
    for (let i = 0; i < input.length; i += 1) {
      const char = input[i];
      if (quoted) {
        if (char === '"' && input[i + 1] === '"') { cell += '"'; i += 1; }
        else if (char === '"') quoted = false;
        else cell += char;
      } else if (char === '"' && cell.length === 0) {
        quoted = true;
      } else if (char === ',') {
        row.push(cell); cell = '';
      } else if (char === '\n') {
        row.push(cell); cell = '';
        if (row.some(value => value.length > 0)) rows.push(row);
        row = [];
        if (rows.length >= maxRows) { rowLimitReached = true; break; }
      } else {
        cell += char;
      }
    }
    if (row.length || cell.length) {
      row.push(cell);
      if (row.some(value => value.length > 0) && rows.length < maxRows) rows.push(row);
    }
    return { rows, truncated: rowLimitReached };
  }

  function csvToMarkdown(source) {
    const parsed = parseCsvRows(source);
    if (!parsed.rows.length) return { text: '', rows: 0, columns: 0, truncated: false };
    const columns = Math.max(...parsed.rows.map(row => row.length));
    const normalizedRows = parsed.rows.map(row => {
      const cells = Array.from({ length: columns }, (_, index) => row[index] || '');
      return `| ${cells.map(value => value.replace(/\|/g, '\\|').replace(/\n/g, '<br>').trim()).join(' | ')} |`;
    });
    if (normalizedRows.length > 1) normalizedRows.splice(1, 0, `| ${Array(columns).fill('---').join(' | ')} |`);
    let text = normalizedRows.join('\n');
    if (parsed.truncated) text += '\n\n[CSV truncated: row limit reached.]';
    const clipped = clipText(text);
    return { text: clipped.text, rows: parsed.rows.length, columns, truncated: parsed.truncated || clipped.truncated };
  }

  function formatJson(source) {
    const normalized = normalizeText(source);
    try {
      return { text: JSON.stringify(JSON.parse(normalized), null, 2), valid: true };
    } catch (_) {
      return { text: normalized, valid: false };
    }
  }

  function inferFormat(name, mimeType = '') {
    const extension = String(name || '').toLowerCase().split('.').pop();
    const supported = new Set(['pdf', 'docx', 'xlsx', 'pptx', 'zip', 'txt', 'md', 'markdown', 'csv', 'json', 'js', 'ts', 'py', 'java', 'kt', 'html', 'css', 'xml', 'yaml', 'yml', 'log']);
    if (supported.has(extension)) return extension === 'markdown' ? 'md' : extension;
    const mime = String(mimeType || '').toLowerCase();
    if (mime === 'application/pdf') return 'pdf';
    if (mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') return 'docx';
    if (mime === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') return 'xlsx';
    if (mime === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') return 'pptx';
    if (mime === 'application/zip' || mime === 'application/x-zip-compressed') return 'zip';
    if (mime === 'text/csv') return 'csv';
    if (mime === 'application/json') return 'json';
    if (mime.startsWith('text/')) return 'txt';
    return '';
  }

  function getDownloadDescriptor(label, rawUrl) {
    let parsed;
    try { parsed = new URL(String(rawUrl || '')); } catch (_) { return null; }
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) return null;
    const path = parsed.pathname.toLowerCase();
    let queryName = parsed.searchParams.get('filename') || parsed.searchParams.get('file_name') || parsed.searchParams.get('name') || '';
    const filePath = /\.(docx|xlsx|pptx|pdf|zip|csv|json|txt|md|png|jpe?g|webp|odt|rtf|ppt|xls)(?:$)/i.test(path)
      || /\.(docx|xlsx|pptx|pdf|zip|csv|json|txt|md|png|jpe?g|webp|odt|rtf|ppt|xls)$/i.test(queryName);
    const fileLabel = /(download|attachment|\bfile\b|下载|文件)/i.test(String(label || ''));
    if (!filePath && !fileLabel) return null;
    let name = String(label || '').trim();
    if (!/\.[a-z0-9]{2,8}$/i.test(name)) {
      try { name = decodeURIComponent(queryName || parsed.pathname.split('/').pop() || 'generated-file'); }
      catch (_) { name = 'generated-file'; }
    }
    name = name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, '_').slice(0, 120) || 'generated-file';
    return { url: parsed.href, name };
  }

  function prepareText(format, source) {
    const normalized = normalizeText(source);
    if (format === 'csv') return { ...csvToMarkdown(normalized), format, details: 'CSV 表格已转换为 Markdown 表格。' };
    if (format === 'json') {
      const result = formatJson(normalized);
      const clipped = clipText(result.text);
      return { ...clipped, format, valid: result.valid, details: result.valid ? 'JSON 已校验并格式化。' : 'JSON 格式无法校验，已保留原始文本。' };
    }
    const clipped = clipText(normalized);
    return { ...clipped, format, details: '本地文本提取完成。' };
  }

  return { MAX_CHARS, normalizeText, clipText, parseCsvRows, csvToMarkdown, formatJson, inferFormat, getDownloadDescriptor, prepareText };
});
