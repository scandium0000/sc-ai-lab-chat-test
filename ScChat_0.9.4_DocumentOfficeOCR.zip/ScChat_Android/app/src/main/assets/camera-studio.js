(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ScCameraStudio = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function fitDimensions(width, height, maxDimension = 1600) {
    const w = Math.max(1, Number(width) || 1);
    const h = Math.max(1, Number(height) || 1);
    const limit = Math.max(1, Number(maxDimension) || 1600);
    const scale = Math.min(1, limit / Math.max(w, h));
    return { width: Math.max(1, Math.round(w * scale)), height: Math.max(1, Math.round(h * scale)), scale };
  }

  function clampCropRect(rect, width, height, minSize = 12) {
    if (!rect || !Number.isFinite(width) || !Number.isFinite(height)) return null;
    const x1 = Math.max(0, Math.min(width, Math.min(rect.x1, rect.x2)));
    const y1 = Math.max(0, Math.min(height, Math.min(rect.y1, rect.y2)));
    const x2 = Math.max(0, Math.min(width, Math.max(rect.x1, rect.x2)));
    const y2 = Math.max(0, Math.min(height, Math.max(rect.y1, rect.y2)));
    if (x2 - x1 < minSize || y2 - y1 < minSize) return null;
    return { x: Math.round(x1), y: Math.round(y1), width: Math.round(x2 - x1), height: Math.round(y2 - y1) };
  }

  function estimateDataUrlBytes(dataUrl) {
    const value = String(dataUrl || '');
    const comma = value.indexOf(',');
    const payload = comma >= 0 ? value.slice(comma + 1) : value;
    return Math.floor(payload.length * 3 / 4) - (payload.endsWith('==') ? 2 : payload.endsWith('=') ? 1 : 0);
  }

  function applyMosaicDab(context, canvas, centerX, centerY, radius, blockSize = 12) {
    const r = Math.max(4, Math.round(radius));
    const left = Math.max(0, Math.floor(centerX - r));
    const top = Math.max(0, Math.floor(centerY - r));
    const right = Math.min(canvas.width, Math.ceil(centerX + r));
    const bottom = Math.min(canvas.height, Math.ceil(centerY + r));
    const width = right - left;
    const height = bottom - top;
    if (width <= 0 || height <= 0) return;
    const image = context.getImageData(left, top, width, height);
    const data = image.data;
    const block = Math.max(4, Math.round(blockSize));
    for (let y = 0; y < height; y += block) {
      for (let x = 0; x < width; x += block) {
        const bw = Math.min(block, width - x);
        const bh = Math.min(block, height - y);
        const dx = left + x + bw / 2 - centerX;
        const dy = top + y + bh / 2 - centerY;
        if (dx * dx + dy * dy > r * r) continue;
        let red = 0, green = 0, blue = 0, alpha = 0, count = 0;
        for (let py = 0; py < bh; py += 1) {
          for (let px = 0; px < bw; px += 1) {
            const index = ((y + py) * width + x + px) * 4;
            red += data[index]; green += data[index + 1]; blue += data[index + 2]; alpha += data[index + 3]; count += 1;
          }
        }
        const color = [Math.round(red / count), Math.round(green / count), Math.round(blue / count), Math.round(alpha / count)];
        for (let py = 0; py < bh; py += 1) {
          for (let px = 0; px < bw; px += 1) {
            const index = ((y + py) * width + x + px) * 4;
            data[index] = color[0]; data[index + 1] = color[1]; data[index + 2] = color[2]; data[index + 3] = color[3];
          }
        }
      }
    }
    context.putImageData(image, left, top);
  }

  return { fitDimensions, clampCropRect, estimateDataUrlBytes, applyMosaicDab };
});
