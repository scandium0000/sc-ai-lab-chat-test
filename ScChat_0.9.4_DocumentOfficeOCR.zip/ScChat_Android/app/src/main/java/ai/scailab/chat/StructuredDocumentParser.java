package ai.scailab.chat;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilderFactory;

/** Safe, in-memory extractors for OOXML spreadsheet and presentation files. */
final class StructuredDocumentParser {
    private static final int MAX_ARCHIVE_BYTES = 15 * 1024 * 1024;
    private static final int MAX_EXPANDED_BYTES = 40 * 1024 * 1024;
    private static final int MAX_ENTRY_BYTES = 12 * 1024 * 1024;
    private static final int MAX_ENTRIES = 400;
    private static final int MAX_OUTPUT_CHARS = 120000;

    private StructuredDocumentParser() { }

    static String extractXlsxText(byte[] bytes) throws Exception {
        Map<String, byte[]> parts = readPackage(bytes);
        List<String> sharedStrings = new ArrayList<>();
        byte[] shared = parts.get("xl/sharedStrings.xml");
        if (shared != null) {
            Document doc = parseXml(shared);
            NodeList items = doc.getElementsByTagNameNS("*", "si");
            for (int i = 0; i < items.getLength(); i++) sharedStrings.add(items.item(i).getTextContent());
        }

        Map<String, String> relationships = new HashMap<>();
        byte[] relBytes = parts.get("xl/_rels/workbook.xml.rels");
        if (relBytes != null) {
            NodeList rels = parseXml(relBytes).getElementsByTagNameNS("*", "Relationship");
            for (int i = 0; i < rels.getLength(); i++) {
                Element rel = (Element) rels.item(i);
                String id = rel.getAttribute("Id");
                String target = rel.getAttribute("Target");
                if (!id.isEmpty() && !target.isEmpty()) relationships.put(id, normalizePart("xl/" + target));
            }
        }

        byte[] workbookBytes = parts.get("xl/workbook.xml");
        if (workbookBytes == null) throw new IllegalArgumentException("XLSX 缺少 workbook.xml。文件可能已损坏。");
        NodeList sheets = parseXml(workbookBytes).getElementsByTagNameNS("*", "sheet");
        if (sheets.getLength() == 0) throw new IllegalArgumentException("XLSX 中没有可读取的工作表。");

        StringBuilder out = new StringBuilder("[XLSX workbook]\n");
        int sheetCount = Math.min(sheets.getLength(), 20);
        for (int s = 0; s < sheetCount; s++) {
            Element sheet = (Element) sheets.item(s);
            String name = sheet.getAttribute("name");
            String rid = sheet.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
            if (rid.isEmpty()) rid = sheet.getAttribute("r:id");
            String path = relationships.get(rid);
            if (path == null || !parts.containsKey(path)) {
                out.append("\n[Worksheet unavailable: ").append(safeLabel(name)).append("]\n");
                continue;
            }
            out.append("\n[Worksheet: ").append(safeLabel(name)).append("]\n");
            Document sheetDoc = parseXml(parts.get(path));
            NodeList rows = sheetDoc.getElementsByTagNameNS("*", "row");
            int rowLimit = Math.min(rows.getLength(), 600);
            for (int r = 0; r < rowLimit; r++) {
                Element row = (Element) rows.item(r);
                NodeList cells = row.getElementsByTagNameNS("*", "c");
                List<String> values = new ArrayList<>();
                int colLimit = Math.min(cells.getLength(), 80);
                for (int c = 0; c < colLimit; c++) {
                    Element cell = (Element) cells.item(c);
                    String type = cell.getAttribute("t");
                    String value = firstChildText(cell, "v");
                    if ("s".equals(type) && !value.isEmpty()) {
                        try { int index = Integer.parseInt(value); value = index >= 0 && index < sharedStrings.size() ? sharedStrings.get(index) : ""; }
                        catch (NumberFormatException ignored) { value = ""; }
                    } else if ("inlineStr".equals(type)) {
                        value = firstChildText(cell, "is");
                    } else if ("b".equals(type)) {
                        value = "1".equals(value) ? "TRUE" : "FALSE";
                    }
                    String formula = firstChildText(cell, "f");
                    if (!formula.isEmpty() && !value.isEmpty()) value += " (formula: =" + formula + ")";
                    values.add(value.replace("|", "\\|").replace("\n", " ").trim());
                }
                if (!values.isEmpty()) out.append("| ").append(join(values, " | ")).append(" |\n");
                if (out.length() > MAX_OUTPUT_CHARS) break;
            }
            if (rows.getLength() > rowLimit) out.append("[Worksheet row limit reached: ").append(rows.getLength()).append(" rows total.]\n");
            if (out.length() > MAX_OUTPUT_CHARS) break;
        }
        if (sheets.getLength() > sheetCount) out.append("\n[Note: ").append(sheets.getLength() - sheetCount).append(" more worksheets omitted.]\n");
        return clip(out.toString());
    }

    static String extractPptxText(byte[] bytes) throws Exception {
        Map<String, byte[]> parts = readPackage(bytes);
        byte[] presentationBytes = parts.get("ppt/presentation.xml");
        if (presentationBytes == null) throw new IllegalArgumentException("PPTX 缺少 presentation.xml。文件可能已损坏。");
        Map<String, String> relationships = new HashMap<>();
        byte[] relBytes = parts.get("ppt/_rels/presentation.xml.rels");
        if (relBytes != null) {
            NodeList rels = parseXml(relBytes).getElementsByTagNameNS("*", "Relationship");
            for (int i = 0; i < rels.getLength(); i++) {
                Element rel = (Element) rels.item(i);
                String id = rel.getAttribute("Id");
                String target = rel.getAttribute("Target");
                if (!id.isEmpty() && !target.isEmpty()) relationships.put(id, normalizePart("ppt/" + target));
            }
        }
        NodeList slides = parseXml(presentationBytes).getElementsByTagNameNS("*", "sldId");
        if (slides.getLength() == 0) throw new IllegalArgumentException("PPTX 中没有可读取的幻灯片。");
        StringBuilder out = new StringBuilder("[PPTX presentation]\n");
        int slideLimit = Math.min(slides.getLength(), 80);
        for (int i = 0; i < slideLimit; i++) {
            Element slide = (Element) slides.item(i);
            String rid = slide.getAttributeNS("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
            if (rid.isEmpty()) rid = slide.getAttribute("r:id");
            String path = relationships.get(rid);
            if (path == null || !parts.containsKey(path)) continue;
            Document slideDoc = parseXml(parts.get(path));
            NodeList paragraphs = slideDoc.getElementsByTagNameNS("*", "p");
            out.append("\n[Slide ").append(i + 1).append("]\n");
            for (int p = 0; p < paragraphs.getLength(); p++) {
                Node paragraph = paragraphs.item(p);
                StringBuilder line = new StringBuilder();
                NodeList textNodes = ((Element) paragraph).getElementsByTagNameNS("*", "t");
                for (int t = 0; t < textNodes.getLength(); t++) line.append(textNodes.item(t).getTextContent());
                String value = line.toString().trim();
                if (!value.isEmpty()) out.append(value).append('\n');
            }
            if (out.length() > MAX_OUTPUT_CHARS) break;
        }
        if (slides.getLength() > slideLimit) out.append("\n[Note: ").append(slides.getLength() - slideLimit).append(" additional slides omitted.]\n");
        return clip(out.toString());
    }

    private static Map<String, byte[]> readPackage(byte[] bytes) throws Exception {
        if (bytes == null || bytes.length == 0 || bytes.length > MAX_ARCHIVE_BYTES) throw new IllegalArgumentException("Office 文件为空或超过 15 MB 限制。");
        Map<String, byte[]> entries = new LinkedHashMap<>();
        long expanded = 0;
        int count = 0;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) {
                if (++count > MAX_ENTRIES) throw new IllegalArgumentException("Office 文件内部条目过多，已停止解析。");
                String name = safePath(entry.getName());
                if (name == null) throw new IllegalArgumentException("Office 文件包含不安全的内部路径。");
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                int read;
                while ((read = zip.read(buffer)) != -1) {
                    expanded += read;
                    if (expanded > MAX_EXPANDED_BYTES || output.size() + read > MAX_ENTRY_BYTES) throw new IllegalArgumentException("Office 文件解压数据超过安全限制。");
                    output.write(buffer, 0, read);
                }
                if (!entry.isDirectory()) entries.put(name, output.toByteArray());
            }
        }
        return entries;
    }

    private static String safePath(String path) {
        if (path == null || path.startsWith("/") || path.indexOf('\\') >= 0 || path.indexOf('\0') >= 0) return null;
        String[] pieces = path.split("/");
        for (String piece : pieces) if ("..".equals(piece)) return null;
        return path;
    }

    private static String normalizePart(String path) {
        String clean = path.replace('\\', '/');
        while (clean.startsWith("/")) clean = clean.substring(1);
        List<String> stack = new ArrayList<>();
        for (String part : clean.split("/")) {
            if (part.isEmpty() || ".".equals(part)) continue;
            if ("..".equals(part)) { if (stack.isEmpty()) return ""; stack.remove(stack.size() - 1); }
            else stack.add(part);
        }
        return join(stack, "/");
    }

    private static Document parseXml(byte[] xml) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        factory.setXIncludeAware(false);
        factory.setExpandEntityReferences(false);
        return factory.newDocumentBuilder().parse(new ByteArrayInputStream(xml));
    }

    private static String firstChildText(Element parent, String localName) {
        NodeList nodes = parent.getElementsByTagNameNS("*", localName);
        return nodes.getLength() == 0 ? "" : nodes.item(0).getTextContent();
    }

    private static String safeLabel(String value) { return value == null ? "" : value.replace("\n", " ").replace("\r", " ").replace("]", "_"); }
    private static String join(List<String> values, String separator) { StringBuilder out = new StringBuilder(); for (String value : values) { if (out.length() > 0) out.append(separator); out.append(value); } return out.toString(); }
    private static String clip(String value) { return value.length() <= MAX_OUTPUT_CHARS ? value : value.substring(0, MAX_OUTPUT_CHARS) + "\n[Content truncated by Sc Chat.]"; }
}
