package ai.scailab.chat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** In-memory ZIP inspection. Entries are never written to a filesystem. */
final class ArchiveDocumentParser {
    interface EntryTextExtractor { String extract(String fileName, byte[] data) throws Exception; }
    private static final int MAX_ZIP_BYTES = 15 * 1024 * 1024;
    private static final int MAX_TOTAL_EXPANDED = 40 * 1024 * 1024;
    private static final int MAX_ENTRY_EXPANDED = 12 * 1024 * 1024;
    private static final int MAX_ENTRIES = 200;
    private static final int MAX_OUTPUT = 120000;

    private ArchiveDocumentParser() { }

    static String extractText(byte[] archive, EntryTextExtractor extractor) throws Exception {
        if (archive == null || archive.length == 0 || archive.length > MAX_ZIP_BYTES) throw new IllegalArgumentException("ZIP 文件为空或超过 15 MB 限制。");
        List<String> sections = new ArrayList<>();
        List<String> skipped = new ArrayList<>();
        long expanded = 0;
        int entries = 0;
        int extracted = 0;
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(archive))) {
            ZipEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = zip.getNextEntry()) != null) {
                entries++;
                if (entries > MAX_ENTRIES) throw new IllegalArgumentException("ZIP 内文件数量超过 200 个的安全限制。");
                String name = entry.getName();
                if (!isSafePath(name)) throw new IllegalArgumentException("ZIP 内包含不安全路径，已停止处理。");
                if (entry.isDirectory()) continue;
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                int read;
                while ((read = zip.read(buffer)) != -1) {
                    expanded += read;
                    if (expanded > MAX_TOTAL_EXPANDED || output.size() + read > MAX_ENTRY_EXPANDED) throw new IllegalArgumentException("ZIP 解压数据超过安全限制，可能包含异常压缩文件。");
                    output.write(buffer, 0, read);
                }
                byte[] data = output.toByteArray();
                String extension = extension(name);
                if (isTextFormat(extension) || isStructuredFormat(extension)) {
                    try {
                        String content = extractor.extract(name, data);
                        if (content != null && !content.trim().isEmpty()) {
                            String section = "\n\n[Archive file: " + name.replace("\n", " ").replace("]", "_") + "]\n" + content.trim();
                            int remaining = MAX_OUTPUT - length(sections);
                            if (remaining <= 0) { skipped.add(name + " (output limit)"); continue; }
                            sections.add(section.length() > remaining ? section.substring(0, remaining) : section);
                            extracted++;
                        }
                    } catch (Exception parseError) {
                        skipped.add(name + " (parse error)");
                    }
                } else {
                    skipped.add(name + " (unsupported binary format)");
                }
            }
        }
        StringBuilder result = new StringBuilder("[ZIP archive summary]\nEntries: ").append(entries)
                .append("\nExtracted text files: ").append(extracted)
                .append("\nExpanded data: ").append(expanded).append(" bytes\n");
        for (String section : sections) {
            if (result.length() + section.length() > MAX_OUTPUT) break;
            result.append(section);
        }
        if (!skipped.isEmpty()) {
            result.append("\n\n[Files not text-extracted: ");
            int count = Math.min(skipped.size(), 40);
            for (int i = 0; i < count; i++) { if (i > 0) result.append("; "); result.append(skipped.get(i)); }
            if (skipped.size() > count) result.append("; and ").append(skipped.size() - count).append(" more");
            result.append("]\n");
        }
        if (extracted == 0) result.append("\nNo supported text content was found in the archive. The archive manifest is shown above.");
        if (result.length() > MAX_OUTPUT) return result.substring(0, MAX_OUTPUT) + "\n[Archive output truncated.]";
        return result.toString();
    }

    private static boolean isSafePath(String path) {
        if (path == null || path.isEmpty() || path.startsWith("/") || path.indexOf('\\') >= 0 || path.indexOf('\0') >= 0) return false;
        String lower = path.toLowerCase(Locale.ROOT);
        if (lower.matches("^[a-z]:.*")) return false;
        for (String part : path.split("/")) if ("..".equals(part)) return false;
        return true;
    }

    private static String extension(String name) { int dot = name.lastIndexOf('.'); return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT); }
    private static boolean isTextFormat(String ext) { return "txt".equals(ext) || "md".equals(ext) || "markdown".equals(ext) || "csv".equals(ext) || "json".equals(ext) || "xml".equals(ext) || "html".equals(ext) || "htm".equals(ext) || "yml".equals(ext) || "yaml".equals(ext) || "log".equals(ext) || "js".equals(ext) || "ts".equals(ext) || "py".equals(ext) || "java".equals(ext) || "kt".equals(ext) || "css".equals(ext); }
    private static boolean isStructuredFormat(String ext) { return "pdf".equals(ext) || "docx".equals(ext) || "xlsx".equals(ext) || "pptx".equals(ext); }
    private static int length(List<String> values) { int total = 0; for (String value : values) total += value.length(); return total; }
}
