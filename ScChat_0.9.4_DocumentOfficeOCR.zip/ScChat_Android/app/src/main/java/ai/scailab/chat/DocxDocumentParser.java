package ai.scailab.chat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import javax.xml.XMLConstants;
import javax.xml.parsers.SAXParserFactory;

final class DocxDocumentParser {
    private static final int MAX_DOCX_BYTES = 10 * 1024 * 1024;
    private static final int MAX_DOCX_XML_BYTES = 16 * 1024 * 1024;
    private static final int MAX_DOCX_TOTAL_EXPANDED_BYTES = 32 * 1024 * 1024;
    private static final int MAX_DOCX_ENTRIES = 512;
    private static final int MAX_DOCUMENT_CHARS = 120000;

    private DocxDocumentParser() { }

    static String extractText(byte[] docxBytes) throws Exception {
        if (docxBytes == null || docxBytes.length == 0) {
            throw new IllegalArgumentException("DOCX 文件为空。");
        }
        if (docxBytes.length > MAX_DOCX_BYTES) {
            throw new IllegalArgumentException("DOCX 文件超过 10 MB 限制。");
        }
        byte[] documentXml = readDocumentXml(docxBytes);
        if (documentXml == null || documentXml.length == 0) {
            throw new IllegalArgumentException("DOCX 文件缺少有效的 Word 正文。");
        }

        String xmlProbe = new String(documentXml, StandardCharsets.UTF_8).toUpperCase(Locale.ROOT);
        if (xmlProbe.contains("<!DOCTYPE") || xmlProbe.contains("<!ENTITY")) {
            throw new IllegalArgumentException("DOCX 正文包含不允许的 XML 实体声明。");
        }
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
        factory.setFeature("http://xml.org/sax/features/external-general-entities", false);
        factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        DocxContentHandler handler = new DocxContentHandler(MAX_DOCUMENT_CHARS);
        factory.newSAXParser().parse(new ByteArrayInputStream(documentXml), handler);
        return handler.getDocumentText();
    }

    private static byte[] readDocumentXml(byte[] zipBytes) throws Exception {
        try (ZipInputStream zip = new ZipInputStream(new ByteArrayInputStream(zipBytes))) {
            ZipEntry entry;
            int entryCount = 0;
            long totalExpanded = 0;
            while ((entry = zip.getNextEntry()) != null) {
                entryCount++;
                if (entryCount > MAX_DOCX_ENTRIES) {
                    throw new IllegalArgumentException("DOCX 内部条目数量异常。");
                }
                boolean target = "word/document.xml".equals(entry.getName());
                if (target && entry.getSize() > MAX_DOCX_XML_BYTES) {
                    throw new IllegalArgumentException("DOCX 正文 XML 解压后超过安全限制。");
                }
                ByteArrayOutputStream output = target ? new ByteArrayOutputStream() : null;
                byte[] buffer = new byte[8192];
                int count;
                while ((count = zip.read(buffer)) != -1) {
                    totalExpanded += count;
                    if (totalExpanded > MAX_DOCX_TOTAL_EXPANDED_BYTES) {
                        throw new IllegalArgumentException("DOCX 解压数据超过安全限制。");
                    }
                    if (target) {
                        if (output.size() + count > MAX_DOCX_XML_BYTES) {
                            throw new IllegalArgumentException("DOCX 正文 XML 解压后超过安全限制。");
                        }
                        output.write(buffer, 0, count);
                    }
                }
                if (target) return output.toByteArray();
            }
        }
        return null;
    }
}
