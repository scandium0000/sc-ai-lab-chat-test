package ai.scailab.chat;

import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXException;
import java.util.ArrayList;
import java.util.List;

final class DocxContentHandler extends DefaultHandler {
    private final int maxChars;
    private final StringBuilder output = new StringBuilder();
    private StringBuilder paragraph;
    private StringBuilder cell;
    private String paragraphStyle = "";
    private boolean inParagraph;
    private boolean inText;
    private boolean inCell;
    private boolean inTable;
    private boolean numberedParagraph;
    private List<String> currentRow;
    private List<List<String>> tableRows;
    private boolean truncated;
    private int tableCount;

    DocxContentHandler(int maxChars) {
        this.maxChars = maxChars;
    }

    private String elementName(String localName, String qName) {
        if (localName != null && !localName.isEmpty()) return localName;
        int separator = qName == null ? -1 : qName.indexOf(':');
        return separator >= 0 ? qName.substring(separator + 1) : qName;
    }

    private String attributeValue(Attributes attributes, String wanted) {
        for (int i = 0; i < attributes.getLength(); i++) {
            String local = attributes.getLocalName(i);
            String qName = attributes.getQName(i);
            if (wanted.equals(local) || (qName != null && qName.endsWith(":" + wanted))) {
                return attributes.getValue(i);
            }
        }
        return "";
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) {
        String name = elementName(localName, qName);
        if ("tbl".equals(name)) {
            if (!inTable) tableRows = new ArrayList<>();
            inTable = true;
        } else if ("tr".equals(name) && inTable) {
            currentRow = new ArrayList<>();
        } else if ("tc".equals(name) && inTable) {
            cell = new StringBuilder();
            inCell = true;
        } else if ("p".equals(name)) {
            paragraph = new StringBuilder();
            paragraphStyle = "";
            numberedParagraph = false;
            inParagraph = true;
        } else if ("pStyle".equals(name) && inParagraph) {
            paragraphStyle = attributeValue(attributes, "val");
        } else if ("numPr".equals(name) && inParagraph) {
            numberedParagraph = true;
        } else if ("t".equals(name) && inParagraph) {
            inText = true;
        } else if ("tab".equals(name) && inParagraph && paragraph != null) {
            paragraph.append('\t');
        } else if (("br".equals(name) || "cr".equals(name)) && inParagraph && paragraph != null) {
            paragraph.append('\n');
        }
    }

    @Override
    public void characters(char[] chars, int start, int length) {
        if (inText && paragraph != null && length > 0) paragraph.append(chars, start, length);
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        String name = elementName(localName, qName);
        if ("t".equals(name)) {
            inText = false;
        } else if ("p".equals(name) && inParagraph) {
            finishParagraph();
        } else if ("tc".equals(name) && inTable && currentRow != null) {
            currentRow.add(cell == null ? "" : cell.toString().trim());
            cell = null;
            inCell = false;
        } else if ("tr".equals(name) && inTable && currentRow != null) {
            tableRows.add(currentRow);
            currentRow = null;
        } else if ("tbl".equals(name) && inTable) {
            finishTable();
            inTable = false;
        }
    }

    private void finishParagraph() {
        String value = paragraph == null ? "" : paragraph.toString().trim();
        if (!value.isEmpty()) {
            if (inCell && cell != null) {
                if (cell.length() > 0) cell.append("<br>");
                cell.append(value);
            } else {
                String style = paragraphStyle == null ? "" : paragraphStyle;
                java.util.regex.Matcher heading = java.util.regex.Pattern.compile("(?i)^Heading([1-6])$").matcher(style);
                if ("Title".equalsIgnoreCase(style)) value = "# " + value;
                else if ("Subtitle".equalsIgnoreCase(style)) value = "## " + value;
                else if (heading.matches()) value = repeatHash(Integer.parseInt(heading.group(1))) + " " + value;
                else if (numberedParagraph || style.toLowerCase(java.util.Locale.ROOT).contains("listparagraph")) value = "- " + value;
                appendOutput(value + "\n\n");
            }
        }
        paragraph = null;
        paragraphStyle = "";
        inParagraph = false;
        inText = false;
    }

    private String repeatHash(int count) {
        StringBuilder value = new StringBuilder();
        for (int i = 0; i < count; i++) value.append('#');
        return value.toString();
    }

    private void finishTable() {
        if (tableRows == null || tableRows.isEmpty()) return;
        tableCount++;
        appendOutput("[Table " + tableCount + "]\n");
        int columns = 0;
        for (List<String> row : tableRows) columns = Math.max(columns, row.size());
        if (columns > 0) {
            for (int rowIndex = 0; rowIndex < tableRows.size(); rowIndex++) {
                List<String> row = tableRows.get(rowIndex);
                StringBuilder line = new StringBuilder("| ");
                for (int column = 0; column < columns; column++) {
                    if (column > 0) line.append(" | ");
                    String value = column < row.size() ? row.get(column) : "";
                    line.append(value.replace("|", "\\|").replace("\n", "<br>"));
                }
                line.append(" |\n");
                appendOutput(line.toString());
                if (rowIndex == 0 && tableRows.size() > 1) {
                    StringBuilder divider = new StringBuilder("| ");
                    for (int column = 0; column < columns; column++) {
                        if (column > 0) divider.append(" | ");
                        divider.append("---");
                    }
                    divider.append(" |\n");
                    appendOutput(divider.toString());
                }
            }
        }
        appendOutput("\n");
        tableRows = null;
    }

    private void appendOutput(String value) {
        if (truncated || value == null || value.isEmpty()) return;
        int remaining = maxChars - output.length();
        if (remaining <= 0) {
            truncated = true;
            return;
        }
        if (value.length() > remaining) {
            output.append(value, 0, remaining);
            truncated = true;
        } else {
            output.append(value);
        }
    }

    String getDocumentText() {
        if (truncated) output.append("\n\n[Document content truncated by Sc Chat: character limit reached.]\n");
        return output.toString().trim();
    }
}
