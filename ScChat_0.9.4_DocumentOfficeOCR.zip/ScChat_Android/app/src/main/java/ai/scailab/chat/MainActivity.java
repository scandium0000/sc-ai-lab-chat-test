package ai.scailab.chat;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.widget.EditText;
import android.widget.FrameLayout;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.net.URLConnection;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

import androidx.core.content.FileProvider;
import androidx.exifinterface.media.ExifInterface;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

public final class MainActivity extends Activity {
    private static final String KEY_ALIAS = "scailab.chat.provider.keys.v1";
    private static final String SECRET_PREFS = "scailab_secure_provider_secrets";
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final int FILE_CHOOSER_REQUEST_CODE = 4105;
    private static final int SAVE_TEXT_FILE_REQUEST_CODE = 4106;
    private static final int CAMERA_CAPTURE_REQUEST_CODE = 4107;
    private static final int SAVE_REMOTE_FILE_REQUEST_CODE = 4108;
    private static final int MAX_EXPORT_BYTES = 8 * 1024 * 1024;
    private static final int MAX_PDF_BYTES = 10 * 1024 * 1024;
    private static final int MAX_PDF_TEXT_CHARS = 120000;
    private static final int MAX_REMOTE_DOWNLOAD_BYTES = 50 * 1024 * 1024;

    private WebView webView;
    private FrameLayout rootContainer;
    private WebViewAssetLoader assetLoader;
    private ValueCallback<Uri[]> fileChooserCallback;
    private volatile String pendingSaveContent;
    private volatile String pendingSaveMimeType;
    private volatile String pendingSaveFileName;
    private volatile File pendingCameraFile;
    private volatile String pendingRemoteDownloadUrl;
    private volatile String pendingRemoteDownloadName;
    private final ExecutorService networkExecutor = Executors.newCachedThreadPool();
    private final ConcurrentHashMap<String, HttpURLConnection> activeConnections = new ConcurrentHashMap<>();
    private final java.util.Set<String> cancelledRequests = ConcurrentHashMap.newKeySet();
    private volatile boolean activityDestroyed = false;
    private volatile boolean pdfBoxInitialized = false;
    private volatile boolean imeVisible = false;
    private boolean rendererGone = false;
    private boolean rendererRecoveryPending = false;
    private boolean activityResumed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            String cameraPath = savedInstanceState.getString("scchat.pending_camera_file", "");
            if (!cameraPath.isEmpty()) {
                File restoredCameraFile = new File(cameraPath);
                if (restoredCameraFile.isFile()) pendingCameraFile = restoredCameraFile;
            }
        }
        rootContainer = new FrameLayout(this);
        rootContainer.setBackgroundColor(isDarkMode() ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246));
        webView = new WebView(this);
        webView.setBackgroundColor(isDarkMode() ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246));
        rootContainer.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT));
        setContentView(rootContainer);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // The app handles system-bar and IME insets explicitly. This avoids relying
            // on OEM-specific adjustResize behavior inside Android WebView.
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
                            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        } else {
            // Legacy Android versions resize the content window when the IME opens.
            getWindow().setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                            | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        applySystemBars();
        applyWindowInsets();

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true); // Access is still gated by the Android document picker.
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        webView.addJavascriptInterface(new ScAiBridge(), "ScAiBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] requestedTypes = requestedMimeTypes(params);
                intent.setType(requestedTypes.length == 1 ? requestedTypes[0] : "*/*");
                if (requestedTypes.length > 1) intent.putExtra(Intent.EXTRA_MIME_TYPES, requestedTypes);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params != null && params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                    return true;
                } catch (Exception error) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("确定", (dialog, which) -> result.confirm())
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
                EditText input = new EditText(MainActivity.this);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.setSingleLine(true);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(message)
                        .setView(input)
                        .setPositiveButton("保存", (dialog, which) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("取消", (dialog, which) -> result.cancel())
                        .setOnCancelListener(dialog -> result.cancel())
                        .show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                dispatchNativeImeState();
                // A restored WebView may have a fresh JavaScript runtime. Let the
                // page reload any encrypted pending authorization after navigation.
                view.evaluateJavascript("window.__scaiNativeResume&&window.__scaiNativeResume();", null);
            }

            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equals(uri.getScheme()) && ASSET_HOST.equals(uri.getHost())) return false;
                if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                        // Keep the current application screen if no browser can handle the link.
                    }
                    return true;
                }
                return true;
            }

            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                android.util.Log.e("ScChatLifecycle", "WebView renderer exited. didCrash="
                        + (detail != null && detail.didCrash())
                        + ", priority=" + (detail == null ? "unknown" : detail.rendererPriorityAtExit()));
                if (view == webView) {
                    rendererGone = true;
                    if (rootContainer != null) rootContainer.removeView(view);
                    webView = null;
                    view.destroy();
                    // Recreate only after a renderer failure. The new Activity will
                    // restore the last saved WebView state or reload the local entry
                    // point; the account and workspace checkpoint live in localStorage.
                    runOnUiThread(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        if (activityResumed) recreate();
                        else rendererRecoveryPending = true;
                    });
                } else {
                    view.destroy();
                }
                return true;
            }
        });

        boolean restoredPage = false;
        if (savedInstanceState != null) {
            try {
                android.webkit.WebBackForwardList restored = webView.restoreState(savedInstanceState);
                restoredPage = restored != null && restored.getSize() > 0;
                android.util.Log.i("ScChatLifecycle", "WebView state restored=" + restoredPage);
            } catch (Exception error) {
                android.util.Log.w("ScChatLifecycle", "WebView state restore failed; loading the local app entry point.", error);
            }
        }
        if (!restoredPage) {
            webView.loadUrl("https://" + ASSET_HOST + "/assets/index.html");
        }
    }


    private String[] requestedMimeTypes(WebChromeClient.FileChooserParams params) {
        java.util.LinkedHashSet<String> types = new java.util.LinkedHashSet<>();
        if (params != null && params.getAcceptTypes() != null) {
            for (String raw : params.getAcceptTypes()) {
                if (raw == null) continue;
                for (String token : raw.split(",")) {
                    String value = token.trim().toLowerCase(java.util.Locale.ROOT);
                    if (value.isEmpty()) continue;
                    if (value.contains("/")) {
                        if (!"*/*".equals(value)) types.add(value);
                    } else if (value.startsWith(".")) {
                        switch (value) {
                            case ".pdf": types.add("application/pdf"); break;
                            case ".docx": types.add("application/vnd.openxmlformats-officedocument.wordprocessingml.document"); break;
                            case ".xlsx": types.add("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"); break;
                            case ".pptx": types.add("application/vnd.openxmlformats-officedocument.presentationml.presentation"); break;
                            case ".zip": types.add("application/zip"); break;
                            case ".txt": case ".log": types.add("text/plain"); break;
                            case ".md": case ".markdown": types.add("text/markdown"); break;
                            case ".csv": types.add("text/csv"); break;
                            case ".json": types.add("application/json"); break;
                            case ".js": case ".ts": types.add("application/javascript"); break;
                            case ".py": types.add("text/x-python"); break;
                            case ".java": case ".kt": types.add("text/x-java-source"); break;
                            case ".html": types.add("text/html"); break;
                            case ".css": types.add("text/css"); break;
                            case ".xml": types.add("application/xml"); break;
                            case ".yaml": case ".yml": types.add("text/yaml"); break;
                            default: break;
                        }
                    }
                }
            }
        }
        if (types.isEmpty()) {
            java.util.Collections.addAll(types, "image/*", "application/pdf", "text/plain", "text/markdown",
                    "text/csv", "application/json", "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/zip", "application/javascript", "text/x-python",
                    "text/x-java-source", "text/html", "text/css", "application/xml", "text/yaml");
        }
        return types.toArray(new String[0]);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_TEXT_FILE_REQUEST_CODE) {
            String content = pendingSaveContent;
            pendingSaveContent = null;
            pendingSaveMimeType = null;
            pendingSaveFileName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || content == null) {
                notifyFileSaveResult(false, "已取消保存。");
                return;
            }
            Uri destination = data.getData();
            networkExecutor.execute(() -> {
                try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
                    if (output == null) throw new IllegalStateException("无法打开保存位置。");
                    output.write(content.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                    notifyFileSaveResult(true, "文件已保存。");
                } catch (Exception error) {
                    String message = error.getMessage() == null ? "保存文件失败。" : error.getMessage();
                    notifyFileSaveResult(false, message.length() > 180 ? message.substring(0, 180) : message);
                }
            });
            return;
        }
        if (requestCode == SAVE_REMOTE_FILE_REQUEST_CODE) {
            String sourceUrl = pendingRemoteDownloadUrl;
            String fileName = pendingRemoteDownloadName;
            pendingRemoteDownloadUrl = null;
            pendingRemoteDownloadName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || sourceUrl == null) {
                notifyRemoteDownloadResult(false, "已取消下载。");
                return;
            }
            Uri destination = data.getData();
            networkExecutor.execute(() -> downloadRemoteFile(sourceUrl, destination, fileName));
            return;
        }
        if (requestCode == CAMERA_CAPTURE_REQUEST_CODE) {
            File capturedFile = pendingCameraFile;
            pendingCameraFile = null;
            if (resultCode == RESULT_OK && capturedFile != null && (!capturedFile.isFile() || capturedFile.length() <= 0)
                    && data != null && data.getExtras() != null && data.getExtras().get("data") instanceof Bitmap) {
                try (FileOutputStream output = new FileOutputStream(capturedFile)) {
                    ((Bitmap) data.getExtras().get("data")).compress(Bitmap.CompressFormat.JPEG, 88, output);
                } catch (Exception ignored) {
                    // Fall through to the standard empty-capture error below.
                }
            }
            if (resultCode != RESULT_OK || capturedFile == null || !capturedFile.isFile() || capturedFile.length() <= 0) {
                if (capturedFile != null) capturedFile.delete();
                notifyCameraCaptureResult(false, "", "", "已取消拍照或没有获得照片。");
                return;
            }
            networkExecutor.execute(() -> {
                try {
                    String dataUrl = encodeCameraPhoto(capturedFile);
                    notifyCameraCaptureResult(true, dataUrl, "ScChat_Camera_" + System.currentTimeMillis() + ".jpg", "");
                } catch (Exception error) {
                    String message = error.getMessage() == null ? "照片处理失败。" : error.getMessage();
                    notifyCameraCaptureResult(false, "", "", message.length() > 180 ? message.substring(0, 180) : message);
                } finally {
                    capturedFile.delete();
                }
            });
            return;
        }
        if (requestCode != FILE_CHOOSER_REQUEST_CODE) return;
        if (fileChooserCallback == null) return;
        Uri[] results = null;
        if (resultCode == RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                int count = data.getClipData().getItemCount();
                results = new Uri[count];
                for (int i = 0; i < count; i++) results[i] = data.getClipData().getItemAt(i).getUri();
            } else if (data.getData() != null) {
                results = new Uri[]{data.getData()};
            }
        }
        fileChooserCallback.onReceiveValue(results);
        fileChooserCallback = null;
    }

    private void launchCameraCapture() {
        if (activityDestroyed || isFinishing()) return;
        if (pendingCameraFile != null) {
            notifyCameraCaptureResult(false, "", "", "相机正在使用，请先完成当前拍摄。");
            return;
        }
        try {
            File cameraDir = new File(getCacheDir(), "camera");
            if (!cameraDir.exists() && !cameraDir.mkdirs()) {
                throw new IllegalStateException("无法创建相机临时目录。");
            }
            File output = File.createTempFile("scchat_capture_", ".jpg", cameraDir);
            pendingCameraFile = output;
            Uri outputUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", output);
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, outputUri);
            intent.setClipData(ClipData.newUri(getContentResolver(), "Sc Chat camera output", outputUri));
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_CAPTURE_REQUEST_CODE);
        } catch (Exception error) {
            File pending = pendingCameraFile;
            pendingCameraFile = null;
            if (pending != null) pending.delete();
            String message = error.getMessage() == null ? "无法启动手机相机。" : error.getMessage();
            notifyCameraCaptureResult(false, "", "", message.length() > 180 ? message.substring(0, 180) : message);
        }
    }

    private String encodeCameraPhoto(File photoFile) throws Exception {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(photoFile.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IllegalArgumentException("相机返回的图片无法解码。");

        int sample = 1;
        int longest = Math.max(bounds.outWidth, bounds.outHeight);
        while (longest / sample > 1600) sample *= 2;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = sample;
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeFile(photoFile.getAbsolutePath(), options);
        if (bitmap == null) throw new IllegalArgumentException("无法读取拍摄的照片。");

        try {
            int orientation = new ExifInterface(photoFile.getAbsolutePath()).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
            Matrix orientationMatrix = new Matrix();
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90: orientationMatrix.postRotate(90); break;
                case ExifInterface.ORIENTATION_ROTATE_180: orientationMatrix.postRotate(180); break;
                case ExifInterface.ORIENTATION_ROTATE_270: orientationMatrix.postRotate(270); break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL: orientationMatrix.preScale(-1, 1); break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL: orientationMatrix.preScale(1, -1); break;
                case ExifInterface.ORIENTATION_TRANSPOSE: orientationMatrix.setRotate(90); orientationMatrix.postScale(-1, 1); break;
                case ExifInterface.ORIENTATION_TRANSVERSE: orientationMatrix.setRotate(270); orientationMatrix.postScale(-1, 1); break;
                default: break;
            }
            if (!orientationMatrix.isIdentity()) {
                Bitmap oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), orientationMatrix, true);
                if (oriented != bitmap) bitmap.recycle();
                bitmap = oriented;
            }

            int quality = 84;
            byte[] jpeg;
            while (true) {
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output);
                jpeg = output.toByteArray();
                if (jpeg.length <= 650 * 1024 || quality <= 68) break;
                quality -= 8;
            }
            while (jpeg.length > 650 * 1024 && Math.max(bitmap.getWidth(), bitmap.getHeight()) > 900) {
                int newWidth = Math.max(1, bitmap.getWidth() * 3 / 4);
                int newHeight = Math.max(1, bitmap.getHeight() * 3 / 4);
                Bitmap smaller = Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
                if (smaller != bitmap) bitmap.recycle();
                bitmap = smaller;
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 76, output);
                jpeg = output.toByteArray();
            }
            if (jpeg.length > 650 * 1024) throw new IllegalArgumentException("照片压缩后仍然过大，请尝试降低相机分辨率。");
            return "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP);
        } finally {
            if (!bitmap.isRecycled()) bitmap.recycle();
        }
    }

    private void notifyCameraCaptureResult(boolean success, String dataUrl, String fileName, String message) {
        WebView target = webView;
        if (target == null || activityDestroyed) return;
        String js = "window.__scaiCameraCaptureResult&&window.__scaiCameraCaptureResult("
                + success + "," + JSONObject.quote(dataUrl == null ? "" : dataUrl)
                + "," + JSONObject.quote(fileName == null ? "" : fileName)
                + "," + JSONObject.quote(message == null ? "" : message) + ");";
        target.post(() -> target.evaluateJavascript(js, null));
    }

    private String sanitizeDownloadName(String name) {
        String value = name == null ? "generated-file" : name.trim();
        value = value.replaceAll("[\\/:*?\"<>|\\p{Cntrl}]", "_");
        if (value.isEmpty() || value.equals(".")) value = "generated-file";
        return value.length() > 120 ? value.substring(0, 120) : value;
    }

    private String guessDownloadMime(String name) {
        String type = URLConnection.guessContentTypeFromName(name);
        return type == null ? "application/octet-stream" : type;
    }

    private void downloadRemoteFile(String sourceUrl, Uri destination, String fileName) {
        HttpURLConnection connection = null;
        try (OutputStream output = getContentResolver().openOutputStream(destination, "w")) {
            if (output == null) throw new IllegalStateException("无法打开保存位置。");
            URL current = new URL(sourceUrl);
            int redirects = 0;
            while (true) {
                if (!"https".equalsIgnoreCase(current.getProtocol()) || Uri.parse(current.toString()).getUserInfo() != null) throw new IllegalArgumentException("下载链接必须使用 HTTPS。");
                connection = (HttpURLConnection) current.openConnection();
                connection.setInstanceFollowRedirects(false);
                connection.setConnectTimeout(20000);
                connection.setReadTimeout(60000);
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Accept", "application/octet-stream, */*");
                connection.setRequestProperty("User-Agent", "ScChat/0.9.4 Android");
                int status = connection.getResponseCode();
                if (status >= 300 && status < 400) {
                    String location = connection.getHeaderField("Location");
                    connection.disconnect(); connection = null;
                    if (location == null || ++redirects > 4) throw new IllegalStateException("下载服务器重定向次数过多或缺少目标地址。");
                    current = new URL(current, location);
                    continue;
                }
                if (status < 200 || status >= 300) throw new IllegalStateException("下载失败，服务器返回 HTTP " + status + "。");
                long contentLength = connection.getContentLengthLong();
                if (contentLength > MAX_REMOTE_DOWNLOAD_BYTES) throw new IllegalArgumentException("文件超过 50 MB 下载限制。");
                long total = 0;
                try (InputStream input = connection.getInputStream()) {
                    byte[] buffer = new byte[16384];
                    int read;
                    while ((read = input.read(buffer)) != -1) {
                        total += read;
                        if (total > MAX_REMOTE_DOWNLOAD_BYTES) throw new IllegalArgumentException("文件超过 50 MB 下载限制。");
                        output.write(buffer, 0, read);
                    }
                }
                output.flush();
                notifyRemoteDownloadResult(true, "文件已下载并保存：" + fileName);
                break;
            }
        } catch (Exception error) {
            try { DocumentsContract.deleteDocument(getContentResolver(), destination); } catch (Exception ignored) { /* Some document providers do not support deletion. */ }
            String message = error.getMessage() == null ? "下载文件失败。" : error.getMessage();
            notifyRemoteDownloadResult(false, message.length() > 180 ? message.substring(0, 180) : message);
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void notifyRemoteDownloadResult(boolean success, String message) {
        WebView target = webView;
        if (target == null || activityDestroyed) return;
        String js = "window.__scaiRemoteDownloadResult&&window.__scaiRemoteDownloadResult(" + success + ","
                + JSONObject.quote(message == null ? "" : message) + ");";
        target.post(() -> target.evaluateJavascript(js, null));
    }

    private void notifyFileSaveResult(boolean success, String message) {
        WebView target = webView;
        if (target == null || activityDestroyed) return;
        String js = "window.__scaiFileSaveResult&&window.__scaiFileSaveResult(" + success + ","
                + JSONObject.quote(message == null ? "" : message) + ")";
        target.post(() -> target.evaluateJavascript(js, null));
    }

    private String extractPdfText(String encodedPdf) {
        if (encodedPdf == null || encodedPdf.length() > 14 * 1024 * 1024) {
            return "__PDF_ERROR__PDF 文件过大，最大支持 10 MB。";
        }
        try {
            byte[] pdfBytes = Base64.decode(encodedPdf, Base64.DEFAULT);
            if (pdfBytes.length == 0 || pdfBytes.length > MAX_PDF_BYTES) {
                return "__PDF_ERROR__PDF 文件为空或超过 10 MB 限制。";
            }
            return extractPdfTextBytes(pdfBytes);
        } catch (Exception error) {
            String message = error.getMessage() == null ? "PDF 解析失败。" : error.getMessage();
            if (message.length() > 240) message = message.substring(0, 240);
            return "__PDF_ERROR__" + message;
        }
    }

    private String extractPdfTextBytes(byte[] pdfBytes) throws Exception {
        if (!pdfBoxInitialized) {
            synchronized (MainActivity.class) {
                if (!pdfBoxInitialized) {
                    PDFBoxResourceLoader.init(getApplicationContext());
                    pdfBoxInitialized = true;
                }
            }
        }
        java.util.List<Integer> pagesNeedingOcr = new java.util.ArrayList<>();
        int pageCount;
        int pagesToRead;
        String[] pageTexts;
        try (PDDocument document = PDDocument.load(new ByteArrayInputStream(pdfBytes))) {
            if (document.isEncrypted()) throw new IllegalArgumentException("暂不支持加密或受密码保护的 PDF。");
            pageCount = document.getNumberOfPages();
            if (pageCount <= 0) return "";
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setSortByPosition(true);
            pagesToRead = Math.min(pageCount, 40);
            pageTexts = new String[pagesToRead];
            for (int page = 1; page <= pagesToRead; page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);
                String pageText = stripper.getText(document);
                if (pageText != null && !pageText.trim().isEmpty()) {
                    pageTexts[page - 1] = pageText.trim();
                } else {
                    pagesNeedingOcr.add(page - 1);
                }
            }
        }
        if (!pagesNeedingOcr.isEmpty()) {
            // OCR fills only pages without an embedded text layer, preserving document order.
            performPdfOcr(pdfBytes, pageCount, pagesNeedingOcr, pageTexts);
        }

        StringBuilder output = new StringBuilder();
        for (int index = 0; index < pagesToRead; index++) {
            String pageText = pageTexts[index];
            if (pageText == null || pageText.trim().isEmpty()) continue;
            boolean ocrPage = pagesNeedingOcr.contains(index);
            output.append(ocrPage ? "[OCR Page " : "[Page ").append(index + 1).append("]\n")
                    .append(pageText).append("\n\n");
            if (output.length() >= MAX_PDF_TEXT_CHARS) break;
        }
        if (pageCount > pagesToRead) {
            output.append("\n[Document note: ").append(pageCount - pagesToRead)
                    .append(" additional pages were not extracted. Maximum: 40 pages.]\n");
        }
        if (pagesNeedingOcr.size() > 20) {
            output.append("\n[OCR limit: processed at most 20 of ").append(pagesNeedingOcr.size())
                    .append(" scanned pages.]\n");
        }
        if (output.toString().trim().isEmpty()) {
            throw new IllegalArgumentException("PDF 未检测到可提取文字，且本地 OCR 没有识别出内容。请尝试更清晰的扫描件。");
        }
        if (!pagesNeedingOcr.isEmpty()) output.insert(0, "[PDF OCR: processed locally on this device where needed]\n");
        return clipPdfText(output.toString());
    }

    private String clipPdfText(String value) {
        if (value.length() <= MAX_PDF_TEXT_CHARS) return value;
        return value.substring(0, MAX_PDF_TEXT_CHARS) + "\n[Document content truncated by Sc Chat.]";
    }

    private void performPdfOcr(byte[] pdfBytes, int pageCount, java.util.List<Integer> pageNumbers,
                               String[] pageTexts) throws Exception {
        File tempPdf = File.createTempFile("scchat_ocr_", ".pdf", getCacheDir());
        TextRecognizer chinese = null;
        TextRecognizer latin = null;
        try {
            try (FileOutputStream fileOutput = new FileOutputStream(tempPdf)) { fileOutput.write(pdfBytes); }
            chinese = TextRecognition.getClient(new ChineseTextRecognizerOptions.Builder().build());
            latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            try (ParcelFileDescriptor descriptor = ParcelFileDescriptor.open(tempPdf, ParcelFileDescriptor.MODE_READ_ONLY);
                 PdfRenderer renderer = new PdfRenderer(descriptor)) {
                int pages = Math.min(pageNumbers.size(), 20);
                for (int index = 0; index < pages; index++) {
                    int pageNumber = pageNumbers.get(index);
                    if (pageNumber < 0 || pageNumber >= renderer.getPageCount() || pageNumber >= pageTexts.length) continue;
                    PdfRenderer.Page page = renderer.openPage(pageNumber);
                    Bitmap bitmap = null;
                    try {
                        float scale = Math.min(2.0f, 1800f / Math.max(page.getWidth(), page.getHeight()));
                        int width = Math.max(1, Math.round(page.getWidth() * scale));
                        int height = Math.max(1, Math.round(page.getHeight() * scale));
                        bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
                        page.render(bitmap, new Rect(0, 0, width, height), null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        InputImage input = InputImage.fromBitmap(bitmap, 0);
                        String chineseText = "";
                        String latinText = "";
                        try { Text detected = Tasks.await(chinese.process(input), 45, TimeUnit.SECONDS); chineseText = detected.getText(); }
                        catch (Exception ignored) { /* Fall back to the Latin model below. */ }
                        String selected = chineseText;
                        if (!containsCjk(chineseText)) {
                            try { Text detected = Tasks.await(latin.process(input), 45, TimeUnit.SECONDS); latinText = detected.getText(); }
                            catch (Exception ignored) { /* Keep any text found by the Chinese model. */ }
                            if (scoreOcrText(latinText) > scoreOcrText(chineseText)) selected = latinText;
                        }
                        if (!selected.trim().isEmpty()) pageTexts[pageNumber] = selected.trim();
                    } finally {
                        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
                        page.close();
                    }
                }
            }
        } finally {
            if (chinese != null) chinese.close();
            if (latin != null) latin.close();
            if (tempPdf.exists()) tempPdf.delete();
        }
    }

    private boolean containsCjk(String value) {
        if (value == null) return false;
        for (int i = 0; i < value.length(); i++) {
            Character.UnicodeBlock block = Character.UnicodeBlock.of(value.charAt(i));
            if (block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
                    || block == Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
                    || block == Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS) return true;
        }
        return false;
    }

    private int scoreOcrText(String value) {
        if (value == null) return 0;
        int score = 0;
        for (int i = 0; i < value.length(); i++) if (!Character.isWhitespace(value.charAt(i))) score++;
        return score;
    }

    private String extractStructuredFile(String format, String base64Content) {
        try {
            if (base64Content == null || base64Content.length() > 22 * 1024 * 1024) throw new IllegalArgumentException("文件超过 15 MB 限制。");
            byte[] bytes = Base64.decode(base64Content, Base64.DEFAULT);
            if ("xlsx".equals(format)) return StructuredDocumentParser.extractXlsxText(bytes);
            if ("pptx".equals(format)) return StructuredDocumentParser.extractPptxText(bytes);
            if ("zip".equals(format)) {
                return ArchiveDocumentParser.extractText(bytes, (name, data) -> extractArchiveEntryText(name, data));
            }
            throw new IllegalArgumentException("不支持的结构化文件格式。");
        } catch (Exception error) {
            String message = error.getMessage() == null ? "文件解析失败。" : error.getMessage();
            if (message.length() > 240) message = message.substring(0, 240);
            return "__STRUCTURED_ERROR__" + message;
        }
    }

    private String extractArchiveEntryText(String name, byte[] data) throws Exception {
        String lower = name.toLowerCase(java.util.Locale.ROOT);
        if (lower.endsWith(".docx")) return DocxDocumentParser.extractText(data);
        if (lower.endsWith(".xlsx")) return StructuredDocumentParser.extractXlsxText(data);
        if (lower.endsWith(".pptx")) return StructuredDocumentParser.extractPptxText(data);
        if (lower.endsWith(".pdf")) return extractPdfTextBytes(data);
        if (lower.matches(".*\\.(txt|md|markdown|csv|json|xml|html|htm|yml|yaml|log|js|ts|py|java|kt|css)$")) {
            if (data.length > 2 * 1024 * 1024) throw new IllegalArgumentException("文本文件超过 ZIP 单个文件解析限制。");
            return new String(data, StandardCharsets.UTF_8);
        }
        return "";
    }

    private String extractDocxText(String encodedDocx) {
        if (encodedDocx == null || encodedDocx.length() > 14 * 1024 * 1024) {
            return "__DOCX_ERROR__DOCX 文件过大，最大支持 10 MB。";
        }
        try {
            byte[] docxBytes = Base64.decode(encodedDocx, Base64.DEFAULT);
            return DocxDocumentParser.extractText(docxBytes);
        } catch (Exception error) {
            String message = error.getMessage() == null ? "DOCX 解析失败。" : error.getMessage();
            if (message.length() > 240) message = message.substring(0, 240);
            return "__DOCX_ERROR__" + message;
        }
    }

    private boolean isDarkMode() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private void applySystemBars() {
        Window window = getWindow();
        boolean dark = isDarkMode();
        int background = dark ? Color.rgb(20, 24, 32) : Color.rgb(250, 249, 246);
        window.setStatusBarColor(Color.TRANSPARENT);
        window.setNavigationBarColor(background);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            window.setStatusBarContrastEnforced(false);
            window.setNavigationBarContrastEnforced(false);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                int appearance = 0;
                if (!dark) {
                    appearance = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                }
                int mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                        | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                controller.setSystemBarsAppearance(appearance, mask);
            }
        } else {
            int flags = 0;
            if (!dark) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) flags |= View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            }
            window.getDecorView().setSystemUiVisibility(flags);
        }
        if (rootContainer != null) rootContainer.setBackgroundColor(background);
        if (webView != null) webView.setBackgroundColor(background);
    }

    private void applyWindowInsets() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            rootContainer.setOnApplyWindowInsetsListener((view, insets) -> {
                int insetTypes = WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout();
                android.graphics.Insets bars = insets.getInsets(insetTypes);
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                boolean keyboardVisible = insets.isVisible(WindowInsets.Type.ime());

                // Lay out the WebView inside the visible app area. The top margin
                // protects the toolbar from the status bar; the bottom margin follows
                // the IME when the keyboard opens and returns to the navigation bar
                // inset when it closes.
                int bottomInset = Math.max(bars.bottom, keyboardVisible ? ime.bottom : 0);
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) webView.getLayoutParams();
                if (params.topMargin != bars.top || params.bottomMargin != bottomInset
                        || params.leftMargin != bars.left || params.rightMargin != bars.right) {
                    params.setMargins(bars.left, bars.top, bars.right, bottomInset);
                    webView.setLayoutParams(params);
                }

                imeVisible = keyboardVisible;
                android.util.Log.d("ScChatInsets", "top=" + bars.top
                        + " bottom=" + bars.bottom + " ime=" + ime.bottom
                        + " visible=" + keyboardVisible
                        + " webViewHeight=" + webView.getHeight());
                dispatchNativeImeState();
                return WindowInsets.CONSUMED;
            });
            rootContainer.requestApplyInsets();
        }
        // API 26-29 use the platform's non-edge-to-edge content area and adjustResize.
        // Their WebView viewport is resized by the system when the keyboard is shown.
    }

    private void dispatchNativeImeState() {
        if (webView == null || activityDestroyed) return;
        webView.post(() -> {
            if (webView == null || activityDestroyed) return;
            String script = "if(window.__scaiNativeImeChanged){window.__scaiNativeImeChanged("
                    + imeVisible + ");}";
            webView.evaluateJavascript(script, null);
        });
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && rootContainer != null) rootContainer.requestApplyInsets();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        applySystemBars();
        if (rootContainer != null) rootContainer.requestApplyInsets();
    }

    private SecretKey getOrCreateSecretKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) return (SecretKey) keyStore.getKey(KEY_ALIAS, null);
        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build());
        return generator.generateKey();
    }

    private SharedPreferences secretPrefs() {
        return getSharedPreferences(SECRET_PREFS, Context.MODE_PRIVATE);
    }

    private String readSecret(String key) throws Exception {
        String stored = secretPrefs().getString(key, null);
        if (stored == null) return null;
        String[] parts = stored.split("\\.", 2);
        if (parts.length != 2) return null;
        byte[] iv = android.util.Base64.decode(parts[0], android.util.Base64.NO_WRAP);
        byte[] encrypted = android.util.Base64.decode(parts[1], android.util.Base64.NO_WRAP);
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateSecretKey(), new GCMParameterSpec(128, iv));
        return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
    }

    private boolean writeSecret(String key, String value) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateSecretKey());
        byte[] encrypted = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
        String encoded = android.util.Base64.encodeToString(cipher.getIV(), android.util.Base64.NO_WRAP)
                + "." + android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP);
        return secretPrefs().edit().putString(key, encoded).commit();
    }

    private void emitNativeEvent(String id, String type, String payload) {
        if (activityDestroyed || webView == null) return;
        String js = "window.__scaiNativeEvent && window.__scaiNativeEvent(" + JSONObject.quote(id) + ","
                + JSONObject.quote(type) + "," + JSONObject.quote(payload == null ? "" : payload) + ");";
        runOnUiThread(() -> {
            if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private String resolveCredential(String credentialRef) throws Exception {
        if (credentialRef == null) throw new IllegalArgumentException("Missing API credential.");
        if (credentialRef.startsWith("literal:")) return credentialRef.substring("literal:".length());
        if (credentialRef.startsWith("secret:")) {
            String key = credentialRef.substring("secret:".length());
            boolean allowedProviderKey = key.startsWith("scailab.provider.key.");
            boolean allowedPollinationsToken = "scailab.oauth.pollinations.access_token".equals(key);
            if (!allowedProviderKey && !allowedPollinationsToken) {
                throw new IllegalArgumentException("Unsupported encrypted credential reference.");
            }
            String value = readSecret(key);
            if (value == null || value.isEmpty()) throw new IllegalStateException("API Key not found in Android Keystore storage.");
            return value;
        }
        throw new IllegalArgumentException("Unsupported credential reference.");
    }

    private void performChatRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
        HttpURLConnection connection = null;
        StringBuilder fullAnswer = new StringBuilder();
        try {
            if (cancelledRequests.remove(requestId)) return;
            Uri parsed = Uri.parse(endpoint);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IllegalArgumentException("Only HTTPS API endpoints are allowed.");
            }
            String credential = resolveCredential(credentialRef);
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("POST");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(25000);
            connection.setReadTimeout(120000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Bearer " + credential);
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            connection.setRequestProperty("Accept", "text/event-stream, application/json");
            activeConnections.put(requestId, connection);
            if (cancelledRequests.remove(requestId)) { connection.disconnect(); return; }
            byte[] body = bodyJson.getBytes(StandardCharsets.UTF_8);
            try (OutputStream output = connection.getOutputStream()) { output.write(body); output.flush(); }

            int status = connection.getResponseCode();
            InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            if (status >= 400) {
                String errorText = readAll(stream);
                String detail = extractApiError(errorText);
                throw new IllegalStateException("API 请求失败（HTTP " + status + "）：" + detail);
            }
            String contentType = connection.getContentType() == null ? "" : connection.getContentType().toLowerCase();
            if (contentType.contains("text/event-stream")) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("data:")) {
                            String data = line.substring(5).trim();
                            if ("[DONE]".equals(data)) break;
                            String piece = parseStreamPiece(data);
                            if (!piece.isEmpty()) {
                                fullAnswer.append(piece);
                                emitNativeEvent(requestId, "chunk", piece);
                            }
                        }
                    }
                }
            } else {
                String jsonText = readAll(stream);
                String content = extractJsonAnswer(jsonText);
                if (!content.isEmpty()) {
                    fullAnswer.append(content);
                    emitNativeEvent(requestId, "chunk", content);
                }
            }
            emitNativeEvent(requestId, "done", fullAnswer.toString());
        } catch (Exception error) {
            emitNativeEvent(requestId, "error", error.getMessage() == null ? "Network request failed." : error.getMessage());
        } finally {
            activeConnections.remove(requestId);
            cancelledRequests.remove(requestId);
            if (connection != null) connection.disconnect();
        }
    }

    private void performProviderTest(String requestId, String endpoint, String credentialRef) {
        HttpURLConnection connection = null;
        int status = 0;
        String body = "";
        try {
            Uri parsed = Uri.parse(endpoint);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) {
                throw new IllegalArgumentException("Only HTTPS API endpoints are allowed.");
            }
            String credential = resolveCredential(credentialRef);
            connection = (HttpURLConnection) new URL(endpoint).openConnection();
            connection.setRequestMethod("GET");
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(12000);
            connection.setReadTimeout(15000);
            connection.setRequestProperty("Authorization", "Bearer " + credential);
            connection.setRequestProperty("Accept", "application/json");
            status = connection.getResponseCode();
            InputStream response = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            body = readLimited(response, 65536);
        } catch (Exception error) {
            body = error.getMessage() == null ? "Provider connection test failed." : error.getMessage();
        } finally {
            if (connection != null) connection.disconnect();
        }
        emitProviderTestResult(requestId, status, body);
    }

    private String readLimited(InputStream stream, int maxChars) throws Exception {
        if (stream == null) return "";
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[2048];
            int read;
            while ((read = reader.read(buffer)) != -1) {
                int remaining = maxChars - text.length();
                if (remaining <= 0) break;
                text.append(buffer, 0, Math.min(read, remaining));
            }
        }
        return text.toString();
    }

    private void emitProviderTestResult(String requestId, int status, String body) {
        if (activityDestroyed || webView == null) return;
        String js = "window.__scaiProviderTestResult&&window.__scaiProviderTestResult("
                + JSONObject.quote(requestId) + "," + status + "," + JSONObject.quote(body == null ? "" : body) + ");";
        runOnUiThread(() -> {
            if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
        });
    }

    private String readAll(InputStream stream) throws Exception {
        if (stream == null) return "";
        StringBuilder text = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) text.append(line).append('\n');
        }
        return text.toString();
    }

    private String parseStreamPiece(String data) throws JSONException {
        JSONObject root = new JSONObject(data);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject delta = choice == null ? null : choice.optJSONObject("delta");
        String value = delta == null ? (choice == null ? "" : choice.optString("text", "")) : delta.optString("content", "");
        return value;
    }

    private String extractJsonAnswer(String jsonText) throws JSONException {
        JSONObject root = new JSONObject(jsonText);
        if (root.has("error")) throw new JSONException(root.optJSONObject("error") == null ? root.optString("error") : root.optJSONObject("error").optString("message"));
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject choice = choices.optJSONObject(0);
        JSONObject message = choice == null ? null : choice.optJSONObject("message");
        if (message == null) return choice == null ? "" : choice.optString("text", "");
        Object content = message.opt("content");
        if (content instanceof String) return (String) content;
        if (content instanceof JSONArray) {
            StringBuilder answer = new StringBuilder();
            JSONArray items = (JSONArray) content;
            for (int i = 0; i < items.length(); i++) {
                JSONObject item = items.optJSONObject(i);
                if (item == null) continue;
                String type = item.optString("type", "");
                String text = item.optString("text", "");
                if (!text.isEmpty()) answer.append(text).append("\n");
                String url = item.optString("url", item.optString("file_url", ""));
                if (url.startsWith("https://") && ("file".equals(type) || "file_url".equals(type) || item.has("filename"))) {
                    String name = item.optString("filename", "generated-file");
                    answer.append("\n[下载文件：").append(name.replace("]", "_")).append("](").append(url).append(")\n");
                }
            }
            return answer.toString().trim();
        }
        return content == null ? "" : String.valueOf(content);
    }

    private String extractApiError(String text) {
        try {
            JSONObject root = new JSONObject(text);
            JSONObject error = root.optJSONObject("error");
            return error == null ? root.optString("message", text) : error.optString("message", error.toString());
        } catch (Exception ignored) {
            return text.length() > 500 ? text.substring(0, 500) : text;
        }
    }

    private final class ScAiBridge {
        @JavascriptInterface
        public boolean saveTextFile(String fileName, String mimeType, String content) {
            if (content == null || activityDestroyed) return false;
            if (content.getBytes(StandardCharsets.UTF_8).length > MAX_EXPORT_BYTES) return false;
            String normalizedName = fileName == null ? "scailab-export.txt" : fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
            final String safeName = normalizedName.isEmpty() ? "scailab-export.txt" : normalizedName;
            final String safeMime = ("application/json".equals(mimeType) || "text/markdown".equals(mimeType)
                    || "text/plain".equals(mimeType)) ? mimeType : "text/plain";
            runOnUiThread(() -> {
                pendingSaveFileName = safeName;
                pendingSaveMimeType = safeMime;
                pendingSaveContent = content;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(safeMime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(intent, SAVE_TEXT_FILE_REQUEST_CODE);
                } catch (Exception error) {
                    pendingSaveContent = null;
                    pendingSaveMimeType = null;
                    pendingSaveFileName = null;
                    notifyFileSaveResult(false, "无法打开系统文件保存窗口。");
                }
            });
            return true;
        }

        @JavascriptInterface
        public void capturePhoto() {
            runOnUiThread(MainActivity.this::launchCameraCapture);
        }

        @JavascriptInterface
        public boolean setSecret(String key, String value) {
            if (!isAllowedSecretKey(key) || value == null) return false;
            try { return writeSecret(key, value); } catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public boolean hasSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            try { String value = readSecret(key); return value != null && !value.isEmpty(); }
            catch (Exception error) { return false; }
        }

        @JavascriptInterface
        public String getSecret(String key) {
            // Only the short-lived device-flow checkpoint is readable by JavaScript.
            // API tokens and provider credentials remain inside Android Keystore.
            if (!"scailab.oauth.pollinations.pending_device".equals(key)) return "";
            try {
                String value = readSecret(key);
                return value == null ? "" : value;
            } catch (Exception error) {
                android.util.Log.w("ScChatSecurity", "Unable to read an encrypted local credential.", error);
                return "";
            }
        }

        @JavascriptInterface
        public boolean removeSecret(String key) {
            if (!isAllowedSecretKey(key)) return false;
            return secretPrefs().edit().remove(key).commit();
        }

        @JavascriptInterface
        public void startRequest(String requestId, String endpoint, String credentialRef, String bodyJson) {
            if (requestId == null || requestId.length() > 120 || endpoint == null || bodyJson == null) {
                emitNativeEvent(requestId == null ? "" : requestId, "error", "Invalid API request.");
                return;
            }
            networkExecutor.execute(() -> performChatRequest(requestId, endpoint, credentialRef, bodyJson));
        }

        @JavascriptInterface
        public void cancelRequest(String requestId) {
            cancelledRequests.add(requestId);
            HttpURLConnection connection = activeConnections.remove(requestId);
            if (connection != null) connection.disconnect();
        }

        @JavascriptInterface
        public void testProvider(String requestId, String endpoint, String credentialRef) {
            if (requestId == null || requestId.length() > 120 || endpoint == null || credentialRef == null) {
                emitProviderTestResult(requestId == null ? "" : requestId, 0, "Invalid provider test request.");
                return;
            }
            networkExecutor.execute(() -> performProviderTest(requestId, endpoint, credentialRef));
        }

        @JavascriptInterface
        public void copyText(String text) {
            runOnUiThread(() -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (clipboard != null) clipboard.setPrimaryClip(ClipData.newPlainText("Sc Chat", text == null ? "" : text));
            });
        }

        @JavascriptInterface
        public void shareText(String title, String text) {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, title == null ? "Sc Chat" : title);
                intent.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                startActivity(Intent.createChooser(intent, "分享或保存聊天记录"));
            });
        }

        @JavascriptInterface
        public void extractPdfTextAsync(String requestId, String base64Pdf) {
            if (requestId == null || requestId.length() > 120 || base64Pdf == null) return;
            networkExecutor.execute(() -> {
                String result = MainActivity.this.extractPdfText(base64Pdf);
                if (activityDestroyed || webView == null) return;
                String js = "window.__scaiPdfResult&&window.__scaiPdfResult(" + JSONObject.quote(requestId)
                        + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> {
                    if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
                });
            });
        }

        @JavascriptInterface
        public void extractDocxTextAsync(String requestId, String base64Docx) {
            if (requestId == null || requestId.length() > 120 || base64Docx == null) return;
            networkExecutor.execute(() -> {
                String result = MainActivity.this.extractDocxText(base64Docx);
                if (activityDestroyed || webView == null) return;
                String js = "window.__scaiDocxResult&&window.__scaiDocxResult(" + JSONObject.quote(requestId)
                        + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> {
                    if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null);
                });
            });
        }

        @JavascriptInterface
        public void extractStructuredFileAsync(String requestId, String format, String base64Content) {
            if (requestId == null || requestId.length() > 120 || format == null || base64Content == null) return;
            networkExecutor.execute(() -> {
                String result = extractStructuredFile(format, base64Content);
                if (activityDestroyed || webView == null) return;
                String js = "window.__scaiStructuredResult&&window.__scaiStructuredResult(" + JSONObject.quote(requestId)
                        + "," + JSONObject.quote(result) + ");";
                runOnUiThread(() -> { if (!activityDestroyed && webView != null) webView.evaluateJavascript(js, null); });
            });
        }

        @JavascriptInterface
        public boolean saveRemoteGeneratedFile(String sourceUrl, String suggestedName) {
            if (activityDestroyed || sourceUrl == null || sourceUrl.length() > 4096) return false;
            final Uri parsed = Uri.parse(sourceUrl);
            if (!"https".equalsIgnoreCase(parsed.getScheme()) || parsed.getHost() == null || parsed.getUserInfo() != null) return false;
            final String safeName = sanitizeDownloadName(suggestedName);
            runOnUiThread(() -> {
                pendingRemoteDownloadUrl = sourceUrl;
                pendingRemoteDownloadName = safeName;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(guessDownloadMime(safeName));
                intent.putExtra(Intent.EXTRA_TITLE, safeName);
                try { startActivityForResult(intent, SAVE_REMOTE_FILE_REQUEST_CODE); }
                catch (Exception error) {
                    pendingRemoteDownloadUrl = null;
                    pendingRemoteDownloadName = null;
                    notifyRemoteDownloadResult(false, "无法打开系统文件保存窗口。");
                }
            });
            return true;
        }

        private boolean isAllowedSecretKey(String key) {
            if (key == null || key.length() > 180) return false;
            return key.startsWith("scailab.provider.key.")
                    || "scailab.oauth.pollinations.access_token".equals(key)
                    || "scailab.oauth.pollinations.pending_device".equals(key);
        }
    }

    @Override
    protected void onPause() {
        activityResumed = false;
        if (webView != null && !rendererGone) {
            // Persist the last workspace selection before Android potentially
            // reclaims this background process. localStorage writes are synchronous.
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            webView.onPause();
        }
        // The keyboard is not considered owned by the composer while the Activity
        // is backgrounded. Insets will be queried again on resume.
        imeVisible = false;
        super.onPause();
        android.util.Log.d("ScChatLifecycle", "Activity paused");
    }

    @Override
    protected void onResume() {
        super.onResume();
        activityResumed = true;
        if (rendererRecoveryPending && !isFinishing()) {
            rendererRecoveryPending = false;
            recreate();
            return;
        }
        if (webView != null && !rendererGone) {
            webView.onResume();
            if (rootContainer != null) rootContainer.requestApplyInsets();
            dispatchNativeImeState();
            // Resume a device authorization whose WebView timers may have been
            // throttled while the external browser was in the foreground.
            webView.evaluateJavascript("window.__scaiNativeResume&&window.__scaiNativeResume();", null);
        }
        android.util.Log.d("ScChatLifecycle", "Activity resumed without reloading the WebView");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (pendingCameraFile != null && pendingCameraFile.isFile()) {
            outState.putString("scchat.pending_camera_file", pendingCameraFile.getAbsolutePath());
        }
        if (webView != null && !rendererGone) {
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            webView.saveState(outState);
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (level >= ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN && webView != null && !rendererGone) {
            webView.evaluateJavascript("window.__scaiPersistUiState&&window.__scaiPersistUiState();", null);
            android.util.Log.i("ScChatLifecycle", "Saved workspace checkpoint while app is hidden; trim level=" + level);
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        pendingSaveContent = null;
        pendingSaveMimeType = null;
        pendingSaveFileName = null;
        if (fileChooserCallback != null) {
            fileChooserCallback.onReceiveValue(null);
            fileChooserCallback = null;
        }
        if (pendingCameraFile != null) {
            pendingCameraFile.delete();
            pendingCameraFile = null;
        }
        for (HttpURLConnection connection : activeConnections.values()) connection.disconnect();
        activeConnections.clear();
        cancelledRequests.clear();
        networkExecutor.shutdownNow();
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("ScAiBridge");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
