# Build Sc Chat 0.9.4 from an Android phone

1. Upload `ScChat_0.9.4_DocumentOfficeOCR.zip` to the root of your private GitHub repository.
2. Copy `build-from-zip-0.9.4.yml` to `.github/workflows/build-from-zip.yml`.
3. Open **Actions** and run **Build Sc Chat 0.9.4 APK**.
4. Download the `ScChat-0.9.4-debug` artifact from the completed workflow.

The workflow initializes Java, Node.js, and Python; discovers the Android SDK Manager on the GitHub-hosted runner; installs Android API 35 and Build Tools 35.0.0; runs JavaScript and Java document-parser tests; validates Android XML; builds the APK with Gradle 8.9; and verifies APK package/version/signature.

Keep the repository private because the development build retains the existing project signing key for upgrade compatibility. Never publish that key or its credentials.
