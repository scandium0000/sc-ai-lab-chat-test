# Sc Chat 0.9.3 — Camera Studio

## Highlights

- Adds native Android camera capture through `ACTION_IMAGE_CAPTURE` and an app-scoped `FileProvider` cache URI. No direct camera permission is requested by Sc Chat; the installed camera app handles capture permissions.
- Corrects common JPEG EXIF orientation metadata before sending the image to the editor.
- Adds the local Camera Studio editor with pen annotation, mosaic brush, drag-to-crop, 90-degree rotation, and undo.
- Allows images already attached to a pending message to be edited before sending.
- Adds a browser-preview fallback using the system image picker with the environment-camera capture hint.
- Compresses captured/edited images locally and applies per-image and per-message size safeguards.
- Keeps document processing from 0.9.2: PDF text extraction with page labels, DOCX paragraph/heading/list/table extraction, and local text/Markdown/CSV/JSON/code handling.
- Preserves the existing package ID and Android Keystore-backed Provider credential handling.

## Important limitations

- Scanned-PDF OCR is not included.
- XLSX and PPTX parsing are not included in this increment.
- Camera availability depends on an installed camera application. The browser preview fallback depends on browser/device capture support.
- Image editing is local and raster-based. Pen strokes are red; mosaic is destructive pixelation; crop and rotation can be undone before saving the edited attachment.
- The APK must still be built by GitHub Actions and tested on a physical Android device. Source-level tests do not prove camera compatibility across all OEM camera apps.

## Validation

- JavaScript syntax and regression tests, including Camera Studio utility tests.
- HTML ID / bridge / manifest resource validation.
- DOCX parser JVM tests.
- Android XML parsing.
- GitHub Actions Debug APK build and APK package/version/signature verification.

Version code: `17`
Version name: `0.9.3`
