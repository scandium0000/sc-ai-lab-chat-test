# Sc Chat 0.9.4 — Document Office, ZIP, OCR & Generated Files

## Highlights

- Adds local XLSX parsing: workbook sheet order, sheet names, shared strings, inline strings, cell values, booleans, and formula text are extracted into readable rows.
- Adds local PPTX parsing: presentation relationship order and text paragraphs are extracted with slide labels.
- Adds safe ZIP archive inspection. It never extracts entries to disk; path traversal names are rejected, and entry count, per-entry expansion, total expanded data, and total output are bounded. Supported text, PDF, DOCX, XLSX and PPTX files inside the archive are locally parsed. Unsupported binary entries are listed instead of executed.
- Adds on-device OCR for scanned or image-only PDF pages using bundled ML Kit Chinese and Latin text-recognition models. Searchable pages retain PDFBox text; pages with no embedded text are rendered locally and OCR'd. OCR processes at most 20 scanned pages per PDF.
- Adds generated-file download controls for HTTPS file links in assistant Markdown and bare HTTPS file URLs. Android opens the system Save As picker and downloads the file directly without attaching Provider API credentials. The downloader rejects non-HTTPS URLs, blocks HTTPS-to-HTTP redirects, allows at most four redirects, and caps downloads at 50 MB.
- Keeps the existing Sc Document Engine, Camera Studio, Reasoning Engine, Provider system, account storage namespace, and Application ID.

## Parsing limits and known limitations

- Individual PDFs are limited to 10 MB. Native PDF text extraction is limited to 40 pages. OCR is limited to 20 scanned pages per PDF. Very low-resolution, rotated, handwritten, or poor-contrast scans may produce incomplete OCR.
- XLSX and PPTX are limited to 15 MB. XLSX extraction is limited to 20 worksheets, 600 rows per worksheet, 80 cells per row, and 120,000 output characters. Formula expressions and cached values are shown; Excel formatting, charts, pivot tables, and visual layout are not reconstructed.
- PPTX extraction is limited to 80 slides and 120,000 output characters. Text is extracted; slide images, diagrams, speaker notes, animations, and visual layout are not OCR'd or reconstructed.
- ZIP uploads are limited to 15 MB, 200 entries, 12 MB per expanded entry, 40 MB total expanded data, and 120,000 output characters. ZIP entries are inspected in memory only. Nested ZIP files are listed but not recursively unpacked. Executables and unsupported binary files are never run.
- PDF OCR is on-device and uses bundled Chinese and Latin models. This increases APK size. OCR results are not guaranteed to be exact and should be checked for important numbers, tables, and formulas.
- Generated-file download is available when the Provider returns a real HTTPS URL in a Markdown file link or a detectable bare file URL. Provider-specific file IDs that require a vendor-specific authenticated download API are not yet supported. Sc Chat does not invent URLs or transmit Provider API keys to file hosts.
- When a server link has no recognizable extension or filename, the file may be saved with a generic name. HTTPS-only download is intentional.

## Privacy and safety

- PDF, DOCX, XLSX, PPTX, and ZIP parsing occurs locally. Extracted text is sent to the selected model only when the user sends the message.
- OCR runs on-device using bundled ML Kit models; source PDF pages are not sent to an OCR cloud service.
- ZIP entries are never written to a filesystem or executed. Archive paths are validated and expansion limits protect against oversized archives.
- Document contents remain untrusted reference data and cannot override system or safety instructions.
- Generated file downloads require an explicit user click and Android's system Save As confirmation. Download requests do not include the configured Provider API key.

## Validation

- JavaScript syntax and all `tests/*.test.cjs` regression tests.
- Java parser tests for DOCX, XLSX, PPTX, ZIP extraction, and ZIP path traversal rejection.
- HTML ID / native bridge / OCR dependency / download flow validation.
- Android XML parsing.
- GitHub Actions performs the Android Gradle build, APK signature verification, and package/version checks.

Version code: `18`
Version name: `0.9.4`
