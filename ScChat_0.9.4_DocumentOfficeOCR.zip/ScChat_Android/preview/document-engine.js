(function (root, factory) {
  const api = factory();
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (root) root.ScDocumentEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const MAX_CHARS = 120000;

  function normalizeText(value) {
    return String(value == null ? '' : value)
      .replace(/^\uFEFF/, '')
      .replace(/\u0000/g, '')
      .replace(/\r\n?/g, '\n');
  }

  function clipText(value, maxChars = MAX_CHARS) {
    const text = normalizeText(value);
    if (text.length <= maxChars) return { text, truncated: false };
    const marker = '\n\n[Document content truncated by Sc Chat: character limit reached.]';
    return { text: text.slice(0, Math.max(0, maxChars - marker.length)) + marker, truncated: true };
  }

  function parseCsvRows(source, maxRows = 1000) {
    const input = normalizeText(source);
    const rows = [];
    let row = [], cell = '', quoted = false, rowLimitReached = false;
    for (let i = 0; i < input.length; i += 1) {
      const char = input[i];
      if (quoted) {
        if (char === '"' && input[i + 1] === '"') { cell += '"'; i += 1; }
        else if (char === '"') quoted = false;
        else cell += char;
      } else if (char === '"' && cell.length === 0) {
        quoted = true;
      } else if (char === ',') {
        row.push(cell); cell = '';
      } else if (char === '\n') {
        row.push(cell); cell = '';
        if (row.some(value => value.length > 0)) rows.push(row);
        row = [];
        if (rows.length >= maxRows) { rowLimitReached = true; break; }
      } else {
        cell += char;
      }
    }
    if (row.length || cell.length) {
      row.push(cell);
      if (row.some(value => value.length > 0) && rows.length < maxRows) rows.push(row);
    }
    return { rows, truncated: rowLimitReached };
  }

  function csvToMarkdown(source) {
    const parsed = parseCsvRows(source);
    if (!parsed.rows.length) return { text: '', rows: 0, columns: 0, truncated: false };
    const columns = Math.max(...parsed.rows.map(row => row.length));
    const normalizedRows = parsed.rows.map(row => {
      const cells = Array.from({ length: columns }, (_, index) => row[index] || '');
      return `| ${cells.map(value => value.replace(/\|/g, '\\|').replace(/\n/g, '<br>').trim()).join(' | ')} |`;
    });
    if (normalizedRows.length > 1) normalizedRows.splice(1, 0, `| ${Array(columns).fill('---').join(' | ')} |`);
    let text = normalizedRows.join('\n');
    if (parsed.truncated) text += '\n\n[CSV truncated: row limit reached.]';
    const clipped = clipText(text);
    return { text: clipped.text, rows: parsed.rows.length, columns, truncated: parsed.truncated || clipped.truncated };
  }

  function formatJson(source) {
    const normalized = normalizeText(source);
    try {
      return { text: JSON.stringify(JSON.parse(normalized), null, 2), valid: true };
    } catch (_) {
      return { text: normalized, valid: false };
    }
  }

  function inferFormat(name, mimeType = '') {
    const extension = String(name || '').toLowerCase().split('.').pop();
    const supported = new Set(['pdf', 'docx', 'txt', 'md', 'markdown', 'csv', 'json', 'js', 'ts', 'py', 'java', 'kt', 'html', 'css', 'xml', 'yaml', 'yml', 'log']);
    if (supported.has(extension)) return extension === 'markdown' ? 'md' : extension;
    const mime = String(mimeType || '').toLowerCase();
    if (mime === 'application/pdf') return 'pdf';
    if (mime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') return 'docx';
    if (mime === 'text/csv') return 'csv';
    if (mime === 'application/json') return 'json';
    if (mime.startsWith('text/')) return 'txt';
    return '';
  }

  function prepareText(format, source) {
    const normalized = normalizeText(source);
    if (format === 'csv') return { ...csvToMarkdown(normalized), format, details: 'CSV 表格已转换为 Markdown 表格。' };
    if (format === 'json') {
      const result = formatJson(normalized);
      const clipped = clipText(result.text);
      return { ...clipped, format, valid: result.valid, details: result.valid ? 'JSON 已校验并格式化。' : 'JSON 格式无法校验，已保留原始文本。' };
    }
    const clipped = clipText(normalized);
    return { ...clipped, format, details: '本地文本提取完成。' };
  }

  return { MAX_CHARS, normalizeText, clipText, parseCsvRows, csvToMarkdown, formatJson, inferFormat, prepareText };
});
