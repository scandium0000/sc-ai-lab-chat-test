# Sc Chat 0.9.2 — Sc Document Engine

## Added
- Local DOCX text extraction with heading, paragraph, list, and table preservation.
- Local shared document normalization for TXT, Markdown, CSV, JSON, HTML, and source-code/text formats.
- CSV-to-Markdown table conversion with quoted-field and embedded-newline support.
- JSON validation and readable formatting, preserving invalid source text.
- Per-attachment local parsing details in the composer.
- Explicit untrusted-document boundaries in provider messages.
- JVM regression test for the production DOCX SAX parser and Node tests for text/CSV/JSON parsing.

## Improved
- PDF extraction includes page markers and a clear 40-page extraction limit.
- Attachment validation rejects empty files and enforces per-file and per-message extracted-text caps.
- DOCX ZIP parsing limits compressed input, expanded XML, aggregate decompressed data, and archive-entry count.
- Scanned PDFs now receive a clear notice that OCR is not part of this release.

## Compatibility
- Application ID remains `ai.scailab.chat`.
- Version code increments to 16; version name is `0.9.2`.
- Existing local storage namespace and debug signing identity are preserved.

## Not included yet
- XLSX and PPTX parsing.
- OCR for image-only PDFs.
- DOCX headers, footers, comments, tracked changes, and embedded media extraction.
- Large-document semantic chunk retrieval; the current release uses bounded local extraction.
