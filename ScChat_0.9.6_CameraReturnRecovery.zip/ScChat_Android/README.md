# Sc Chat — Android 0.9.6

A minimal Android AI chat client by Sc Ai Lab. The app uses a native Java Android shell and a local HTML/CSS/JavaScript interface inside Android WebView.

## What's new in 0.9.6

### Camera return recovery
- Persist the pending camera output path synchronously before launching the external camera app. This provides a recovery path if Android recreates the Activity or reclaims the app process while the camera is in the foreground.
- Restore the pending output path from saved Activity state first and app-private SharedPreferences as a fallback.
- Buffer the camera result callback until the local WebView page has finished loading and its JavaScript handler is available.
- Add lifecycle and result-delivery diagnostics under the `ScChatCamera` tag.
- Keep camera decoding bounded (1280-pixel longest edge), use the local WebView resource route, and release temporary files after processing.

This is a targeted recovery improvement for the failure window after the user confirms a photo in the system camera and returns to Sc Chat. It is not yet a claim of confirmed device-level resolution; the exact crash cause still requires device logs if it persists.

### Retained features from 0.9.5 / 0.9.4
- Camera Studio pen, mosaic, crop, rotate, and undo.
- PDF local text extraction and Chinese/Latin on-device OCR.
- DOCX, XLSX, PPTX, ZIP, TXT, MD, CSV, JSON, and common source-code parsing.
- HTTPS downloads for recognizable server-generated file links via Android Save As.
- Provider management, Sc Reasoning Engine, local drafts, and prior stability improvements.

## Parsing limits

- PDF: 10 MB; native extraction up to 40 pages; OCR up to 20 scanned pages.
- DOCX: 10 MB.
- XLSX/PPTX: 15 MB; XLSX up to 20 worksheets, 600 rows per sheet, 80 cells per row; PPTX up to 80 slides.
- ZIP: 15 MB upload, 200 entries, 12 MB per expanded entry, 40 MB total expanded data. Nested ZIP files are listed, not recursively unpacked.
- Extracted content is capped at 120,000 characters per document. Important tables, formulas, charts, images, handwriting, or visual layout may require manual verification.

## Privacy and safety

- Document extraction and OCR run locally on the device. Only prepared text or images are sent to the selected Provider when the user sends the message.
- ZIP content is inspected in memory, never executed, and archive paths and expansion sizes are validated.
- Generated file downloads require explicit user action and Android Save As confirmation. Only HTTPS is accepted; Provider API keys are not forwarded to the file host.
- Camera recovery state contains only an app-private temporary file path and is cleared when the camera result is consumed or the user deliberately closes the Activity.

## Build from an Android phone with GitHub Actions

1. Upload `ScChat_0.9.6_CameraReturnRecovery.zip` to the root of your private GitHub repository.
2. Copy `build-from-zip-0.9.6.yml` to `.github/workflows/build-from-zip.yml`.
3. Open **Actions** and run **Build Sc Chat 0.9.6 APK**.
4. Download the `ScChat-0.9.6-debug` artifact when the workflow succeeds.

The workflow discovers the Android SDK Manager provisioned on the GitHub-hosted runner, installs Android API 35 and Build Tools 35.0.0, runs the JavaScript regression suite and Java parser tests, validates Android XML, builds with Gradle 8.9, and verifies the APK package, version, and signature.

Keep the repository private because the debug build retains the existing project signing key to preserve upgrade compatibility. Never publish the keystore or its credentials.

## Compatibility

- Application ID / namespace: `ai.scailab.chat`
- Minimum Android SDK: 26
- Compile / target SDK: 35
- Java: 17
- Gradle: 8.9
- Version code: 20
- Version name: `0.9.6`

## Verification status

In this development environment, all 11 JavaScript regression tests pass, asset validation passes, and the JavaScript syntax and Android XML checks pass. The Android SDK and Gradle are not installed here, so this environment has not compiled the APK or tested the camera flow on a physical device. GitHub Actions must confirm the native build, and the camera return flow still requires repeated testing on the target phone.
