# Sc Chat 0.9.5 — Camera Stability Update

## Camera pipeline

- Replaces the large Base64 Java-to-WebView camera payload with an app-local WebView resource URL backed by a short-lived cache file.
- Bounds native image decoding to a 1280-pixel longest edge and limits the compressed temporary preview to 450 KB.
- Releases preview files after the editor has loaded the image, and cleans up temporary previews when the Activity is destroyed.
- Preserves an in-progress camera output file across Activity configuration recreation instead of deleting it from the old Activity instance.
- Explicitly grants the camera output URI to resolved camera activities.
- Adds non-content diagnostic events under the `ScChatCamera` log tag (no image bytes or image content are logged).

## Compatibility

- Application ID and namespace remain `ai.scailab.chat`.
- Version code: `19`; version name: `0.9.5`.
- Existing debug signing configuration is retained for upgrade compatibility.
- All 0.9.4 document, OCR, ZIP, and generated-file download features are retained.

## Verification status

- JavaScript syntax and regression tests are run locally.
- Android Gradle compilation and physical-device camera testing must be confirmed by the GitHub Actions build and device validation; they are not claimed as complete here.
