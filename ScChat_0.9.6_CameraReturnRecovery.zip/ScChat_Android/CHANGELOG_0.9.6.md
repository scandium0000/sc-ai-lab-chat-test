# Sc Chat 0.9.6 — Camera Return Recovery

## Fixed / Improved
- Persist the pending camera output path synchronously before handing control to the external camera app.
- Restore the pending path from Activity saved state or app-private SharedPreferences after Activity/process recreation.
- Defer the native-to-WebView camera result callback until the WebView page is ready.
- Add diagnostic events for camera launch, pending-path persistence, Activity restoration, camera result receipt, image preparation, and JavaScript callback delivery.
- Guard camera background-task submission against a rejected executor and keep photo decoding bounded.

## Preserved
- Application ID, namespace, signing configuration, and local storage namespace.
- 0.9.5 camera preview route and image-size limits.
- Camera Studio editing tools, document parsers/OCR, generated-file downloads, Provider features, and Sc Reasoning Engine.

## Verification
- 11 JavaScript regression tests passed.
- Asset validation passed.
- JavaScript syntax checks passed.
- Android XML parsing checks passed.
- Android Gradle build and physical-device camera testing were not available in this environment.
