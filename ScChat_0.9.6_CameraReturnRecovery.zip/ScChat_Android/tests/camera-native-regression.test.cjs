const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const java = fs.readFileSync(path.join(root, 'app/src/main/java/ai/scailab/chat/MainActivity.java'), 'utf8');
const app = fs.readFileSync(path.join(root, 'app/src/main/assets/app.js'), 'utf8');

assert.match(java, /\/camera-preview\//, 'Native camera previews must use the local WebView resource route.');
assert.match(java, /interceptCameraPreview\(request\.getUrl\(\)\)/, 'WebView must intercept local camera preview requests.');
assert.match(java, /cameraPreviewFiles\.put\(previewId, previewFile\)/, 'Preview files must be registered before the WebView loads them.');
assert.match(java, /public void releaseCameraPreview\(String previewId\)/, 'JavaScript must be able to release temporary preview files.');
assert.match(java, /isFinishing\(\) && !isChangingConfigurations\(\)/, 'A pending camera output must survive Activity recreation.');
assert.match(java, /PREF_PENDING_CAMERA_PATH/, 'The pending camera output path must be persisted outside the Activity instance.');
assert.match(java, /Restored pending camera output after Activity recreation/, 'The camera flow must log recovery after process or Activity recreation.');
assert.match(java, /dispatchPendingCameraCallback\(\)/, 'The camera result must wait until the WebView page is ready.');
assert.match(java, /webPageReady/, 'The camera callback must be gated on WebView readiness.');
assert.match(java, /while \(longest \/ sample > 1280\)/, 'Native camera decoding must be bounded to a modest image size.');
assert.doesNotMatch(java, /return "data:image\/jpeg;base64," \+ Base64\.encodeToString/, 'Camera photos must not be passed to WebView as a large Base64 JavaScript string.');
assert.match(app, /releaseCameraPreview\(previewId\)/, 'The editor must release the native preview after image load.');
assert.match(app, /openCameraEditor\(String\(imageUrl \|\| ''\)/, 'The camera result must open the editor using the local image URL.');

console.log('Native camera regression checks passed: bounded decode, persisted Activity recovery, WebView-ready callback delivery, local preview handoff, and preview cleanup.');
