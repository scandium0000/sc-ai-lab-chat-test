# Sc Chat — Android 0.6.1

<p align="center">
  <img src="app/src/main/assets/logo.png" width="112" alt="Sc Ai Lab atom emblem">
</p>

<p align="center"><strong>A focused, multi-provider AI workspace by Sc Ai Lab.</strong></p>
<p align="center">Android · Local-first · Provider-independent · 0.6.1</p>

---

## 0.6.1 Hotfix

This maintenance release corrects the Android keyboard and system-bar layout behavior observed on real Android devices.

- Uses a native `FrameLayout` container for the WebView.
- Handles status-bar, navigation-bar, display-cutout, and IME insets through Android `WindowInsets` on API 30+.
- Positions the WebView below the status bar and above the software keyboard.
- Uses `adjustResize` on Android 8–10 and explicit IME inset layout on Android 11+.
- Sends the native IME visibility state to the web UI so the welcome shortcuts collapse while typing.
- Removes page-level `scrollIntoView()` behavior that could move the composer unexpectedly.
- Keeps the composer in the visible flex layout when the keyboard is open.

The insets behavior was statically reviewed and the web layout was smoke-tested at reduced viewport heights. A physical-device test is still required to verify OEM keyboard behavior.

## Overview

Sc Chat is an Android AI chat application developed by Sc Ai Lab. It brings conversations, projects, personal assistants, model connections, and conversation attachments into one mobile workspace.

The application is designed to remain independent of any single model provider. It supports Pollinations and user-configured OpenAI-compatible Chat Completions endpoints.

## Features

### Chat
- Streaming assistant responses and stop generation.
- Copy responses, edit previous prompts, and regenerate responses.
- Markdown, tables, links, and code blocks.
- Image and document attachments.
- Keyboard-aware mobile composer.

### Projects and Assistants
- Create, edit, and delete local projects.
- Create conversations within projects and move existing conversations.
- Create and manage personal assistants with custom system instructions.

### Models and Connections
- Pollinations device authorization.
- Custom OpenAI-compatible HTTPS providers.
- Provider and model selection.
- Per-provider Vision capability setting.
- API keys stored through an Android Keystore-backed AES-GCM bridge.

### File Library
- Aggregates images and documents attached to local conversations.
- Search by filename or conversation title and navigate to the source conversation.
- Extracts selectable text from PDFs locally; scanned image-only PDFs are not OCR processed.

### Account and Appearance
- Local registration and login.
- Profile image, display name, password changes, and account deletion.
- Automatic light/dark theme based on Android system appearance.
- Sc Ai Lab atom emblem and blue accent identity.

## Requirements

- Android 8.0 (API 26) or later.
- Internet for remote AI providers.
- Valid provider credentials where required.
- An OpenAI Chat Completions-compatible endpoint for custom providers.

## Build from GitHub Actions

1. Upload `ScChat_0.6.1_KeyboardFix.zip` to the repository root.
2. Replace `.github/workflows/build-from-zip.yml` with `build-from-zip-0.6.1.yml`.
3. Run **Build Sc Chat 0.6.1 APK** from Actions.
4. Download the `ScChat-0.6.1-debug` artifact after a successful run.

The artifact is a debug/test APK, not a production release.

## Build from Source

Requirements: JDK 17, Android SDK Platform 35, Android Build Tools 35.0.0, and Gradle 8.9.

From the `ScChat_Android` directory:

```bash
gradle --no-daemon :app:assembleDebug
```

APK output:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Custom Provider

Open **Models & Connections → Add OpenAI-compatible provider** and enter the provider name, HTTPS API Base URL, model ID, and API key. Enable Vision only when the selected model actually supports image input.

Example values are placeholders; provider pricing, quota, capabilities, and data handling are controlled by each provider.

## Local Data and Privacy

- Local accounts, projects, assistants, and chats are stored on the device.
- Local accounts do not provide cloud sync or password recovery.
- Provider API keys are stored via Android Keystore-backed encryption.
- Prompts and attachments are sent to the provider selected by the user when submitted.
- Avoid sending credentials or unnecessary sensitive information.

## Upgrade Compatibility

- `applicationId` remains `ai.scailab.chat`.
- Local storage namespaces remain `scailab.*`.
- `versionCode` is 8 and `versionName` is 0.6.1.
- The same private development keystore is retained for test upgrades. Keep it private and do not use it for a public production release.
- If Android reports a signature conflict, do not uninstall the previous build until local data has been exported.

## Roadmap

- [x] Local accounts and profile settings
- [x] Streaming chat and message actions
- [x] Projects and custom assistants
- [x] Multi-provider architecture
- [x] Local attachment library
- [x] Native Android keyboard and system-bar insets handling
- [ ] Conversation memory and context management
- [ ] Knowledge collections and RAG
- [ ] Voice input and speech output
- [ ] HSSM native provider integration
- [ ] Encrypted local conversation database and backups

## About Sc Ai Lab

Sc Chat is part of the Sc Ai Lab ecosystem. The long-term direction is a flexible client for third-party cloud models, local inference runtimes, and Sc Ai Lab's own HSSM models.

## License

Apache License 2.0. See [LICENSE](LICENSE) for details.
