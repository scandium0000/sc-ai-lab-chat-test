# Build Sc Chat 0.6.1 from an Android phone

1. Upload `ScChat_0.6.1_KeyboardFix.zip` to the root of your private GitHub repository.
2. Replace `.github/workflows/build-from-zip.yml` with the supplied `build-from-zip-0.6.1.yml`.
3. Open **Actions** and run **Build Sc Chat 0.6.1 APK**.
4. When successful, download the `ScChat-0.6.1-debug` artifact.
5. Install `app-debug.apk` on the Android device and test keyboard opening/closing, landscape mode, status-bar spacing, and navigation-bar spacing.

The build preserves the application ID and development signing key from 0.6.0. Do not publish the development signing key.
