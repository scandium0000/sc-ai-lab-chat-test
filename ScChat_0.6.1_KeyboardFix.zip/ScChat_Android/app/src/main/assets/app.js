'use strict';

const $ = (id) => document.getElementById(id);
const STORE_USERS = 'scailab.users.v1';
const STORE_SESSION = 'scailab.session.v1';
const STORE_CHATS = 'scailab.chats.v1';
const STORE_APPKEY = 'scailab.pollinations.appkey.v1';
const STORE_PROVIDERS = 'scailab.providers.v1';
const STORE_ACTIVE_PROVIDER = 'scailab.activeProvider.v1';
const STORE_ASSISTANTS = 'scailab.assistants.v1';
const STORE_PROJECTS = 'scailab.projects.v1';
const STORE_ACTIVE_ASSISTANT = 'scailab.activeAssistant.v1';
const POLLINATIONS = 'https://gen.pollinations.ai';
const ENTER = 'https://enter.pollinations.ai';
const ITERATIONS = 210000;

let authMode = 'login';
let currentUser = null; // Normalised local account key.
let currentUserRecord = null;
let activeAssistantId = 'default';
let editingAssistantId = null;
let assistants = [];
let projects = [];
let activeWorkspacePage = 'chats';
let openProjectId = null;
let editingProjectId = null;
let pendingAttachments = [];
let currentChatId = null;
let chats = [];
let freeModels = [];
let providers = [];
let selectedProviderId = 'pollinations';
let accessToken = null; // OAuth access token remains memory-only.
let devicePollTimer = null;
let deviceCancelled = false;
let busy = false;
let activeController = null;
let activeGenerationChatId = null;
let toastTimer = null;
let runtimeSecrets = Object.create(null); // Preview fallback only; never persisted.
let pendingNative = new Map();
let pendingPdfExtractions = new Map();

function safeJsonParse(value, fallback) { try { return value ? JSON.parse(value) : fallback; } catch { return fallback; } }
function getUsers() { return safeJsonParse(localStorage.getItem(STORE_USERS), {}); }
function setUsers(users) { localStorage.setItem(STORE_USERS, JSON.stringify(users)); }
function assistantsStorageKey() { return `${STORE_ASSISTANTS}.${normaliseUsername(currentUser || '')}`; }
function activeAssistantStorageKey() { return `${STORE_ACTIVE_ASSISTANT}.${normaliseUsername(currentUser || '')}`; }
function currentDisplayName() { return String(currentUserRecord?.displayName || currentUserRecord?.username || currentUser || 'User').trim(); }
function renderAvatar(element, fallbackText, imageData) {
  if (!element) return;
  element.textContent = imageData ? '' : (fallbackText || 'U').slice(0, 1).toUpperCase();
  element.style.backgroundImage = imageData ? `url("${imageData}")` : '';
  element.classList.toggle('has-photo', !!imageData);
}
function renderUserIdentity() {
  if (!currentUserRecord) return;
  const display = currentDisplayName();
  $('sidebarUsername').textContent = display;
  $('sidebarHandle').textContent = `@${currentUserRecord.username || currentUser}`;
  renderAvatar($('userAvatar'), display, currentUserRecord.avatarDataUrl || '');
  renderAvatar($('profileAvatar'), display, currentUserRecord.avatarDataUrl || '');
  $('profileDisplayName').textContent = display;
  $('profileUsername').textContent = `@${currentUserRecord.username || currentUser}`;
  if ($('welcomeUserName')) $('welcomeUserName').textContent = display;
}

function normaliseUsername(value) { return value.trim().toLowerCase(); }
function validUsername(value) { return /^[a-zA-Z0-9_-]{3,24}$/.test(value); }
function base64(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))); }
function fromBase64(value) { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }
function randomBytes(length) { const out = new Uint8Array(length); crypto.getRandomValues(out); return out; }
async function derivePassword(password, salt) {
  if (!crypto.subtle) throw new Error('当前运行环境不支持安全密码摘要，请在 Android 应用或 HTTPS 环境中使用。');
  const material = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({name:'PBKDF2', salt, iterations:ITERATIONS, hash:'SHA-256'}, material, 256);
  return base64(bits);
}

function showToast(message) {
  const toast = $('toast'); toast.textContent = message; toast.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove('show'), 3200);
}
function setAuthMode(mode) {
  authMode = mode;
  $('authTitle').textContent = mode === 'login' ? 'Welcome back.' : 'Create your space.';
  $('authSubtitle').textContent = mode === 'login' ? '进入 Sc Chat，开始你的 AI 对话。' : '创建一个保存在本机的 Sc Chat 账户。';
  $('authSubmit').innerHTML = mode === 'login' ? '登录 <span>↗</span>' : '创建账户 <span>↗</span>';
  $('switchPrompt').textContent = mode === 'login' ? '还没有本地账户？' : '已经有账户了？';
  $('switchAuth').textContent = mode === 'login' ? '创建账户' : '返回登录';
  $('confirmWrap').classList.toggle('hidden', mode === 'login');
  $('authPassword').autocomplete = mode === 'login' ? 'current-password' : 'new-password';
  $('authError').textContent = '';
}

$('switchAuth').addEventListener('click', () => setAuthMode(authMode === 'login' ? 'register' : 'login'));
$('authForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  const usernameRaw = $('authUsername').value.trim();
  const username = normaliseUsername(usernameRaw);
  const password = $('authPassword').value;
  $('authError').textContent = '';
  if (!validUsername(usernameRaw)) { $('authError').textContent = '用户名需为 3–24 位字母、数字、下划线或连字符。'; return; }
  if (password.length < 10) { $('authError').textContent = '密码至少需要 10 位。请勿重复使用其他网站的密码。'; return; }
  const users = getUsers();
  const submit = $('authSubmit'); submit.disabled = true;
  try {
    if (authMode === 'register') {
      if (users[username]) { $('authError').textContent = '这个用户名已经存在。'; return; }
      if (password !== $('authConfirm').value) { $('authError').textContent = '两次输入的密码不一致。'; return; }
      const salt = randomBytes(16);
      const hash = await derivePassword(password, salt);
      users[username] = {username: usernameRaw, displayName: usernameRaw, avatarDataUrl: '', salt: base64(salt), hash, createdAt: Date.now()};
      setUsers(users);
      localStorage.setItem(STORE_SESSION, username);
      enterApp(usernameRaw);
      showToast('本地账户创建成功');
    } else {
      const record = users[username];
      if (!record) { $('authError').textContent = '没有找到这个本地账户。请先注册。'; return; }
      const hash = await derivePassword(password, fromBase64(record.salt));
      if (hash !== record.hash) { $('authError').textContent = '用户名或密码不正确。'; return; }
      localStorage.setItem(STORE_SESSION, username);
      enterApp(record.username);
    }
  } catch (error) {
    $('authError').textContent = error?.message || '账户操作失败。';
  } finally { submit.disabled = false; }
});

function enterApp(username) {
  currentUser = normaliseUsername(username);
  const users = getUsers();
  currentUserRecord = users[currentUser] || {username, displayName: username, createdAt: Date.now()};
  currentUserRecord.displayName = currentUserRecord.displayName || currentUserRecord.username || username;
  currentUserRecord.avatarDataUrl = currentUserRecord.avatarDataUrl || '';
  users[currentUser] = currentUserRecord; setUsers(users);
  $('authView').classList.add('hidden'); $('chatView').classList.remove('hidden');
  renderUserIdentity();
  loadChats(); loadAssistants(); loadProjects(); loadProviders(); renderConversationList();
  $('appKeyInput').value = localStorage.getItem(STORE_APPKEY) || '';
  selectedProviderId = localStorage.getItem(STORE_ACTIVE_PROVIDER) || 'pollinations';
  renderProviderControls();
  loadModels(); updateConnectionState(); renderAssistantSwitcher();
  if (chats.length) selectChat(sortedChats()[0].id); else createChat();
}
function logOut() {
  if (activeController) activeController.abort();
  currentUser = null; currentUserRecord = null; assistants = []; activeAssistantId = 'default'; accessToken = null; runtimeSecrets = Object.create(null); pendingAttachments = []; localStorage.removeItem(STORE_SESSION);
  if (devicePollTimer) clearTimeout(devicePollTimer);
  $('chatView').classList.add('hidden'); $('authView').classList.remove('hidden');
  $('authForm').reset(); setAuthMode('login');
}
$('logoutButton').addEventListener('click', logOut);

function chatStorageKey() { return `${STORE_CHATS}.${normaliseUsername(currentUser || '')}`; }
function projectsStorageKey() { return `${STORE_PROJECTS}.${normaliseUsername(currentUser || '')}`; }
function loadChats() {
  chats = safeJsonParse(localStorage.getItem(chatStorageKey()), []);
  if (!Array.isArray(chats)) chats = [];
  chats.forEach(chat => { if (!Array.isArray(chat.messages)) chat.messages = []; if (typeof chat.pinned !== 'boolean') chat.pinned = false; });
}
function saveChats() { try { localStorage.setItem(chatStorageKey(), JSON.stringify(chats)); renderConversationList(); updateSidebarCounts(); } catch (error) { showToast('本机存储空间不足，部分附件可能无法保存。请先导出聊天记录或删除不需要的附件。'); } }
function sortedChats() { return [...chats].sort((a,b) => Number(!!b.pinned)-Number(!!a.pinned) || (b.updatedAt||0)-(a.updatedAt||0)); }
function createChat(projectId = null) {
  setWorkspacePage('chats');
  const chat = {id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()), title:'新对话', messages:[], updatedAt:Date.now(), pinned:false, assistantId:activeAssistantId, projectId: projectId || null};
  chats.unshift(chat); currentChatId = chat.id; saveChats(); renderMessages();
  $('welcomePanel').classList.remove('hidden'); $('messages').classList.add('hidden'); $('messageInput').focus(); closeSidebar();
  if (projectId) showToast('已在项目中创建新对话。');
  return chat;
}
function selectChat(id) {
  if (busy && activeGenerationChatId === currentChatId) stopGeneration();
  currentChatId = id; const chat = chats.find(item => item.id === id); if (!chat) return;
  setWorkspacePage('chats');
  activeAssistantId = chat.assistantId || 'default'; localStorage.setItem(activeAssistantStorageKey(), activeAssistantId); renderAssistantSwitcher();
  renderConversationList(); renderMessages(); closeSidebar();
}
function activeChat() { return chats.find(item => item.id === currentChatId); }
function renderConversationList() {
  const list = $('conversationList'); if (!list) return;
  const query = ($('chatSearch')?.value || '').trim().toLowerCase();
  list.innerHTML = '';
  const visible = sortedChats().filter(chat => !query || (chat.title || '').toLowerCase().includes(query) || chat.messages.some(m => String(m.content||'').toLowerCase().includes(query)));
  if (!visible.length) {
    const empty = document.createElement('div'); empty.className = 'conversation-empty'; empty.textContent = query ? '没有匹配的对话' : '还没有对话'; list.appendChild(empty); return;
  }
  for (const chat of visible) {
    const row = document.createElement('div'); row.className = `conversation-row${chat.id === currentChatId ? ' active' : ''}`;
    const button = document.createElement('button'); button.className = 'conversation-item';
    button.textContent = `${chat.pinned ? '📌 ' : ''}${chat.title || '新对话'}`; button.title = chat.title || '新对话';
    button.addEventListener('click', () => selectChat(chat.id));
    const more = document.createElement('button'); more.className = 'conversation-more'; more.type = 'button'; more.textContent = '⋯'; more.setAttribute('aria-label','对话操作');
    const menu = document.createElement('div'); menu.className = 'conversation-menu hidden';
    const actions = [
      ['重命名', () => renameChat(chat)],
      [chat.pinned ? '取消置顶' : '置顶对话', () => { chat.pinned = !chat.pinned; chat.updatedAt = Date.now(); saveChats(); }],
      ['移至项目', () => moveChatToProject(chat)],
      ['导出 Markdown', () => exportChat(chat)],
      ['删除对话', () => deleteChat(chat)]
    ];
    actions.forEach(([label, action]) => { const item = document.createElement('button'); item.type='button'; item.textContent=label; item.addEventListener('click', event => { event.stopPropagation(); menu.classList.add('hidden'); action(); }); menu.appendChild(item); });
    more.addEventListener('click', event => { event.stopPropagation(); document.querySelectorAll('.conversation-menu').forEach(other => { if (other !== menu) other.classList.add('hidden'); }); menu.classList.toggle('hidden'); });
    row.append(button, more, menu); list.appendChild(row);
  }
}
document.addEventListener('click', event => { if (!event.target.closest('.conversation-row')) document.querySelectorAll('.conversation-menu').forEach(menu => menu.classList.add('hidden')); });
$('chatSearch').addEventListener('input', renderConversationList);
function renameChat(chat) {
  const name = prompt('为这段对话设置一个名称：', chat.title || '新对话');
  if (name === null) return;
  const clean = name.trim().slice(0,80);
  if (!clean) { showToast('对话名称不能为空。'); return; }
  chat.title = clean; chat.updatedAt = Date.now(); saveChats(); showToast('对话已重命名。');
}
function deleteChat(chat) {
  if (!confirm(`确定删除“${chat.title || '新对话'}”吗？此操作无法撤销。`)) return;
  if (activeGenerationChatId===chat.id) stopGeneration();
  chats = chats.filter(item => item.id !== chat.id);
  if (currentChatId === chat.id) {
    currentChatId = null;
    if (chats.length) selectChat(sortedChats()[0].id); else createChat();
  } else saveChats();
  showToast('对话已删除。');
}
function markdownForChat(chat) {
  const lines = [`# ${chat.title || '新对话'}`, '', `导出时间：${new Date().toLocaleString()}`, ''];
  for (const message of chat.messages) lines.push(`## ${message.role === 'user' ? '用户' : 'Sc Chat'}`, '', String(message.content || ''), '');
  return lines.join('\n');
}
function nativeShare(title, text) {
  if (window.ScAiBridge && typeof window.ScAiBridge.shareText === 'function') { window.ScAiBridge.shareText(title, text); return true; }
  copyText(text); showToast('当前预览环境不支持文件分享，内容已复制。'); return false;
}
function nativeSaveTextFile(fileName, mimeType, content, fallbackTitle) {
  if (window.ScAiBridge && typeof window.ScAiBridge.saveTextFile === 'function') {
    const accepted = window.ScAiBridge.saveTextFile(fileName, mimeType, content);
    if (accepted) { showToast('请选择文件保存位置。'); return true; }
    showToast('无法启动保存窗口；导出文件可能超过 8 MB。'); return false;
  }
  return nativeShare(fallbackTitle || fileName, content);
}
window.__scaiFileSaveResult = (success, message) => showToast(message || (success ? '文件已保存。' : '文件保存失败。'));
function exportChat(chat) {
  const content = markdownForChat(chat);
  nativeSaveTextFile(`scchat-${chat.id || Date.now()}.md`, 'text/markdown', content, `导出对话：${chat.title || '新对话'}`);
}
$('exportAllChats').addEventListener('click', () => {
  const backup = {format:'scchat-backup-v3', exportedAt:new Date().toISOString(), username:currentUserRecord?.username || currentUser, profile:{displayName:currentUserRecord?.displayName || '',avatarDataUrl:currentUserRecord?.avatarDataUrl || ''}, assistants, projects, chats};
  nativeSaveTextFile('sc-chat-backup.json', 'application/json', JSON.stringify(backup, null, 2), 'Sc Chat 聊天记录备份');
});
function renderMessages() {
  const chat = activeChat(); const messages = $('messages');
  if (!chat || chat.messages.length === 0) { $('welcomePanel').classList.remove('hidden'); messages.classList.add('hidden'); messages.innerHTML = ''; return; }
  $('welcomePanel').classList.add('hidden'); messages.classList.remove('hidden'); messages.innerHTML = '';
  chat.messages.forEach((item,index) => appendMessage(item.role, item.content, {index, attachments:item.attachments || []}));
  messages.scrollTop = messages.scrollHeight;
}
function escapeHtml(value) { return String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char])); }
function renderInlineMarkdown(text) {
  let html = escapeHtml(text);
  html = html.replace(/`([^`]+)`/g, '<code class="inline-code">$1</code>');
  html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  html = html.replace(/\*([^*\n]+)\*/g, '<em>$1</em>');
  html = html.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
  return html;
}
function highlightCode(source, language) {
  const escaped = String(source);
  if (!/^(js|javascript|ts|typescript|py|python|json|bash|sh|yaml|yml|java|kotlin|css|html|xml)$/i.test(language || '')) return escapeHtml(escaped);
  const tokenPattern = /(\/\/[^\n]*|#[^\n]*|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`)|(\b(?:const|let|var|function|return|if|else|for|while|class|new|async|await|import|from|export|default|try|catch|throw|public|private|static|final|void|int|boolean|extends|implements|package|interface|def|lambda|pass|True|False|None|null|undefined|true|false)\b)|(\b\d+(?:\.\d+)?\b)/g;
  let output=''; let last=0; let match;
  while((match=tokenPattern.exec(escaped))!==null) {
    output+=escapeHtml(escaped.slice(last,match.index));
    const token=match[0];
    const cls=match[1]?'code-comment':match[2]?'code-string':match[3]?'code-keyword':'code-number';
    output+=`<span class="${cls}">${escapeHtml(token)}</span>`; last=match.index+token.length;
  }
  return output+escapeHtml(escaped.slice(last));
}
function renderMarkdown(source) {
  const lines = String(source || '').replace(/\r\n?/g,'\n').split('\n');
  const output = []; let paragraph = []; let index = 0;
  const flushParagraph = () => { if (paragraph.length) { output.push(`<p>${paragraph.map(renderInlineMarkdown).join('<br>')}</p>`); paragraph=[]; } };
  while (index < lines.length) {
    const line = lines[index];
    const fence = line.match(/^\s*```([\w+-]*)\s*$/);
    if (fence) {
      flushParagraph(); const language = fence[1] || 'text'; index++; const code=[];
      while (index < lines.length && !/^\s*```\s*$/.test(lines[index])) code.push(lines[index++]);
      if (index < lines.length) index++;
      const raw = code.join('\n');
      output.push(`<div class="code-block"><div class="code-header"><span>${escapeHtml(language)}</span><button type="button" class="code-copy">复制代码</button></div><pre><code>${highlightCode(raw,language)}</code></pre></div>`);
      continue;
    }
    if (!line.trim()) { flushParagraph(); index++; continue; }
    const heading = line.match(/^(#{1,6})\s+(.+)$/);
    if (heading) { flushParagraph(); const level=heading[1].length; output.push(`<h${level}>${renderInlineMarkdown(heading[2])}</h${level}>`); index++; continue; }
    if (/^\s*(---+|\*\*\*+)\s*$/.test(line)) { flushParagraph(); output.push('<hr>'); index++; continue; }
    if (line.startsWith('>')) { flushParagraph(); const quote=[]; while(index<lines.length && lines[index].startsWith('>')) quote.push(lines[index++].replace(/^>\s?/,'')); output.push(`<blockquote>${quote.map(renderInlineMarkdown).join('<br>')}</blockquote>`); continue; }
    if (/^\s*\|/.test(line) && index+1<lines.length && /^\s*\|?\s*:?-{3,}/.test(lines[index+1])) {
      flushParagraph(); const parseCells = value => value.trim().replace(/^\|/,'').replace(/\|$/,'').split('|').map(cell=>cell.trim());
      const headers=parseCells(line); index+=2; const rows=[];
      while(index<lines.length && /^\s*\|/.test(lines[index])) rows.push(parseCells(lines[index++]));
      output.push(`<div class="table-wrap"><table><thead><tr>${headers.map(cell=>`<th>${renderInlineMarkdown(cell)}</th>`).join('')}</tr></thead><tbody>${rows.map(row=>`<tr>${headers.map((_,i)=>`<td>${renderInlineMarkdown(row[i]||'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`);
      continue;
    }
    if (/^\s*[-*+]\s+/.test(line)) {
      flushParagraph(); const items=[]; while(index<lines.length && /^\s*[-*+]\s+/.test(lines[index])) items.push(`<li>${renderInlineMarkdown(lines[index++].replace(/^\s*[-*+]\s+/,''))}</li>`); output.push(`<ul>${items.join('')}</ul>`); continue;
    }
    if (/^\s*\d+[.)]\s+/.test(line)) {
      flushParagraph(); const items=[]; while(index<lines.length && /^\s*\d+[.)]\s+/.test(lines[index])) items.push(`<li>${renderInlineMarkdown(lines[index++].replace(/^\s*\d+[.)]\s+/,''))}</li>`); output.push(`<ol>${items.join('')}</ol>`); continue;
    }
    paragraph.push(line); index++;
  }
  flushParagraph();
  return output.join('');
}
function appendMessage(role, content, opts = {}) {
  const messages = $('messages');
  const row = document.createElement('article'); row.className = `message ${role}`;
  const avatar = document.createElement('div'); avatar.className = 'message-avatar'; if (role === 'assistant') avatar.textContent = 'SC'; else renderAvatar(avatar, currentDisplayName(), currentUserRecord?.avatarDataUrl || '');
  const bodyWrap = document.createElement('div'); bodyWrap.className = 'message-content';
  const label = document.createElement('div'); label.className = 'message-role'; label.textContent = role === 'assistant' ? 'SC CHAT' : 'YOU';
  const body = document.createElement('div'); body.className = `message-body${opts.error ? ' error' : ''}`;
  if (opts.typing) body.innerHTML = '<span class="typing"><i></i><i></i><i></i></span>';
  else body.innerHTML = renderMarkdown(content);
  const attachmentItems = Array.isArray(opts.attachments) ? opts.attachments : [];
  if (attachmentItems.length) {
    const attachmentBox = document.createElement('div'); attachmentBox.className = 'message-attachments';
    attachmentItems.forEach(item => {
      if (item.kind === 'image' && item.dataUrl) { const image = document.createElement('img'); image.src = item.dataUrl; image.alt = item.name || 'Attached image'; image.loading = 'lazy'; attachmentBox.appendChild(image); }
      else { const chip = document.createElement('span'); chip.className = 'message-file-chip'; chip.textContent = `▤ ${item.name || '文档'}`; attachmentBox.appendChild(chip); }
    });
    bodyWrap.appendChild(attachmentBox);
  }
  bodyWrap.append(label, body);
  if (!opts.typing && Number.isInteger(opts.index)) {
    const actions = document.createElement('div'); actions.className = 'message-actions';
    const addAction = (labelText, actionName, callback) => { const button=document.createElement('button'); button.type='button'; button.textContent=labelText; button.dataset.action=actionName; button.addEventListener('click',callback); actions.appendChild(button); };
    addAction('复制', 'copy', () => copyText(String(content || '')));
    if (role === 'assistant') addAction('重新生成', 'regenerate', () => regenerateMessage(opts.index));
    if (role === 'user') addAction('编辑', 'edit', () => editMessage(opts.index));
    bodyWrap.append(actions);
  }
  row.append(avatar, bodyWrap); messages.appendChild(row); messages.scrollTop = messages.scrollHeight;
  row.querySelectorAll('.code-copy').forEach(button => button.addEventListener('click', () => copyText(button.closest('.code-block')?.querySelector('code')?.textContent || '')));
  return {row, body};
}
async function copyText(text) {
  try {
    if (window.ScAiBridge && typeof window.ScAiBridge.copyText === 'function') window.ScAiBridge.copyText(String(text));
    else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(String(text));
    else { const temp=document.createElement('textarea'); temp.value=String(text); document.body.appendChild(temp); temp.select(); document.execCommand('copy'); temp.remove(); }
    showToast('已复制到剪贴板。');
  } catch { showToast('复制失败，请长按文字选择复制。'); }
}
function editMessage(index) {
  const chat=activeChat(); if (!chat || !chat.messages[index] || chat.messages[index].role!=='user') return;
  const content=chat.messages[index].content;
  pendingAttachments = Array.isArray(chat.messages[index].attachments) ? [...chat.messages[index].attachments] : []; renderAttachmentPreview();
  chat.messages=chat.messages.slice(0,index); chat.updatedAt=Date.now(); saveChats(); renderMessages();
  $('messageInput').value=content; autoResize(); $('messageInput').focus(); showToast('已载入提问。修改后发送即可。');
}
async function regenerateMessage(index) {
  const chat=activeChat(); if (!chat || busy || !chat.messages[index] || chat.messages[index].role!=='assistant') return;
  let userIndex=index-1; while(userIndex>=0 && chat.messages[userIndex].role!=='user') userIndex--;
  if (userIndex<0) { showToast('找不到对应的用户提问。'); return; }
  const promptText=chat.messages[userIndex].content;
  chat.messages=chat.messages.slice(0,index); chat.updatedAt=Date.now(); saveChats(); renderMessages();
  await requestAssistant(chat,promptText);
}
$('newChat').addEventListener('click', createChat);
document.querySelectorAll('.suggestion-card').forEach(button => button.addEventListener('click', () => { $('messageInput').value = button.dataset.prompt || ''; $('messageInput').focus(); autoResize(); }));

function inferVisionCapability(model) {
  const candidates = [model?.input_modalities, model?.modalities, model?.architecture?.input_modalities, model?.capabilities, model?.supported_inputs, model?.input?.modalities];
  return candidates.some(value => Array.isArray(value) ? value.some(item => /image|vision/i.test(String(item))) : typeof value === 'string' && /image|vision/i.test(value)) || model?.vision === true || model?.supports_vision === true;
}
function selectedProviderSupportsVision() {
  if (selectedProviderId === 'pollinations') {
    const selectedId = $('modelSelect')?.value;
    return !!freeModels.find(item => item.id === selectedId)?.supportsVision;
  }
  return !!providers.find(item => item.id === selectedProviderId)?.supportsVision;
}
function buildApiMessages(chat) {
  const output = [];
  const assistant = assistants.find(item => item.id === (chat.assistantId || activeAssistantId));
  if (assistant?.systemPrompt?.trim()) output.push({role:'system',content:assistant.systemPrompt.trim()});
  for (const message of chat.messages.slice(-30)) {
    const attachments = Array.isArray(message.attachments) ? message.attachments : [];
    const textParts = [String(message.content || '')];
    attachments.filter(item => item.kind === 'document' && item.text).forEach(item => {
      textParts.push(`\n\n[Attached document: ${item.name || 'document'}]\n${String(item.text).slice(0,120000)}`);
    });
    const images = attachments.filter(item => item.kind === 'image' && item.dataUrl);
    if (message.role === 'user' && images.length) {
      const content = [{type:'text',text:textParts.filter(Boolean).join('\n').trim() || '请分析图片。'}];
      images.forEach(item => content.push({type:'image_url',image_url:{url:item.dataUrl}}));
      output.push({role:message.role,content});
    } else output.push({role:message.role,content:textParts.join('\n').trim()});
  }
  return output;
}
function renderAttachmentPreview() {
  const box = $('attachmentPreview'); if (!box) return;
  box.innerHTML = '';
  box.classList.toggle('hidden', pendingAttachments.length === 0);
  pendingAttachments.forEach((item,index) => {
    const chip = document.createElement('div'); chip.className = 'pending-attachment';
    if (item.kind === 'image' && item.dataUrl) { const img = document.createElement('img'); img.src=item.dataUrl; img.alt=item.name||'图片'; chip.appendChild(img); }
    const label = document.createElement('span'); label.textContent = item.name || '附件'; chip.appendChild(label);
    const remove = document.createElement('button'); remove.type='button'; remove.textContent='×'; remove.setAttribute('aria-label','移除附件'); remove.addEventListener('click',()=>{pendingAttachments.splice(index,1);renderAttachmentPreview();}); chip.appendChild(remove); box.appendChild(chip);
  });
}
function extractPdfTextAsync(base64Pdf) {
  return new Promise((resolve,reject)=>{
    const id=`pdf_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    const timer=setTimeout(()=>{pendingPdfExtractions.delete(id);reject(new Error('PDF 提取超时，请尝试较小的文件。'));},90000);
    pendingPdfExtractions.set(id,{resolve,reject,timer});
    try{window.ScAiBridge.extractPdfTextAsync(id,base64Pdf);}catch(error){clearTimeout(timer);pendingPdfExtractions.delete(id);reject(error);}
  });
}
window.__scaiPdfResult=(id,result)=>{
  const entry=pendingPdfExtractions.get(id);if(!entry)return;
  clearTimeout(entry.timer);pendingPdfExtractions.delete(id);
  if(String(result).startsWith('__PDF_ERROR__'))entry.reject(new Error(String(result).replace('__PDF_ERROR__','')));
  else entry.resolve(String(result||''));
};
function readFileAsDataUrl(file) { return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result||''));reader.onerror=()=>reject(new Error('无法读取所选文件。'));reader.readAsDataURL(file);}); }
async function compressImage(file, maxDimension = 1200) {
  const objectUrl=URL.createObjectURL(file);
  try {
    const image=await new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('图片无法解码。'));img.src=objectUrl;});
    const scale=Math.min(1,maxDimension/Math.max(image.naturalWidth,image.naturalHeight));
    const canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(image.naturalWidth*scale));canvas.height=Math.max(1,Math.round(image.naturalHeight*scale));
    const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(image,0,0,canvas.width,canvas.height);
    return canvas.toDataURL('image/jpeg',0.82);
  } finally { URL.revokeObjectURL(objectUrl); }
}
async function prepareAttachment(file) {
  const name=String(file.name||'attachment').slice(0,120);
  if(file.size>10*1024*1024) throw new Error(`${name} 超过 10 MB 限制。`);
  if(file.type.startsWith('image/')) { const dataUrl=await compressImage(file,1024); if(dataUrl.length>900000) throw new Error(`${name} 压缩后仍然过大，请选择较小的图片。`); return {kind:'image',name,type:'image/jpeg',dataUrl}; }
  const ext=name.toLowerCase().split('.').pop();
  if(file.type==='application/pdf'||ext==='pdf') {
    if(!window.ScAiBridge||typeof window.ScAiBridge.extractPdfTextAsync!=='function') throw new Error('PDF 文本提取需要 Sc Chat Android 原生组件。');
    const dataUrl=await readFileAsDataUrl(file); const base64Data=dataUrl.split(',')[1]||'';
    const extracted=await extractPdfTextAsync(base64Data);
    if(String(extracted).startsWith('__PDF_ERROR__')) throw new Error(String(extracted).replace('__PDF_ERROR__',''));
    if(!String(extracted).trim()) throw new Error(`${name} 没有可提取的文本，扫描版 PDF 暂不支持 OCR。`);
    return {kind:'document',name,type:'application/pdf',text:String(extracted).slice(0,120000)};
  }
  const allowed=['txt','md','csv','json','js','ts','py','java','kt','html','css','xml','yaml','yml','log'];
  if(!allowed.includes(ext)) throw new Error(`${name} 暂不支持。请上传 PDF、图片或常见文本/代码文件。`);
  const text=await file.text();
  return {kind:'document',name,type:file.type||'text/plain',text:String(text).slice(0,120000)};
}
$('attachButton').addEventListener('click',()=>$('attachmentInput').click());
$('attachmentInput').addEventListener('change',async event=>{
  const files=Array.from(event.target.files||[]);event.target.value='';
  for(const file of files){
    if(pendingAttachments.length>=5){showToast('每条消息最多添加 5 个附件。');break;}
    try{const item=await prepareAttachment(file);const imageBytes=pendingAttachments.filter(x=>x.kind==='image').reduce((sum,x)=>sum+(x.dataUrl?.length||0),0)+(item.kind==='image'?(item.dataUrl?.length||0):0);if(imageBytes>2200000)throw new Error('本条消息的图片附件总量不能超过约 2.2 MB。');pendingAttachments.push(item);renderAttachmentPreview();}
    catch(error){showToast(error.message||'附件读取失败。');}
  }
  $('messageInput').focus();
});

function setBusy(value) {
  busy = value; $('messageInput').disabled = value;
  $('sendButton').textContent = value ? '■' : '↑';
  $('sendButton').setAttribute('aria-label', value ? '停止生成' : '发送消息');
  $('sendButton').classList.toggle('stop-mode', value);
}
$('sendButton').addEventListener('click', event => { if (busy) { event.preventDefault(); stopGeneration(); } });
function stopGeneration() { if (activeController) activeController.abort(); }
$('composer').addEventListener('submit', async (event) => {
  event.preventDefault();
  const text = $('messageInput').value.trim();
  if ((!text && !pendingAttachments.length) || busy) return;
  const hasImages = pendingAttachments.some(item => item.kind === 'image');
  if (hasImages && !selectedProviderSupportsVision()) { showToast('当前模型未确认支持图片输入。请在 Provider 能力设置中启用 Vision，或切换支持图片的模型。'); openSettings(); return; }
  if (selectedProviderId === 'pollinations') {
    if (!accessToken) { showToast('请先连接 Pollinations，或在设置中添加其他服务商。'); openSettings(); return; }
    if (!$('modelSelect').value || !freeModels.some(item => item.id === $('modelSelect').value)) { showToast('请先选择一个已确认零价格的 Pollinations 模型。'); openSettings(); return; }
  } else {
    const selected = providers.find(item => item.id === selectedProviderId);
    const ready = selected && (runtimeSecrets[selected.keyId] || (window.ScAiBridge && window.ScAiBridge.hasSecret && window.ScAiBridge.hasSecret(selected.keyId)));
    if (!ready) { showToast('请先在设置中添加并选择一个有效的服务商。'); openSettings(); return; }
  }
  $('messageInput').value = ''; autoResize();
  let chat=activeChat(); if (!chat) { createChat(); chat=activeChat(); }
  const attachmentsToSend = pendingAttachments.map(item => ({...item})); pendingAttachments = []; renderAttachmentPreview();
  const userText = text || (attachmentsToSend.length ? '请分析我上传的附件。' : '');
  chat.messages.push({role:'user',content:userText,attachments:attachmentsToSend});
  if (chat.messages.length===1) chat.title=userText.slice(0,36)||attachmentsToSend[0]?.name||'新对话';
  chat.updatedAt=Date.now(); saveChats(); renderMessages();
  await requestAssistant(chat,text);
});
async function requestAssistant(chat, promptText) {
  const providerId=selectedProviderId;
  const provider=providers.find(item=>item.id===providerId);
  if (providerId==='pollinations') {
    if (!accessToken) { showToast('请先在设置中连接 Pollinations，或添加其他兼容服务。'); openSettings(); return; }
    const modelId=$('modelSelect').value;
    if (!modelId || !freeModels.some(item=>item.id===modelId)) { showToast('当前没有已确认零价格的 Pollinations 文本模型。'); openSettings(); return; }
  } else if (!provider) { showToast('请先添加并选择一个模型服务商。'); openSettings(); return; }
  const requestId=`req_${Date.now()}_${Math.random().toString(36).slice(2)}`;
  const controller=new AbortController(); activeController=controller; activeGenerationChatId=chat.id;
  const pending=chat.id===currentChatId ? appendMessage('assistant','',{typing:true}) : null;
  let answer=''; setBusy(true);
  try {
    const messages=buildApiMessages(chat);
    if (providerId==='pollinations') {
      const modelId=$('modelSelect').value;
      const body={model:modelId,messages,stream:true};
      const endpoint=`${POLLINATIONS}/v1/chat/completions`;
      const onChunk=chunk=>{answer+=chunk;updateStreamDisplay(pending,answer);};
      if(window.ScAiBridge&&typeof window.ScAiBridge.startRequest==='function') answer=await streamNative(requestId,endpoint,`literal:${accessToken}`,body,controller.signal,onChunk);
      else answer=await streamFetch(endpoint,accessToken,body,controller.signal,onChunk);
    } else {
      const endpoint=normaliseEndpoint(provider.baseUrl);
      const body={model:provider.model,messages,stream:true};
      const onChunk=chunk=>{answer+=chunk;updateStreamDisplay(pending,answer);};
      if (window.ScAiBridge && typeof window.ScAiBridge.startRequest==='function') {
        answer=await streamNative(requestId,endpoint,`secret:${provider.keyId}`,body,controller.signal,onChunk);
      } else {
        const key=runtimeSecrets[provider.keyId];
        if (!key) throw new Error('当前预览环境未保存 API Key。请在此会话重新输入密钥；正式 Android 应用会使用系统 Keystore 加密保存。');
        answer=await streamFetch(endpoint,key,body,controller.signal,onChunk);
      }
    }
    if (controller.signal.aborted && !answer.trim()) throw new DOMException('Generation stopped','AbortError');
    if (!answer.trim()) throw new Error('模型没有返回可显示的文本。');
    chat.messages.push({role:'assistant',content:answer.trim()}); chat.updatedAt=Date.now(); saveChats();
    if (pending) { pending.row.remove(); renderMessages(); }
  } catch (error) {
    if (error?.name==='AbortError') {
      if (answer.trim()) { chat.messages.push({role:'assistant',content:answer.trim()+'\n\n_（已停止生成）_'}); chat.updatedAt=Date.now(); saveChats(); }
      if (pending) {
        pending.row.remove();
        if (chat.id === currentChatId) { if (answer.trim()) renderMessages(); else appendMessage('assistant','已停止生成。',{error:true}); }
      }
      showToast('已停止生成。');
    } else {
      if (pending) pending.row.remove();
      const message=`${error?.message || '请求失败。'}\n\n请检查网络、服务商地址、API Key、模型名称和账户额度。`;
      if (pending) appendMessage('assistant',message,{error:true}); else showToast(message);
    }
  } finally {
    if (activeController===controller) activeController=null;
    activeGenerationChatId=null; setBusy(false); $('messageInput').focus();
  }
}
function updateStreamDisplay(pending, text) {
  if (!pending?.body) return;
  pending.body.innerHTML=renderMarkdown(text || '');
  pending.row.querySelectorAll('.code-copy').forEach(button => button.addEventListener('click', () => copyText(button.closest('.code-block')?.querySelector('code')?.textContent || '')));
  $('messages').scrollTop=$('messages').scrollHeight;
}
function normaliseEndpoint(baseUrl) {
  let url; try { url=new URL(baseUrl.trim()); } catch { throw new Error('服务商 Base URL 不是有效网址。'); }
  if (url.protocol!=='https:') throw new Error('为了保护 API Key，服务商地址必须使用 HTTPS。');
  let endpoint=url.toString().replace(/\/+$/,'');
  if (!/\/chat\/completions$/i.test(endpoint)) endpoint+='/chat/completions';
  return endpoint;
}
async function streamFetch(url, credential, body, signal, onChunk) {
  const response=await fetch(url,{method:'POST',signal,headers:{'Authorization':`Bearer ${credential}`,'Content-Type':'application/json','Accept':'text/event-stream, application/json'},body:JSON.stringify(body)});
  if (!response.ok) { const text=await response.text(); let detail=text; try { const parsed=JSON.parse(text); detail=parsed?.error?.message||parsed?.message||text; } catch {} throw new Error(`API 请求失败（HTTP ${response.status}）：${detail.slice(0,500)}`); }
  const type=response.headers.get('content-type')||'';
  if (type.includes('text/event-stream')) return readSse(response,onChunk);
  const payload=await response.json();
  const content=payload?.choices?.[0]?.message?.content??payload?.choices?.[0]?.text??'';
  const value=typeof content==='string'?content:Array.isArray(content)?content.map(part=>part.text||'').join(''):'';
  if (value) onChunk(value);
  return value;
}
async function readSse(response,onChunk) {
  if (!response.body?.getReader) throw new Error('当前设备不支持流式响应读取。');
  const reader=response.body.getReader(); const decoder=new TextDecoder(); let buffer=''; let all='';
  const consume=block=>{
    const data=block.split(/\r?\n/).filter(line=>line.startsWith('data:')).map(line=>line.slice(5).trim()).join('\n');
    if (!data || data==='[DONE]') return;
    let payload; try { payload=JSON.parse(data); } catch { return; }
    const piece=payload?.choices?.[0]?.delta?.content??payload?.choices?.[0]?.text??'';
    const value=typeof piece==='string'?piece:Array.isArray(piece)?piece.map(part=>part.text||'').join(''):'';
    if (value) { all+=value; onChunk(value); }
    const error=payload?.error?.message; if (error) throw new Error(error);
  };
  while(true) {
    const {done,value}=await reader.read();
    buffer+=decoder.decode(value||new Uint8Array(),{stream:!done});
    let boundary;
    while((boundary=buffer.indexOf('\n\n'))>=0) { const block=buffer.slice(0,boundary); buffer=buffer.slice(boundary+2); consume(block); }
    if(done) break;
  }
  if(buffer.trim()) consume(buffer);
  return all;
}
function streamNative(requestId, endpoint, credentialRef, body, signal, onChunk) {
  return new Promise((resolve,reject)=>{
    const entry={resolve,reject,onChunk}; pendingNative.set(requestId,entry);
    const abort=()=>{ pendingNative.delete(requestId); try { window.ScAiBridge.cancelRequest(requestId); } catch {} reject(new DOMException('Generation stopped','AbortError')); };
    signal.addEventListener('abort',abort,{once:true}); entry.cleanup=()=>signal.removeEventListener('abort',abort);
    try { window.ScAiBridge.startRequest(requestId,endpoint,credentialRef,JSON.stringify(body)); }
    catch(error) { pendingNative.delete(requestId); entry.cleanup(); reject(error); }
  });
}
window.__scaiNativeEvent=(id,type,payload)=>{
  const entry=pendingNative.get(id); if(!entry) return;
  if(type==='chunk') entry.onChunk(payload);
  else if(type==='done') { pendingNative.delete(id); entry.cleanup?.(); entry.resolve(payload||''); }
  else if(type==='error') { pendingNative.delete(id); entry.cleanup?.(); entry.reject(new Error(payload||'Native network request failed.')); }
};
function getAvailableViewportHeight() {
  const layoutHeight = Number(document.documentElement.clientHeight || window.innerHeight || 0);
  const visualHeight = Number(window.visualViewport?.height || 0);
  if (layoutHeight > 0 && visualHeight > 0) return Math.min(layoutHeight, visualHeight);
  return Math.max(layoutHeight, visualHeight);
}
function syncAppViewport() {
  const viewportHeight = getAvailableViewportHeight();
  if (Number.isFinite(viewportHeight) && viewportHeight > 0) {
    document.documentElement.style.setProperty('--app-viewport-height', `${Math.round(viewportHeight)}px`);
  }
}
function keepComposerVisible() {
  syncAppViewport();
  if (document.activeElement === $('messageInput')) {
    requestAnimationFrame(() => {
      // The native Activity now resizes the WebView to the IME-safe area.
      // Keep the message list at its end; do not scroll the whole page, which
      // can move the composer behind the keyboard on some WebView versions.
      const messages = $('messages');
      if (messages && !messages.classList.contains('hidden')) {
        messages.scrollTop = messages.scrollHeight;
      }
      syncAppViewport();
    });
  }
}
function setImeVisible(visible) {
  document.body.classList.toggle('ime-visible', !!visible);
  requestAnimationFrame(() => {
    syncAppViewport();
    if (visible) keepComposerVisible();
  });
}
// Called by MainActivity after it applies WindowInsets.Type.ime() to the
// WebView container. This is the authoritative keyboard visibility signal.
window.__scaiNativeImeChanged = setImeVisible;
function autoResize() {
  const input=$('messageInput'); input.style.height='auto'; input.style.height=`${Math.min(input.scrollHeight,170)}px`;
  keepComposerVisible();
}
window.addEventListener('resize', syncAppViewport);
window.visualViewport?.addEventListener('resize', keepComposerVisible);
window.visualViewport?.addEventListener('scroll', keepComposerVisible);
syncAppViewport();
$('messageInput').addEventListener('focus', () => {
  // Immediate visual response while waiting for the native IME inset callback.
  document.body.classList.add('ime-visible');
  setTimeout(syncAppViewport, 80);
  setTimeout(keepComposerVisible, 180);
  setTimeout(syncAppViewport, 320);
});
$('messageInput').addEventListener('blur', () => {
  document.body.classList.remove('ime-visible');
  setTimeout(syncAppViewport, 80);
  setTimeout(syncAppViewport, 220);
});
$('messageInput').addEventListener('input',autoResize);
$('messageInput').addEventListener('keydown',event=>{if(event.key==='Enter'&&!event.shiftKey){event.preventDefault();$('composer').requestSubmit();}});

function openAccount() {
  if(!currentUserRecord) return;
  $('nicknameInput').value=currentUserRecord.displayName||currentUserRecord.username||currentUser;
  $('accountUsernameReadonly').value=currentUserRecord.username||currentUser;
  $('accountCreatedAt').textContent=currentUserRecord.createdAt?new Date(currentUserRecord.createdAt).toLocaleDateString(): '未知';
  $('currentPasswordInput').value='';$('newPasswordInput').value='';$('confirmNewPasswordInput').value='';$('deleteAccountPasswordInput').value='';
  renderUserIdentity();$('accountModal').classList.remove('hidden');
}
function closeAccount() { $('accountModal').classList.add('hidden'); }
$('openAccount').addEventListener('click',openAccount);
$('closeAccount').addEventListener('click',closeAccount);$('doneAccount').addEventListener('click',closeAccount);
$('accountModal').addEventListener('click',event=>{if(event.target===$('accountModal'))closeAccount();});
$('chooseAvatarButton').addEventListener('click',()=>$('avatarFileInput').click());
$('changeAvatarText').addEventListener('click',()=>$('avatarFileInput').click());
$('resetAvatarButton').addEventListener('click',()=>{
  if(!currentUserRecord)return;
  currentUserRecord.avatarDataUrl='';
  const users=getUsers();users[currentUser]=currentUserRecord;setUsers(users);renderUserIdentity();renderMessages();
  showToast('已恢复默认头像。');
});
$('avatarFileInput').addEventListener('change',async event=>{
  const file=event.target.files?.[0];event.target.value='';if(!file)return;
  if(!file.type.startsWith('image/')){showToast('请选择图片文件。');return;}
  if(file.size>8*1024*1024){showToast('头像图片不能超过 8 MB。');return;}
  try{currentUserRecord.avatarDataUrl=await compressImage(file,512);const users=getUsers();users[currentUser]=currentUserRecord;setUsers(users);renderUserIdentity();renderMessages();showToast('头像已更新。');}
  catch(error){showToast(error.message||'头像处理失败。');}
});
$('saveProfileButton').addEventListener('click',()=>{
  const nickname=$('nicknameInput').value.trim().slice(0,32);
  if(!nickname){showToast('昵称不能为空。');return;}
  currentUserRecord.displayName=nickname;
  const users=getUsers();users[currentUser]=currentUserRecord;setUsers(users);renderUserIdentity();renderMessages();showToast('个人资料已保存。');
});
$('changePasswordButton').addEventListener('click',async()=>{
  const current=$('currentPasswordInput').value;const next=$('newPasswordInput').value;const confirmNext=$('confirmNewPasswordInput').value;
  if(!current||!next||!confirmNext){showToast('请填写全部密码字段。');return;}
  if(next.length<10){showToast('新密码至少需要 10 位。');return;}
  if(next!==confirmNext){showToast('两次输入的新密码不一致。');return;}
  try{
    const existing=fromBase64(currentUserRecord.salt);const currentHash=await derivePassword(current,existing);
    if(currentHash!==currentUserRecord.hash){showToast('当前密码不正确。');return;}
    const salt=randomBytes(16);currentUserRecord.salt=base64(salt);currentUserRecord.hash=await derivePassword(next,salt);currentUserRecord.passwordUpdatedAt=Date.now();
    const users=getUsers();users[currentUser]=currentUserRecord;setUsers(users);
    $('currentPasswordInput').value='';$('newPasswordInput').value='';$('confirmNewPasswordInput').value='';$('deleteAccountPasswordInput').value='';showToast('本地账户密码已更新。');
  }catch(error){showToast(error.message||'密码更新失败。');}
});
$('accountLogoutButton').addEventListener('click',()=>{closeAccount();logOut();});
$('deleteAccountButton').addEventListener('click',async()=>{
  const password=$('deleteAccountPasswordInput').value;
  if(!password){showToast('请输入当前账户密码以确认删除。');return;}
  try{
    const hash=await derivePassword(password,fromBase64(currentUserRecord.salt));
    if(hash!==currentUserRecord.hash){showToast('密码不正确，账户未删除。');return;}
    if(!confirm('确定删除此本地账户、个人资料、聊天记录和自定义助手吗？此操作无法撤销。'))return;
    const users=getUsers();delete users[currentUser];setUsers(users);
    localStorage.removeItem(chatStorageKey());localStorage.removeItem(assistantsStorageKey());localStorage.removeItem(activeAssistantStorageKey());localStorage.removeItem(projectsStorageKey());
    $('deleteAccountPasswordInput').value='';closeAccount();logOut();showToast('本地账户和个人资料已删除。');
  }catch(error){showToast(error.message||'无法验证账户。');}
});
$('openAccountFromSettings').addEventListener('click',()=>{closeSettings();openAccount();});

// Workspace navigation and locally stored projects.
function loadProjects() {
  projects = safeJsonParse(localStorage.getItem(projectsStorageKey()), []);
  if (!Array.isArray(projects)) projects = [];
  projects = projects.filter(item => item && item.id && item.name).map(item => ({...item, description:String(item.description || ''), createdAt:item.createdAt || Date.now(), updatedAt:item.updatedAt || item.createdAt || Date.now()}));
  saveProjects();
}
function saveProjects() {
  localStorage.setItem(projectsStorageKey(), JSON.stringify(projects));
  updateSidebarCounts();
  if (activeWorkspacePage === 'projects') renderProjects();
}
function updateSidebarCounts() {
  const projectCount = $('projectNavCount');
  const libraryCount = $('libraryNavCount');
  if (projectCount) projectCount.textContent = String(projects.length);
  if (libraryCount) {
    const count = chats.reduce((sum, chat) => sum + (chat.messages || []).reduce((inner, message) => inner + (message.attachments || []).length, 0), 0);
    libraryCount.textContent = String(count);
  }
}
function setActiveNav(id) {
  document.querySelectorAll('.nav-item').forEach(button => button.classList.toggle('active', button.id === id));
}
function setWorkspacePage(page) {
  activeWorkspacePage = page;
  const isChat = page === 'chats';
  $('welcomePanel').classList.toggle('hidden', !isChat);
  $('messages').classList.toggle('hidden', !isChat || !activeChat() || !(activeChat()?.messages?.length));
  $('projectsPage').classList.toggle('hidden', page !== 'projects');
  $('libraryPage').classList.toggle('hidden', page !== 'library');
  $('composerWrap').classList.toggle('hidden', !isChat);
  $('topbarContext').textContent = page === 'projects' ? '项目' : page === 'library' ? '文件库' : '对话';
  setActiveNav(page === 'projects' ? 'navProjects' : page === 'library' ? 'navLibrary' : 'navChats');
  if (isChat && activeChat()) renderMessages();
  closeSidebar();
}
function navigateToChats() { setWorkspacePage('chats'); if (!activeChat()) createChat(); else renderMessages(); }
function openProjectEditor(project = null) {
  editingProjectId = project?.id || null;
  $('projectModalTitle').textContent = project ? '编辑项目' : '新建项目';
  $('projectNameInput').value = project?.name || '';
  $('projectDescriptionInput').value = project?.description || '';
  $('projectModal').classList.remove('hidden');
  setTimeout(() => $('projectNameInput').focus(), 80);
}
function closeProjectEditor() { $('projectModal').classList.add('hidden'); editingProjectId = null; }
function renderProjects() {
  const grid = $('projectGrid');
  if (!grid) return;
  grid.innerHTML = '';
  $('projectNavCount').textContent = String(projects.length);
  $('projectDetail').classList.add('hidden');
  grid.classList.remove('hidden');
  if (!projects.length) {
    const empty = document.createElement('div'); empty.className = 'workspace-empty';
    empty.innerHTML = '<div class="empty-icon">▦</div><strong>从一个项目开始</strong><p>把研究、学习或开发相关的对话集中在一起。</p><button class="primary-button small-button" type="button">＋ 创建第一个项目</button>';
    empty.querySelector('button').addEventListener('click', () => openProjectEditor());
    grid.appendChild(empty); return;
  }
  projects.slice().sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0)).forEach(project => {
    const card = document.createElement('article'); card.className = 'project-card';
    const open = document.createElement('button'); open.type='button'; open.className='project-card-open';
    const icon = document.createElement('span'); icon.className='project-card-icon'; icon.textContent='▦';
    const name = document.createElement('strong'); name.textContent=project.name;
    const desc = document.createElement('small'); desc.textContent=project.description || '尚未添加项目说明';
    const meta = document.createElement('span'); meta.className='project-card-meta'; meta.textContent=`${chats.filter(chat=>chat.projectId===project.id).length} 段对话 · 更新于 ${new Date(project.updatedAt).toLocaleDateString()}`;
    const text = document.createElement('span'); text.className='project-card-text'; text.append(name,desc,meta); open.append(icon,text); open.addEventListener('click',()=>openProject(project.id));
    const tools = document.createElement('div'); tools.className='project-card-tools';
    const edit = document.createElement('button'); edit.type='button'; edit.textContent='编辑'; edit.addEventListener('click',()=>openProjectEditor(project));
    const remove = document.createElement('button'); remove.type='button'; remove.textContent='删除'; remove.className='danger-mini'; remove.addEventListener('click',()=>deleteProject(project.id));
    tools.append(edit,remove); card.append(open,tools); grid.appendChild(card);
  });
}
function openProject(id) {
  const project = projects.find(item=>item.id===id); if(!project) return;
  openProjectId = id;
  $('projectGrid').classList.add('hidden');
  const detail = $('projectDetail'); detail.classList.remove('hidden');
  const box = $('projectDetailContent'); box.innerHTML='';
  const header = document.createElement('div'); header.className='project-detail-heading';
  const icon = document.createElement('div'); icon.className='project-detail-icon'; icon.textContent='▦';
  const copy = document.createElement('div'); copy.className='project-detail-copy';
  const title = document.createElement('h2'); title.textContent=project.name;
  const desc = document.createElement('p'); desc.textContent=project.description || '这个项目还没有说明。';
  copy.append(title,desc); header.append(icon,copy);
  const newButton = document.createElement('button'); newButton.type='button'; newButton.className='primary-button small-button'; newButton.textContent='＋ 在项目中新建对话';
  newButton.addEventListener('click',()=>createChat(project.id));
  const listTitle = document.createElement('h3'); listTitle.className='project-chat-heading'; listTitle.textContent='项目对话';
  const list = document.createElement('div'); list.className='project-chat-list';
  const related = chats.filter(chat=>chat.projectId===project.id).sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
  if (!related.length) { const empty=document.createElement('p'); empty.className='project-empty-note'; empty.textContent='这里还没有对话。创建一段新对话，或从对话菜单将已有对话移入此项目。'; list.appendChild(empty); }
  related.forEach(chat=>{const button=document.createElement('button');button.type='button';button.className='project-chat-row';const title=document.createElement('strong');title.textContent=chat.title||'新对话';const meta=document.createElement('small');meta.textContent=`${chat.messages.length} 条消息 · ${new Date(chat.updatedAt||Date.now()).toLocaleDateString()}`;button.append(title,meta);button.addEventListener('click',()=>selectChat(chat.id));list.appendChild(button);});
  box.append(header,newButton,listTitle,list);
}
function deleteProject(id) {
  const project=projects.find(item=>item.id===id); if(!project)return;
  if(!confirm(`删除项目“${project.name}”？项目中的对话会保留，但不再属于这个项目。`))return;
  projects=projects.filter(item=>item.id!==id);chats.forEach(chat=>{if(chat.projectId===id)delete chat.projectId;});saveProjects();saveChats();showToast('项目已删除，对话记录已保留。');
}
function moveChatToProject(chat) {
  const lines=['0. 不关联项目',...projects.map((project,index)=>`${index+1}. ${project.name}`)];
  const choice=prompt(`将“${chat.title||'新对话'}”移至哪个项目？\n${lines.join('\n')}\n输入编号：`, chat.projectId ? String(projects.findIndex(item=>item.id===chat.projectId)+1) : '0');
  if(choice===null)return;
  const index=Number(choice);
  if(!Number.isInteger(index)||index<0||index>projects.length){showToast('项目编号无效。');return;}
  chat.projectId=index===0?null:projects[index-1].id;chat.updatedAt=Date.now();saveChats();showToast(index===0?'已从项目中移出。':`已移至项目「${projects[index-1].name}」。`);
}
function renderLibrary() {
  const list=$('libraryList'); if(!list)return;
  list.innerHTML='';
  const query=($('librarySearch').value||'').trim().toLowerCase();
  const items=[];
  chats.forEach(chat=>(chat.messages||[]).forEach((message,messageIndex)=>(message.attachments||[]).forEach(attachment=>items.push({chat,messageIndex,attachment}))));
  const filtered=items.filter(item=>`${item.attachment.name||''} ${item.chat.title||''}`.toLowerCase().includes(query));
  $('libraryNavCount').textContent=String(items.length);
  if(!filtered.length){const empty=document.createElement('div');empty.className='workspace-empty';empty.innerHTML='<div class="empty-icon">▤</div><strong>文件会显示在这里</strong><p>在聊天中添加图片、PDF、文本或代码文件后，可以从文件库快速回到对应对话。</p>';list.appendChild(empty);return;}
  filtered.sort((a,b)=>(b.chat.updatedAt||0)-(a.chat.updatedAt||0)).forEach(({chat,messageIndex,attachment})=>{
    const row=document.createElement('article');row.className='library-item';
    if(attachment.kind==='image'&&attachment.dataUrl){const preview=document.createElement('img');preview.className='library-preview';preview.src=attachment.dataUrl;preview.alt=attachment.name||'图片';row.appendChild(preview);}else{const icon=document.createElement('div');icon.className='library-file-icon';icon.textContent=(attachment.name||'').toLowerCase().endsWith('.pdf')?'PDF':'TXT';row.appendChild(icon);}
    const info=document.createElement('div');info.className='library-item-info';const name=document.createElement('strong');name.textContent=attachment.name||'未命名文件';const meta=document.createElement('small');meta.textContent=`来自：${chat.title||'新对话'} · ${new Date(chat.updatedAt||Date.now()).toLocaleDateString()}`;info.append(name,meta);
    const open=document.createElement('button');open.type='button';open.className='secondary-button';open.textContent='打开对话';open.addEventListener('click',()=>selectChat(chat.id));
    row.append(info,open);list.appendChild(row);
  });
}
$('navChats').addEventListener('click',navigateToChats);
$('navProjects').addEventListener('click',()=>{setWorkspacePage('projects');renderProjects();});
$('navLibrary').addEventListener('click',()=>{setWorkspacePage('library');renderLibrary();});
$('navAssistants').addEventListener('click',()=>{closeSidebar();setActiveNav('navAssistants');openAssistants();});
$('navModels').addEventListener('click',()=>{closeSidebar();setActiveNav('navModels');openSettings();});
$('createProjectButton').addEventListener('click',()=>openProjectEditor());
$('homeCreateProject').addEventListener('click',()=>{setWorkspacePage('projects');openProjectEditor();});
$('homeOpenLibrary').addEventListener('click',()=>{setWorkspacePage('library');renderLibrary();});
$('homeOpenAssistants').addEventListener('click',()=>openAssistants());
$('backProjectsButton').addEventListener('click',()=>{openProjectId=null;renderProjects();});
$('projectModal').addEventListener('click',event=>{if(event.target===$('projectModal'))closeProjectEditor();});
$('closeProjectModal').addEventListener('click',closeProjectEditor);
$('cancelProjectButton').addEventListener('click',closeProjectEditor);
$('saveProjectButton').addEventListener('click',()=>{
  const wasEditing=!!editingProjectId;
  const name=$('projectNameInput').value.trim().slice(0,48);const description=$('projectDescriptionInput').value.trim().slice(0,240);
  if(!name){showToast('请填写项目名称。');return;}
  if(editingProjectId){const project=projects.find(item=>item.id===editingProjectId);if(project)Object.assign(project,{name,description,updatedAt:Date.now()});}
  else projects.unshift({id:crypto.randomUUID?crypto.randomUUID():`project_${Date.now()}`,name,description,createdAt:Date.now(),updatedAt:Date.now()});
  saveProjects();closeProjectEditor();showToast(wasEditing?'项目已更新。':'项目已创建。');
});
$('librarySearch').addEventListener('input',renderLibrary);
function openSettingsFromNavigation() { setActiveNav('navModels'); openSettings(); }

function loadAssistants() {
  assistants=safeJsonParse(localStorage.getItem(assistantsStorageKey()),[]);if(!Array.isArray(assistants))assistants=[];
  assistants=assistants.filter(item=>item&&item.id&&item.name&&typeof item.systemPrompt==='string');
  activeAssistantId=localStorage.getItem(activeAssistantStorageKey())||'default';
  if(activeAssistantId!=='default'&&!assistants.some(item=>item.id===activeAssistantId))activeAssistantId='default';
}
function saveAssistants(){localStorage.setItem(assistantsStorageKey(),JSON.stringify(assistants));}
function assistantName(id){return id==='default'?'通用助手':(assistants.find(item=>item.id===id)?.name||'通用助手');}
function renderAssistantSwitcher(){ $('activeAssistantLabel').textContent=assistantName(activeAssistantId); }
function openAssistants(){renderAssistantList();resetAssistantForm();$('assistantModal').classList.remove('hidden');}
function closeAssistants(){ $('assistantModal').classList.add('hidden'); }
$('assistantManagerButton').addEventListener('click',openAssistants);
$('closeAssistants').addEventListener('click',closeAssistants);$('doneAssistants').addEventListener('click',closeAssistants);
$('assistantModal').addEventListener('click',event=>{if(event.target===$('assistantModal'))closeAssistants();});
function renderAssistantList(){
  const list=$('assistantList');list.innerHTML='';
  const entries=[{id:'default',name:'通用助手',description:'不额外添加系统指令。'},...assistants];
  entries.forEach(item=>{
    const row=document.createElement('div');row.className=`assistant-card${activeAssistantId===item.id?' active':''}`;
    const main=document.createElement('button');main.type='button';main.className='assistant-card-main';
    const name=document.createElement('strong');name.textContent=item.name;const desc=document.createElement('small');desc.textContent=item.description|| (item.id==='default'?'默认对话模式':'自定义助手');main.append(name,desc);
    main.addEventListener('click',()=>{
      activeAssistantId=item.id;localStorage.setItem(activeAssistantStorageKey(),activeAssistantId);
      const chat=activeChat();if(chat){chat.assistantId=activeAssistantId;chat.updatedAt=Date.now();saveChats();}
      renderAssistantSwitcher();renderAssistantList();showToast(`已切换到${item.name}。`);
    });row.appendChild(main);
    if(item.id!=='default'){
      const edit=document.createElement('button');edit.type='button';edit.className='assistant-edit';edit.textContent='编辑';edit.addEventListener('click',()=>editAssistant(item.id));
      const del=document.createElement('button');del.type='button';del.className='assistant-edit danger-mini';del.textContent='删除';del.addEventListener('click',()=>deleteAssistant(item.id));row.append(edit,del);
    }
    list.appendChild(row);
  });
}
function resetAssistantForm(){editingAssistantId=null;$('assistantEditorTitle').textContent='创建助手';$('assistantNameInput').value='';$('assistantDescriptionInput').value='';$('assistantPromptInput').value='';$('saveAssistantButton').innerHTML='保存助手 <span>✓</span>';}
function editAssistant(id){const item=assistants.find(entry=>entry.id===id);if(!item)return;editingAssistantId=id;$('assistantEditorTitle').textContent='编辑助手';$('assistantNameInput').value=item.name;$('assistantDescriptionInput').value=item.description||'';$('assistantPromptInput').value=item.systemPrompt;$('saveAssistantButton').innerHTML='保存修改 <span>✓</span>';}
function deleteAssistant(id){if(!confirm('确定删除这个自定义助手吗？相关对话会回退到通用助手。'))return;assistants=assistants.filter(item=>item.id!==id);chats.forEach(chat=>{if(chat.assistantId===id)chat.assistantId='default';});if(activeAssistantId===id){activeAssistantId='default';localStorage.setItem(activeAssistantStorageKey(),'default');}saveAssistants();saveChats();renderAssistantList();renderAssistantSwitcher();showToast('助手已删除。');}
$('resetAssistantForm').addEventListener('click',resetAssistantForm);
$('saveAssistantButton').addEventListener('click',()=>{
  const name=$('assistantNameInput').value.trim().slice(0,32);const description=$('assistantDescriptionInput').value.trim().slice(0,80);const systemPrompt=$('assistantPromptInput').value.trim();
  if(!name||!systemPrompt){showToast('请填写助手名称和系统指令。');return;}
  if(systemPrompt.length>6000){showToast('系统指令不能超过 6000 个字符。');return;}
  if(editingAssistantId){const item=assistants.find(entry=>entry.id===editingAssistantId);if(item)Object.assign(item,{name,description,systemPrompt,updatedAt:Date.now()});}
  else assistants.push({id:crypto.randomUUID?crypto.randomUUID():`assistant_${Date.now()}`,name,description,systemPrompt,createdAt:Date.now()});
  saveAssistants();renderAssistantList();resetAssistantForm();showToast('助手已保存。');
});

function openSettings() { $('settingsModal').classList.remove('hidden'); renderProviderControls(); }
function closeSettings() { $('settingsModal').classList.add('hidden'); }
$('settingsButton').addEventListener('click',openSettings); $('topSettings').addEventListener('click',openSettings);
$('closeSettings').addEventListener('click',closeSettings); $('doneSettings').addEventListener('click',closeSettings);
$('settingsModal').addEventListener('click',event=>{if(event.target===$('settingsModal'))closeSettings();});
$('appKeyInput').addEventListener('change',()=>localStorage.setItem(STORE_APPKEY,$('appKeyInput').value.trim()));
$('disconnectButton').addEventListener('click',()=>{accessToken=null;deviceCancelled=true;updateConnectionState();showToast('已断开 Pollinations 连接。');});

function loadProviders() {
  providers=safeJsonParse(localStorage.getItem(STORE_PROVIDERS),[]);
  if(!Array.isArray(providers)) providers=[];
  providers=providers.filter(item=>item&&item.id&&item.name&&item.baseUrl&&item.model&&item.keyId);
}
function saveProviders() { localStorage.setItem(STORE_PROVIDERS,JSON.stringify(providers)); }
function renderProviderControls() {
  const select=$('providerSelect'); if(!select) return;
  select.innerHTML='';
  const poll=document.createElement('option'); poll.value='pollinations'; poll.textContent='Pollinations'; select.appendChild(poll);
  providers.forEach(provider=>{const option=document.createElement('option');option.value=provider.id;option.textContent=provider.name;select.appendChild(option);});
  if(selectedProviderId!=='pollinations'&&!providers.some(item=>item.id===selectedProviderId))selectedProviderId='pollinations';
  select.value=selectedProviderId;
  $('pollinationsSettings').classList.toggle('hidden',selectedProviderId!=='pollinations');
  $('customProviderList').innerHTML='';
  providers.forEach(provider=>{
    const row=document.createElement('div');row.className='provider-saved-row';
    const info=document.createElement('div');info.className='provider-saved-info';
    const title=document.createElement('strong');title.textContent=provider.name;
    const detail=document.createElement('small');detail.textContent=`${provider.model} · ${new URL(provider.baseUrl).host}${provider.supportsVision?' · Vision':''}`;
    info.append(title,detail);
    const actions=document.createElement('div');actions.className='provider-saved-actions';
    const visionLabel=document.createElement('label');visionLabel.className='capability-check provider-capability';
    const visionToggle=document.createElement('input');visionToggle.type='checkbox';visionToggle.checked=!!provider.supportsVision;
    visionToggle.addEventListener('change',()=>{provider.supportsVision=visionToggle.checked;saveProviders();showToast(provider.supportsVision?'已启用该模型的图片输入能力。':'已关闭该模型的图片输入能力。');});
    const visionText=document.createElement('span');visionText.textContent='Vision';visionLabel.append(visionToggle,visionText);
    const remove=document.createElement('button');remove.type='button';remove.className='provider-remove';remove.textContent='移除';
    remove.addEventListener('click',async()=>{
      if(!confirm(`确定移除服务商“${provider.name}”吗？`))return;
      providers=providers.filter(item=>item.id!==provider.id);await removeSecret(provider.keyId);
      if(selectedProviderId===provider.id)selectedProviderId='pollinations';
      localStorage.setItem(STORE_ACTIVE_PROVIDER,selectedProviderId);saveProviders();renderProviderControls();updateConnectionState();showToast('服务商已移除。');
    });
    actions.append(visionLabel,remove);row.append(info,actions);$('customProviderList').appendChild(row);
  });
  updateSelectedModelLabel(); updateConnectionState();
}
$('providerSelect').addEventListener('change',()=>{
  selectedProviderId=$('providerSelect').value;localStorage.setItem(STORE_ACTIVE_PROVIDER,selectedProviderId);
  renderProviderControls();
  if(selectedProviderId==='pollinations')loadModels();
});
async function saveSecret(key,value) {
  if(window.ScAiBridge&&typeof window.ScAiBridge.setSecret==='function') {
    if(!window.ScAiBridge.setSecret(key,value)) throw new Error('Android Keystore 保存失败，请重试。');
  } else runtimeSecrets[key]=value;
}
async function removeSecret(key) {
  if(window.ScAiBridge&&typeof window.ScAiBridge.removeSecret==='function')window.ScAiBridge.removeSecret(key);
  delete runtimeSecrets[key];
}
$('saveProviderButton').addEventListener('click',async()=>{
  const name=$('providerNameInput').value.trim().slice(0,40);
  const baseUrl=$('providerBaseUrlInput').value.trim();
  const model=$('providerModelInput').value.trim().slice(0,120);
  const apiKey=$('providerApiKeyInput').value.trim();
  if(!name||!baseUrl||!model||!apiKey){showToast('请完整填写名称、Base URL、模型 ID 和 API Key。');return;}
  try {
    const endpoint=normaliseEndpoint(baseUrl); const parsed=new URL(endpoint);
    if(!/^https:$/.test(parsed.protocol)){showToast('服务商必须使用 HTTPS。');return;}
    const id=crypto.randomUUID?crypto.randomUUID():`provider_${Date.now()}`;
    const keyId=`scailab.provider.key.${id}`;
    await saveSecret(keyId,apiKey);
    providers.push({id,name,baseUrl:baseUrl.replace(/\/+$/,''),model,keyId,supportsVision:$('providerVisionInput').checked,createdAt:Date.now()});
    saveProviders();selectedProviderId=id;localStorage.setItem(STORE_ACTIVE_PROVIDER,id);
    $('providerNameInput').value='';$('providerBaseUrlInput').value='';$('providerModelInput').value='';$('providerApiKeyInput').value='';$('providerVisionInput').checked=false;
    renderProviderControls();showToast('兼容服务商已添加，密钥已安全保存。');
  } catch(error){showToast(error.message||'保存服务商失败。');}
});
async function loadModels() {
  if(selectedProviderId!=='pollinations') { updateSelectedModelLabel(); return; }
  $('modelStatus').textContent='正在获取 Pollinations 实时文本模型目录…';$('modelSelect').innerHTML='<option>正在加载…</option>';
  try {
    const response=await fetch(`${POLLINATIONS}/text/models`,{headers:{'Accept':'application/json'}});
    if(!response.ok)throw new Error(`目录请求失败（HTTP ${response.status}）`);
    const raw=await response.json();const entries=Array.isArray(raw)?raw:(raw.data||raw.models||raw.results||[]);
    freeModels=entries.map(entry=>({id:entry.id||entry.name||entry.model||entry.slug,label:entry.name||entry.title||entry.id||entry.model,raw:entry,supportsVision:inferVisionCapability(entry)})).filter(item=>item.id&&isExplicitlyFree(item.raw));
    const select=$('modelSelect');select.innerHTML='';
    if(!freeModels.length){select.innerHTML='<option value="">当前没有检测到零价格文本模型</option>';$('modelStatus').textContent='目录中没有返回明确标记为零价格的文本模型。你可以添加其他兼容服务商。';$('selectedModelLabel').textContent='未找到免费模型';return;}
    freeModels.sort((a,b)=>String(a.label).localeCompare(String(b.label)));
    for(const item of freeModels){const option=document.createElement('option');option.value=item.id;option.textContent=`${item.label} · FREE`;select.appendChild(option);}
    $('modelStatus').textContent=`已找到 ${freeModels.length} 个明确零价格的文本模型。列表以实时目录为准。`;
    updateSelectedModelLabel();
  }catch(error){freeModels=[];$('modelSelect').innerHTML='<option value="">无法加载模型目录</option>';$('modelStatus').textContent=`${error.message}。请检查网络，或配置其他服务商。`;$('selectedModelLabel').textContent='目录不可用';}
}
function isExplicitlyFree(model) {
  const candidates=[];
  const addNumericLeaves=value=>{
    if(typeof value==='number'&&Number.isFinite(value))candidates.push(value);
    else if(Array.isArray(value))value.forEach(addNumericLeaves);
    else if(value&&typeof value==='object')Object.entries(value).forEach(([key,val])=>{if(/price|pricing|cost|pollen|token|input|output|prompt|completion/i.test(key))addNumericLeaves(val);else if(val&&typeof val==='object')addNumericLeaves(val);});
  };
  for(const key of ['pricing','price','input_price','output_price','cost','pollen'])if(key in model)addNumericLeaves(model[key]);
  return candidates.length>0&&candidates.every(value=>value===0);
}
$('refreshModels').addEventListener('click',loadModels);
$('modelSelect').addEventListener('change',updateSelectedModelLabel);
function updateSelectedModelLabel() {
  const selected=providers.find(item=>item.id===selectedProviderId);
  if(selected){$('selectedModelLabel').textContent=`${selected.name} · ${selected.model}`;return;}
  const option=$('modelSelect').selectedOptions[0];$('selectedModelLabel').textContent=option?.value?option.textContent:'未选择模型';
}

async function connectPollinations() {
  const appKey=$('appKeyInput').value.trim();
  if(!appKey.startsWith('pk_')){showToast('请先填入 Pollinations App Key（pk_…）。');return;}
  localStorage.setItem(STORE_APPKEY,appKey);
  if(devicePollTimer)clearTimeout(devicePollTimer);
  deviceCancelled=false;$('connectButton').disabled=true;$('connectButton').textContent='正在启动授权…';
  $('devicePanel').classList.remove('hidden');$('deviceStatus').textContent='正在向 Pollinations 请求设备授权码…';
  try {
    const response=await fetch(`${ENTER}/api/device/code`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({client_id:appKey})});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok)throw new Error(payload.error_description||payload.error||`HTTP ${response.status}`);
    if(!payload.device_code||!payload.user_code)throw new Error('授权服务未返回完整设备代码。');
    $('deviceCode').textContent=payload.user_code;
    $('deviceLink').href=payload.verification_uri?new URL(payload.verification_uri,ENTER).href:`${ENTER}/device`;
    $('deviceStatus').textContent='请打开授权页面并输入上方代码。授权完成后，本应用会自动连接。';
    pollDeviceToken(payload.device_code,Date.now()+12*60*1000);
  }catch(error){$('deviceStatus').textContent=`启动失败：${error.message}`;showToast('无法启动 Pollinations 授权。');}
  finally{$('connectButton').disabled=false;$('connectButton').textContent='重新连接 ↗';}
}
function pollDeviceToken(deviceCode,deadline) {
  const poll=async()=>{
    if(deviceCancelled||Date.now()>deadline){$('deviceStatus').textContent=deviceCancelled?'授权已取消。':'授权等待超时，请重新开始。';return;}
    try {
      const response=await fetch(`${ENTER}/api/device/token`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({device_code:deviceCode})});
      const payload=await response.json().catch(()=>({}));
      if(response.ok&&payload.access_token){accessToken=payload.access_token;$('deviceStatus').textContent='授权成功。你可以关闭此窗口并开始对话。';updateConnectionState();showToast('Pollinations 已连接。');return;}
      const error=payload.error||'';
      if(error==='authorization_pending'||response.status===400||response.status===428){$('deviceStatus').textContent='等待你在浏览器中确认授权…';}
      else if(error==='slow_down'){$('deviceStatus').textContent='授权服务要求降低轮询频率，正在稍后重试…';devicePollTimer=setTimeout(poll,8000);return;}
      else if(error)throw new Error(payload.error_description||error);
      else if(!response.ok)throw new Error(payload.error_description||`HTTP ${response.status}`);
    }catch(error){$('deviceStatus').textContent=`授权检查失败：${error.message}`;return;}
    devicePollTimer=setTimeout(poll,5000);
  };
  devicePollTimer=setTimeout(poll,5000);
}
$('connectButton').addEventListener('click',connectPollinations);
$('cancelDevice').addEventListener('click',()=>{deviceCancelled=true;if(devicePollTimer)clearTimeout(devicePollTimer);$('deviceStatus').textContent='已取消。';});
function updateConnectionState() {
  const usingPollinations=selectedProviderId==='pollinations';
  const selectedCustom=providers.find(item=>item.id===selectedProviderId);
  let customKeyExists=!!(selectedCustom&&runtimeSecrets[selectedCustom.keyId]);
  if(selectedCustom&&window.ScAiBridge&&typeof window.ScAiBridge.hasSecret==='function') customKeyExists=window.ScAiBridge.hasSecret(selectedCustom.keyId);
  const connected=usingPollinations?!!accessToken:!!(selectedCustom&&customKeyExists);
  const pill=$('connectionLabel');pill.classList.toggle('connected',connected);
  pill.innerHTML=connected?'<i></i> Connected':'<i></i> Not connected';
  $('apiStatus').textContent=accessToken?'已授权':'未授权';
  $('disconnectButton').classList.toggle('hidden',!accessToken);
  $('apiHint').textContent=usingPollinations
    ?(accessToken?'Pollinations 已连接。发送前请确认所选模型的实时价格与账户额度。':'可连接 Pollinations，或在设置中添加其他兼容服务商。Pollinations 调用可能产生费用。')
    :`当前使用 ${providers.find(item=>item.id===selectedProviderId)?.name||'自定义服务商'}。费用与免费额度由对应服务商决定。`;
}

$('clearLocalData').addEventListener('click',()=>{
  if(!confirm('确定清除这台设备上的所有 Sc Chat 本地账户、项目和聊天记录吗？此操作无法撤销。'))return;
  providers.forEach(provider=>removeSecret(provider.keyId));
  localStorage.removeItem(STORE_USERS);localStorage.removeItem(STORE_SESSION);
  localStorage.removeItem(STORE_PROVIDERS);localStorage.removeItem(STORE_ACTIVE_PROVIDER);
  localStorage.removeItem(STORE_APPKEY);
  if(currentUser){localStorage.removeItem(assistantsStorageKey());localStorage.removeItem(activeAssistantStorageKey());localStorage.removeItem(projectsStorageKey());}
  for(const key of Object.keys(localStorage))if(key.startsWith(STORE_CHATS+'.'))localStorage.removeItem(key);
  projects=[];chats=[];accessToken=null;closeSettings();logOut();showToast('本地账户、服务商配置、项目与聊天记录已清除。');
});
function openSidebar(){$('sidebar').classList.add('open');$('sidebarScrim').classList.add('active');}
function closeSidebar(){$('sidebar').classList.remove('open');$('sidebarScrim').classList.remove('active');}
$('openSidebar').addEventListener('click',openSidebar);$('closeSidebar').addEventListener('click',closeSidebar);
$('sidebarScrim').addEventListener('click',closeSidebar);

(function boot(){
  setAuthMode('login');
  const saved=localStorage.getItem(STORE_SESSION);
  if(saved){const account=getUsers()[saved];if(account)enterApp(account.username);else localStorage.removeItem(STORE_SESSION);}
})();
