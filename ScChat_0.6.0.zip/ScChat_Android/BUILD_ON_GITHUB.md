# Build Sc Chat 0.6.0 from an Android phone

1. Upload `ScChat_0.6.0.zip` to the root of your private GitHub repository.
2. Replace `.github/workflows/build-from-zip.yml` with `build-from-zip-0.6.0.yml`.
3. Open **Actions** and run **Build Sc Chat 0.6.0 APK**.
4. When successful, download the `ScChat-0.6.0-debug` artifact.
5. Install `app-debug.apk` on your Android device.

The app keeps the existing Android application ID `ai.scailab.chat` and existing `scailab.*` local-storage namespaces for in-place upgrade compatibility.
