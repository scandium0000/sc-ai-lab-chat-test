# Sc Chat — Android 0.6.0

<p align="center">
  <img src="app/src/main/assets/logo.png" width="112" alt="Sc Ai Lab atom emblem">
</p>

<p align="center">
  <strong>A focused, multi-provider AI workspace by Sc Ai Lab.</strong>
</p>

<p align="center">
  Android · Local-first · Provider-independent · 0.6.0
</p>

---

## Overview

**Sc Chat** is an Android AI chat application developed by **Sc Ai Lab**. It brings conversations, projects, personal assistants, model connections, and conversation attachments into one mobile workspace.

The interface is inspired by compact, navigation-led AI applications, but uses its own Sc Ai Lab identity, blue accent system, atom emblem, page structure, and local-first workflow.

The application is designed to remain independent of any single model provider. The current implementation supports Pollinations and user-configured OpenAI-compatible chat-completions endpoints.

## Highlights

### Chat workspace
- Streaming assistant responses.
- Stop generation.
- Copy messages, edit previous user prompts, and regenerate assistant responses.
- Markdown rendering, including headings, lists, tables, links, code blocks, and code-copy actions.
- Image and document attachments in conversations.
- Mobile composer layout with Android IME/keyboard resizing support.

### Projects
- Create, edit, and delete local projects.
- Create conversations inside a project.
- Move existing conversations into or out of projects.
- Project details show the conversations belonging to that project.
- Deleting a project does not delete its conversations.

### Personal assistants
- Create, edit, select, and delete local assistants.
- Define assistant-specific system instructions.
- Associate conversations with an assistant.

### Model connections
- Pollinations device authorization flow.
- User-configurable OpenAI-compatible HTTPS providers.
- Provider selection and model selection.
- Per-provider Vision capability setting.
- API credentials are stored through the Android Keystore bridge with AES-GCM encryption.
- Pollinations model discovery is fail-closed: a model is not labelled free unless the returned pricing fields can be explicitly confirmed as zero.

### File library
- Aggregates images and documents attached to saved conversations.
- Search attachments by filename or conversation title.
- Navigate back to the conversation containing an attachment.
- PDF text extraction is performed on-device for text-based PDFs (up to 40 pages / 120,000 extracted characters in the current native layer).
- Scanned image-only PDFs are not OCR processed.

### Account and appearance
- Local registration and login.
- Profile image and display-name editing.
- Password changes after current-password verification.
- Account deletion for the current device.
- Automatic light/dark theme based on Android system appearance.
- Blue Sc Ai Lab accent color and the text-free atom emblem.

## Navigation

The main navigation contains:

| Section | Purpose |
|---|---|
| Conversations | Chat history and new conversations |
| Projects | Group related conversations into workspaces |
| AI Assistants | Manage task-specific assistant instructions |
| Models & Connections | Configure providers, credentials, and models |
| File Library | Find attachments already used in conversations |
| Account & Settings | Manage local profile, data, and preferences |

## Requirements

- Android 8.0 (API 26) or later.
- Internet connection for remote AI providers.
- A valid provider API credential where required.
- A model endpoint that supports the OpenAI Chat Completions-compatible request format for custom providers.

## Installation from GitHub Actions

1. Upload `ScChat_0.6.0.zip` to the root of the private GitHub repository.
2. Put the provided workflow at `.github/workflows/build-from-zip.yml`.
3. Run **Build Sc Chat 0.6.0 APK** from the repository's Actions page.
4. When the workflow succeeds, download the `ScChat-0.6.0-debug` artifact.
5. Install `app-debug.apk` on the Android device.

The current build is a debug/test APK, not a production release.

## Build from source

Requirements:

- JDK 17.
- Android SDK Platform 35.
- Android Build Tools 35.0.0.
- Gradle 8.9.

From the `ScChat_Android` directory:

```bash
gradle --no-daemon :app:assembleDebug
```

The APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Custom provider configuration

Open **Models & Connections → Add OpenAI-compatible provider** and enter:

- Provider display name.
- HTTPS API Base URL.
- Model ID.
- API Key.
- Whether the selected model supports image input.

Example values (illustrative only):

```text
Provider Name: My Provider
Base URL: https://api.example.com/v1
Model ID: example-model
API Key: your-provider-key
```

The endpoint must be controlled by a provider you trust. Provider pricing, quotas, model capabilities, and data handling are determined by the provider, not by Sc Chat.

## Local data and privacy

- User accounts, profile data, projects, assistants, conversations, and attachment contents are stored locally in the application's WebView storage.
- The current local account system does not provide cloud account access, password recovery, or cross-device synchronization.
- Provider API credentials are handled through the native Android Keystore bridge. They are not included in chat exports.
- Attachments and prompts are sent to the selected AI provider when the user submits a request that includes them.
- The File Library indexes attachments stored inside local conversations; it is not a separate cloud drive.
- Users should avoid uploading secrets, private credentials, or unnecessary personal information.

## Compatibility and upgrade notes

- Android `applicationId` remains `ai.scailab.chat` so the product rename does not create a different Android app identity.
- Internal local-storage namespaces remain `scailab.*` to preserve existing 0.5.0 user data on compatible in-place updates.
- The debug build uses the same development signing configuration included in the project archive. Keep that key stable for test updates; do not use this development key for a public production release.
- If Android reports a signing-certificate conflict, do not uninstall the old app until local data has been exported or otherwise backed up.

## Roadmap

- [x] Local accounts and profile settings
- [x] Streaming chat and message actions
- [x] Custom AI assistants
- [x] Multi-provider connection architecture
- [x] Projects and project-linked conversations
- [x] Local attachment library
- [x] Automatic system light/dark theme
- [ ] Conversation memory and context management
- [ ] Knowledge collections and retrieval-augmented generation
- [ ] Voice input and speech output
- [ ] HSSM native provider integration
- [ ] Encrypted local conversation database and encrypted backups

## About Sc Ai Lab

Sc Chat is part of the Sc Ai Lab ecosystem. The long-term direction is to provide one flexible client for third-party cloud models, local inference runtimes, and Sc Ai Lab's own HSSM models.

## Disclaimer

Sc Chat is under active development. This 0.6.0 build is intended for testing. Compatibility and provider integrations may change between versions. Verify the provider's current pricing and privacy policy before sending data or using a paid model.

## License

Licensed under the Apache License 2.0. See [LICENSE](LICENSE) for details.
