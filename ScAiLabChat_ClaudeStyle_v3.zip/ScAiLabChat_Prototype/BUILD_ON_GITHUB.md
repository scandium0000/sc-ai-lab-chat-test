# Build Sc Ai Lab Chat 0.2.0 from a phone

This source archive is named `ScAiLabChat_ClaudeStyle_v3.zip`. When using GitHub from an Android phone and uploading the ZIP file itself into the repository root, put the companion workflow template at `.github/workflows/build-from-zip.yml`. The workflow watches the exact ZIP filename, extracts the project, installs Android SDK 35 components, builds `:app:assembleDebug`, verifies the APK signature, and uploads the APK artifact.

After uploading the ZIP and committing the workflow file, open **Actions**, select **Build Sc Ai Lab APK (ZIP)**, and choose **Run workflow**. Download the `app-debug` artifact from the successful run. GitHub may deliver the artifact as a ZIP; extract it to find `app-debug.apk`.

If you instead upload the extracted contents of `ScAiLabChat_Prototype/` to a repository, use `.github/workflows/build-debug-apk.yml` included in this project.

The Pollinations connection is not guaranteed to be free. Confirm the selected model price and your account balance/limits before sending prompts. Do not place a private `sk_...` API secret in the app or repository.
